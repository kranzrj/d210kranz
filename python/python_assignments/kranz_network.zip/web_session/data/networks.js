var networks = {"networkData.tsv": {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.3",
  "target_cytoscapejs_version" : "~2.1",
  "data" : {
    "shared_name" : "networkData.tsv",
    "name" : "networkData.tsv",
    "SUID" : 247,
    "__Annotations" : [ ],
    "selected" : true
  },
  "elements" : {
    "nodes" : [ {
      "data" : {
        "id" : "3517",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "hideous",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "hideous",
        "SelfLoops" : 0,
        "SUID" : 3517,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -555.2467281917918,
        "y" : -144.43760561174048
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3497",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "gasp",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "gasp",
        "SelfLoops" : 0,
        "SUID" : 3497,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -118.69299320304299,
        "y" : 463.8193318315318
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3493",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "deathly",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "deathly",
        "SelfLoops" : 0,
        "SUID" : 3493,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 1.2765183955256134,
        "y" : -429.93368649217706
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3483",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "sickly",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "sickly",
        "SelfLoops" : 0,
        "SUID" : 3483,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 169.6728511461224,
        "y" : -549.401979251055
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3469",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "orange",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "orange",
        "SelfLoops" : 0,
        "SUID" : 3469,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -164.9537653520362,
        "y" : -448.3653661404528
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3453",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "dejected",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "dejected",
        "SelfLoops" : 0,
        "SUID" : 3453,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -522.7521813202372,
        "y" : -236.40613002470923
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3447",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "dumbfounded",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "dumbfounded",
        "SelfLoops" : 0,
        "SUID" : 3447,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -71.76880846243444,
        "y" : 570.8912477728993
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3435",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "key",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "key",
        "SelfLoops" : 0,
        "SUID" : 3435,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 457.9550109518492,
        "y" : -142.81402400834008
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3431",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "omnious",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "omnious",
        "SelfLoops" : 0,
        "SUID" : 3431,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -404.97413647582334,
        "y" : -141.68347491901346
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3419",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "worthy",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "worthy",
        "SelfLoops" : 0,
        "SUID" : 3419,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 302.79481699149915,
        "y" : -489.2270566286838
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3413",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "typewritten",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "typewritten",
        "SelfLoops" : 0,
        "SUID" : 3413,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -523.3300782871167,
        "y" : -48.14218269489152
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3409",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "significant",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "significant",
        "SelfLoops" : 0,
        "SUID" : 3409,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 421.7151371193703,
        "y" : 317.97028421868663
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3383",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "back",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "back",
        "SelfLoops" : 0,
        "SUID" : 3383,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -167.1198143550625,
        "y" : 550.3415340437377
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3377",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "hi",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "hi",
        "SelfLoops" : 0,
        "SUID" : 3377,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 390.6263691998703,
        "y" : 355.40906463501096
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3357",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "juvenile",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 0,
        "name" : "juvenile",
        "SelfLoops" : 0,
        "SUID" : 3357,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -193.02592051183484,
        "y" : 272.0548230800089
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3349",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "impish",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "impish",
        "SelfLoops" : 0,
        "SUID" : 3349,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -490.00026451962924,
        "y" : -189.8518622440116
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3331",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "brief",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "brief",
        "SelfLoops" : 0,
        "SUID" : 3331,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 230.2649670275298,
        "y" : 364.90280570242567
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3327",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "wooded",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "wooded",
        "SelfLoops" : 0,
        "SUID" : 3327,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 275.8312638503885,
        "y" : -265.3779585894237
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3321",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "impending",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "impending",
        "SelfLoops" : 0,
        "SUID" : 3321,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 568.0838881899944,
        "y" : 97.65866147791064
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3317",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "placcid",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "placcid",
        "SelfLoops" : 0,
        "SUID" : 3317,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -446.6638341953458,
        "y" : -276.88314663299474
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3313",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "unmanned",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "unmanned",
        "SelfLoops" : 0,
        "SUID" : 3313,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 318.7770252178743,
        "y" : 420.9083961201827
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3307",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "mighty",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "mighty",
        "SelfLoops" : 0,
        "SUID" : 3307,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 470.107723048758,
        "y" : -95.87748438047993
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3301",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "u-2",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "u-2",
        "SelfLoops" : 0,
        "SUID" : 3301,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 143.42977071087898,
        "y" : -405.78087747501183
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3283",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "generic",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 0,
        "name" : "generic",
        "SelfLoops" : 0,
        "SUID" : 3283,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 13.453944786784064,
        "y" : 382.44757422100633
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3273",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "naked",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 0,
        "name" : "naked",
        "SelfLoops" : 0,
        "SUID" : 3273,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 214.8850493792835,
        "y" : -256.2075887567964
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3269",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "present",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "present",
        "SelfLoops" : 0,
        "SUID" : 3269,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 230.26496702752615,
        "y" : -363.9632509097465
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3259",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "less",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "less",
        "SelfLoops" : 0,
        "SUID" : 3259,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 381.2169174119301,
        "y" : -431.226373660857
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3237",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "straight",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "straight",
        "SelfLoops" : 0,
        "SUID" : 3237,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 269.628688814689,
        "y" : -336.03320083499716
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3229",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "wasted",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "wasted",
        "SelfLoops" : 0,
        "SUID" : 3229,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -378.6638806208672,
        "y" : -431.226373660863
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3225",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "wooden",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "wooden",
        "SelfLoops" : 0,
        "SUID" : 3225,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 525.305218111295,
        "y" : 237.3456848173879
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3219",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 4,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "bewildered",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 4,
        "Indegree" : 0,
        "name" : "bewildered",
        "SelfLoops" : 0,
        "SUID" : 3219,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -190.86194289128548,
        "y" : 139.958736653826
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3197",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "shitty",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "shitty",
        "SelfLoops" : 0,
        "SUID" : 3197,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -340.6847497973282,
        "y" : -461.89238011471144
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3189",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "catatonic",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 0,
        "name" : "catatonic",
        "SelfLoops" : 0,
        "SUID" : 3189,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -10.91942457997777,
        "y" : 334.1809306101461
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3185",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "wild",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "wild",
        "SelfLoops" : 0,
        "SUID" : 3185,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 191.59815803588435,
        "y" : 491.7465603114965
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3181",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "wet",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "wet",
        "SelfLoops" : 0,
        "SUID" : 3181,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 121.24602999409285,
        "y" : -462.87977703885196
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3173",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "near",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "near",
        "SelfLoops" : 0,
        "SUID" : 3173,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 337.7794966268598,
        "y" : -267.88239302282807
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3169",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "conventional",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "conventional",
        "SelfLoops" : 0,
        "SUID" : 3169,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -343.0007315676442,
        "y" : -165.44737704627642
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3137",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "quiet",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "quiet",
        "SelfLoops" : 0,
        "SUID" : 3137,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -318.9600612644405,
        "y" : -208.1060122539073
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3133",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "rotund",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "rotund",
        "SelfLoops" : 0,
        "SUID" : 3133,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -257.62636435288283,
        "y" : -513.0334562321382
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3129",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "warm",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "warm",
        "SelfLoops" : 0,
        "SUID" : 3129,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 503.3289184017068,
        "y" : 280.9330749779988
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3121",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "myopic",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "myopic",
        "SelfLoops" : 0,
        "SUID" : 3121,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 49.8884784867646,
        "y" : 525.0763740789853
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3097",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "sexy",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "sexy",
        "SelfLoops" : 0,
        "SUID" : 3097,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 477.73531964557026,
        "y" : 322.4997206527321
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3087",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "slack",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "slack",
        "SelfLoops" : 0,
        "SUID" : 3087,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -477.352245166055,
        "y" : 0.4697773963433747
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3069",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "fixable",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "fixable",
        "SelfLoops" : 0,
        "SUID" : 3069,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -310.3758128948612,
        "y" : 540.267449488583
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3057",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "vacant",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "vacant",
        "SelfLoops" : 0,
        "SUID" : 3057,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 492.553301310685,
        "y" : -189.8518622440131
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3053",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "mindless",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "mindless",
        "SelfLoops" : 0,
        "SUID" : 3053,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -474.8965557648837,
        "y" : -47.95229146810118
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3047",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "genuine",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "genuine",
        "SelfLoops" : 0,
        "SUID" : 3047,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -417.2109214140067,
        "y" : 232.74925567660307
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3043",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "thundering",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "thundering",
        "SelfLoops" : 0,
        "SUID" : 3043,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 407.5271732668774,
        "y" : -141.68347491901977
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3033",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "funny",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 0,
        "name" : "funny",
        "SelfLoops" : 0,
        "SUID" : 3033,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 155.92845894636275,
        "y" : 349.95240109085444
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3021",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "stunning",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "stunning",
        "SelfLoops" : 0,
        "SUID" : 3021,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -455.4019741607966,
        "y" : -142.8140240083286
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3009",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "scorching",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "scorching",
        "SelfLoops" : 0,
        "SUID" : 3009,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 1.2765183955280008,
        "y" : 430.8732412848585
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3001",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "protective",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "protective",
        "SelfLoops" : 0,
        "SUID" : 3001,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 503.32891840170976,
        "y" : -279.9935201853122
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2997",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "alone",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "alone",
        "SelfLoops" : 0,
        "SUID" : 2997,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -300.2417802004396,
        "y" : 490.1666114213674
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2985",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "male",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "male",
        "SelfLoops" : 0,
        "SUID" : 2985,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 477.4495925559396,
        "y" : 48.89184626078554
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2979",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "fun",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "fun",
        "SelfLoops" : 0,
        "SUID" : 2979,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 420.8888688401843,
        "y" : -95.30400336617186
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2971",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "curious",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "curious",
        "SelfLoops" : 0,
        "SUID" : 2971,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -167.1198143550577,
        "y" : -549.4019792510576
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2951",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "willing",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "willing",
        "SelfLoops" : 0,
        "SUID" : 2951,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -455.401974160795,
        "y" : 143.753578801015
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2943",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "flattered",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "flattered",
        "SelfLoops" : 0,
        "SUID" : 2943,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -289.6622365551195,
        "y" : -247.34056913565325
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2939",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "substantial",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "substantial",
        "SelfLoops" : 0,
        "SUID" : 2939,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -119.88078197147229,
        "y" : -561.7020666247931
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2931",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "fleeting",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "fleeting",
        "SelfLoops" : 0,
        "SUID" : 2931,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -95.53266168354207,
        "y" : -517.4135942224793
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2925",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "broken",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "broken",
        "SelfLoops" : 0,
        "SUID" : 2925,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -438.5631227455225,
        "y" : -188.28027793981448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2921",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "ceramic",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "ceramic",
        "SelfLoops" : 0,
        "SUID" : 2921,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 419.76395820506366,
        "y" : 232.7492556766017
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2917",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "unconscious",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "unconscious",
        "SelfLoops" : 0,
        "SUID" : 2917,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -335.226459835807,
        "y" : -267.8823930228237
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2903",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "pissed",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 0,
        "name" : "pissed",
        "SelfLoops" : 0,
        "SUID" : 2903,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -217.46037970780304,
        "y" : 313.8537214468822
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2899",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "used",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "used",
        "SelfLoops" : 0,
        "SUID" : 2899,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -47.335441695710074,
        "y" : -524.1368192863035
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2895",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "weird",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 0,
        "name" : "weird",
        "SelfLoops" : 0,
        "SUID" : 2895,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -310.6231587478093,
        "y" : -118.82174033325941
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2889",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "pleasant",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "pleasant",
        "SelfLoops" : 0,
        "SUID" : 2889,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 394.11750943711706,
        "y" : 273.8951768491936
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2885",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "several",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "several",
        "SelfLoops" : 0,
        "SUID" : 2885,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -303.0646895662223,
        "y" : -303.87143056540947
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2879",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "excellent",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "excellent",
        "SelfLoops" : 0,
        "SUID" : 2879,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -255.5882243186798,
        "y" : -282.50695474060313
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2875",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "facinating",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "facinating",
        "SelfLoops" : 0,
        "SUID" : 2875,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -23.13054169954535,
        "y" : -574.0914195704028
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2871",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "steamy",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "steamy",
        "SelfLoops" : 0,
        "SUID" : 2871,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 381.21691741192603,
        "y" : 432.16592845354194
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2857",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "speedy",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "speedy",
        "SelfLoops" : 0,
        "SUID" : 2857,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 364.4399805022865,
        "y" : 312.2353834197165
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2827",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "bloody",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 0,
        "name" : "bloody",
        "SelfLoops" : 0,
        "SUID" : 2827,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -230.49841072919656,
        "y" : -239.93042442050148
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2823",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "floral",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 3,
        "Indegree" : 0,
        "name" : "floral",
        "SelfLoops" : 0,
        "SUID" : 2823,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 107.76434654470734,
        "y" : 265.57155337865424
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2815",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "worthless",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "worthless",
        "SelfLoops" : 0,
        "SUID" : 2815,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -217.2973995764048,
        "y" : -313.0278611321475
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2811",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "messed",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "messed",
        "SelfLoops" : 0,
        "SUID" : 2811,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 25.68357849061033,
        "y" : -574.0914195704024
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2803",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "sizzling",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "sizzling",
        "SelfLoops" : 0,
        "SUID" : 2803,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 191.59815803588344,
        "y" : -490.8070055188154
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2799",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "obscene",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "obscene",
        "SelfLoops" : 0,
        "SUID" : 2799,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -276.07640563380943,
        "y" : 448.4101299872134
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2785",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "frozen",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 0,
        "name" : "frozen",
        "SelfLoops" : 0,
        "SUID" : 2785,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -289.93037440869057,
        "y" : 163.903006537975
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2781",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "quizical",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "quizical",
        "SelfLoops" : 0,
        "SUID" : 2781,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 312.92884968591716,
        "y" : -539.3278946959017
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2771",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "cooked",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "cooked",
        "SelfLoops" : 0,
        "SUID" : 2771,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 236.1155822759282,
        "y" : -471.15063991257523
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2755",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "overall",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "overall",
        "SelfLoops" : 0,
        "SUID" : 2755,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 407.5271732668797,
        "y" : 142.62302971169504
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2749",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "furious",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "furious",
        "SelfLoops" : 0,
        "SUID" : 2749,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 541.0741904877699,
        "y" : -311.18255389404936
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2743",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "gigantic",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "gigantic",
        "SelfLoops" : 0,
        "SUID" : 2743,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 343.2377865883875,
        "y" : 462.83193490739063
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2737",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "fried",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "fried",
        "SelfLoops" : 0,
        "SUID" : 2737,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 528.1305816301764,
        "y" : 0.4697773963407599
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2729",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "lonesome",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "lonesome",
        "SelfLoops" : 0,
        "SUID" : 2729,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 212.06182663531104,
        "y" : 430.1848540910612
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2721",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "orignal",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "orignal",
        "SelfLoops" : 0,
        "SUID" : 2721,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -335.22645983580696,
        "y" : 268.8219478155054
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2717",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "bare",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "bare",
        "SelfLoops" : 0,
        "SUID" : 2717,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 312.9288496859176,
        "y" : 540.267449488583
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2711",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "strange",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "strange",
        "SelfLoops" : 0,
        "SUID" : 2711,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 302.79481699149505,
        "y" : 490.16661142136786
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2701",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "sappy",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "sappy",
        "SelfLoops" : 0,
        "SUID" : 2701,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -361.8869437112331,
        "y" : -311.29582862703194
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2697",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "terrible",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "terrible",
        "SelfLoops" : 0,
        "SUID" : 2697,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 167.50680214308738,
        "y" : 449.30492093313615
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2693",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "romantic",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "romantic",
        "SelfLoops" : 0,
        "SUID" : 2693,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -185.46854584557173,
        "y" : -387.3103442045765
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2687",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "depressed",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "depressed",
        "SelfLoops" : 0,
        "SUID" : 2687,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -130.63861915612523,
        "y" : -358.2135417938166
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2681",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "mammary",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "mammary",
        "SelfLoops" : 0,
        "SUID" : 2681,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 568.0838881899955,
        "y" : -96.71910668522298
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2675",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "false",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "false",
        "SelfLoops" : 0,
        "SUID" : 2675,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 318.7770252178743,
        "y" : -419.968841327501
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2669",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "amazing",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "amazing",
        "SelfLoops" : 0,
        "SUID" : 2669,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -328.48286621650425,
        "y" : -346.43689819348344
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2665",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "schizophrenic",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "schizophrenic",
        "SelfLoops" : 0,
        "SUID" : 2665,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 121.24602999409933,
        "y" : 463.8193318315318
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2655",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "deserted",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "deserted",
        "SelfLoops" : 0,
        "SUID" : 2655,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -35.35306600493027,
        "y" : -379.94263108580856
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2651",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "garish",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "garish",
        "SelfLoops" : 0,
        "SUID" : 2651,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 122.43381876253716,
        "y" : -561.7020666247913
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2647",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "tassled",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "tassled",
        "SelfLoops" : 0,
        "SUID" : 2647,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 169.67285114611764,
        "y" : 550.3415340437377
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2625",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "smart",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 0,
        "name" : "smart",
        "SelfLoops" : 0,
        "SUID" : 2625,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -275.2120648624397,
        "y" : 72.39107118967888
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2621",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "litany",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "litany",
        "SelfLoops" : 0,
        "SUID" : 2621,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -573.8028445121854,
        "y" : 0.46977739633825877
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2615",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "pre",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "pre",
        "SelfLoops" : 0,
        "SUID" : 2615,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 122.43381876253227,
        "y" : 562.6416214174737
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2609",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "further",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 0,
        "name" : "further",
        "SelfLoops" : 0,
        "SUID" : 2609,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -175.583177271573,
        "y" : 339.2558087333489
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2605",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "nasty",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 0,
        "name" : "nasty",
        "SelfLoops" : 0,
        "SUID" : 2605,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -289.8076669582474,
        "y" : 248.10928154999715
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2601",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "weakened",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 0,
        "name" : "weakened",
        "SelfLoops" : 0,
        "SUID" : 2601,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 131.87965779496506,
        "y" : -306.8650478079645
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2597",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "afraid",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 3,
        "Indegree" : 0,
        "name" : "afraid",
        "SelfLoops" : 0,
        "SUID" : 2597,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -168.65784887643815,
        "y" : 230.1236909114
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2587",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 6,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "front",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 6,
        "Indegree" : 0,
        "name" : "front",
        "SelfLoops" : 0,
        "SUID" : 2587,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 95.83186727224336,
        "y" : 164.28333383424183
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2581",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "broad",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "broad",
        "SelfLoops" : 0,
        "SUID" : 2581,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -540.9528422402852,
        "y" : 192.05159831580772
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2575",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "closed",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 3,
        "Indegree" : 0,
        "name" : "closed",
        "SelfLoops" : 0,
        "SUID" : 2575,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 223.54039203364766,
        "y" : 179.9617818095844
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2563",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "gritty",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "gritty",
        "SelfLoops" : 0,
        "SUID" : 2563,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 365.70954670161314,
        "y" : 229.45822602834255
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2551",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "wide",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 0,
        "name" : "wide",
        "SelfLoops" : 0,
        "SUID" : 2551,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 175.2361776455308,
        "y" : -284.5739240916461
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2547",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "rousing",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "rousing",
        "SelfLoops" : 0,
        "SUID" : 2547,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 356.2158056341989,
        "y" : -388.8800734080009
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2539",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "angleic",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "angleic",
        "SelfLoops" : 0,
        "SUID" : 2539,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 364.4399805022813,
        "y" : -311.2958286270411
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2529",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "maroon",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "maroon",
        "SelfLoops" : 0,
        "SUID" : 2529,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -404.97413647582334,
        "y" : 142.62302971169515
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2515",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "entire",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 3,
        "Indegree" : 0,
        "name" : "entire",
        "SelfLoops" : 0,
        "SUID" : 2515,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 250.6801348572193,
        "y" : -138.87312794417312
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2507",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "interested",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 3,
        "Indegree" : 0,
        "name" : "interested",
        "SelfLoops" : 0,
        "SUID" : 2507,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 282.85597002900806,
        "y" : 48.756645079950886
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2489",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "previous",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "previous",
        "SelfLoops" : 0,
        "SUID" : 2489,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 576.3558813032417,
        "y" : 0.4697773963407599
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2475",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "homely",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "homely",
        "SelfLoops" : 0,
        "SUID" : 2475,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 394.1175094371123,
        "y" : -272.9556220565188
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2469",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "american",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 3,
        "Indegree" : 0,
        "name" : "american",
        "SelfLoops" : 0,
        "SUID" : 2469,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -205.0287578010379,
        "y" : 198.09756437571377
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2463",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "underway",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "underway",
        "SelfLoops" : 0,
        "SUID" : 2463,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 110.06511889709634,
        "y" : -365.89120221454806
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2457",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "selfish",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "selfish",
        "SelfLoops" : 0,
        "SUID" : 2457,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 574.28415130941,
        "y" : 49.239914414516306
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2449",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "bright",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "bright",
        "SelfLoops" : 0,
        "SUID" : 2449,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 449.21687098639984,
        "y" : 277.8227014256797
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2443",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "stinging",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "stinging",
        "SelfLoops" : 0,
        "SUID" : 2443,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 419.76395820505957,
        "y" : -231.80970088392758
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2431",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "foul",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 0,
        "name" : "foul",
        "SelfLoops" : 0,
        "SUID" : 2431,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -35.01814231295339,
        "y" : -282.90507465825146
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2421",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "far",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "far",
        "SelfLoops" : 0,
        "SUID" : 2421,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -525.5775448391203,
        "y" : 0.4697773963441705
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2415",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "confusing",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "confusing",
        "SelfLoops" : 0,
        "SUID" : 2415,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -490.00026451962685,
        "y" : 190.7914170366994
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2407",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "jammed",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 3,
        "Indegree" : 0,
        "name" : "jammed",
        "SelfLoops" : 0,
        "SUID" : 2407,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -35.06221534739666,
        "y" : 283.8389810915671
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2401",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 5,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "hot",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 5,
        "Indegree" : 0,
        "name" : "hot",
        "SelfLoops" : 0,
        "SUID" : 2401,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 95.87117721500601,
        "y" : -163.32108253441766
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2397",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "rowdy",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "rowdy",
        "SelfLoops" : 0,
        "SUID" : 2397,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -475.18228285451204,
        "y" : -321.5601658600534
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2389",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "condescending",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "condescending",
        "SelfLoops" : 0,
        "SUID" : 2389,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -516.6068532232932,
        "y" : -96.33940268272318
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2381",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "outer",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "outer",
        "SelfLoops" : 0,
        "SUID" : 2381,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -71.20117152037164,
        "y" : -472.63959449661223
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2377",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "cavalier",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "cavalier",
        "SelfLoops" : 0,
        "SUID" : 2377,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -209.50878984425475,
        "y" : 430.1848540910614
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2369",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "reprehensible",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "reprehensible",
        "SelfLoops" : 0,
        "SUID" : 2369,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -380.11848327155724,
        "y" : 24.825057807452595
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2365",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "moral",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "moral",
        "SelfLoops" : 0,
        "SUID" : 2365,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -446.15578751734034,
        "y" : -360.8065784143253
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2357",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "obtuse",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "obtuse",
        "SelfLoops" : 0,
        "SUID" : 2357,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -505.46522983335154,
        "y" : -143.7106808800757
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2349",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "interesting",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 0,
        "name" : "interesting",
        "SelfLoops" : 0,
        "SUID" : 2349,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -310.6231587478098,
        "y" : 119.7612951259398
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2345",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "left",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "left",
        "SelfLoops" : 0,
        "SUID" : 2345,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -251.90087183584205,
        "y" : 406.6553290646914
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2335",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "chilling",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "chilling",
        "SelfLoops" : 0,
        "SUID" : 2335,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 239.58541020049324,
        "y" : -298.30137092161397
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2325",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "spooky",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "spooky",
        "SelfLoops" : 0,
        "SUID" : 2325,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -470.34389891338964,
        "y" : -234.36928648405603
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2321",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "fatty",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "fatty",
        "SelfLoops" : 0,
        "SUID" : 2321,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 356.21580563419866,
        "y" : 389.8196282006827
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2309",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "relaxed",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "relaxed",
        "SelfLoops" : 0,
        "SUID" : 2309,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 97.05029915803084,
        "y" : -419.14257304831756
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2303",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "aft",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "aft",
        "SelfLoops" : 0,
        "SUID" : 2303,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 307.5698975839298,
        "y" : -228.09026470614447
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2289",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "deadly",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "deadly",
        "SelfLoops" : 0,
        "SUID" : 2289,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 278.6294424248674,
        "y" : 448.41012998721226
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2285",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "dramatic",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 0,
        "name" : "dramatic",
        "SelfLoops" : 0,
        "SUID" : 2285,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 249.98122613161343,
        "y" : 223.31017578554201
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2271",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "global",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "global",
        "SelfLoops" : 0,
        "SUID" : 2271,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 334.28027505244813,
        "y" : -187.05042160344362
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2267",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "raggy",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "raggy",
        "SelfLoops" : 0,
        "SUID" : 2267,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 343.2377865883916,
        "y" : -461.89238011470616
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2261",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "polluted",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "polluted",
        "SelfLoops" : 0,
        "SUID" : 2261,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -419.16210032831657,
        "y" : -317.0307294260018
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2257",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "scenic",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "scenic",
        "SelfLoops" : 0,
        "SUID" : 2257,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 236.11558227592866,
        "y" : 472.09019470525664
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2251",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 5,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "nuclear",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 5,
        "Indegree" : 0,
        "name" : "nuclear",
        "SelfLoops" : 0,
        "SUID" : 2251,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -187.86783660144522,
        "y" : 0.37896544925320086
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2245",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "green",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 0,
        "name" : "green",
        "SelfLoops" : 0,
        "SUID" : 2245,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 131.87965779496278,
        "y" : 307.80460260064694
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2241",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "fetid",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "fetid",
        "SelfLoops" : 0,
        "SUID" : 2241,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -361.38958450666166,
        "y" : -120.06496774495952
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2233",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "blank",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "blank",
        "SelfLoops" : 0,
        "SUID" : 2233,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 543.5058790313409,
        "y" : 192.05159831580954
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2227",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "tiny",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "tiny",
        "SelfLoops" : 0,
        "SUID" : 2227,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 449.21687098640075,
        "y" : -276.8831466329969
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2217",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "german",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 3,
        "Indegree" : 0,
        "name" : "german",
        "SelfLoops" : 0,
        "SUID" : 2217,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -190.773958902716,
        "y" : -139.14029469703416
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2213",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "massive",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 0,
        "name" : "massive",
        "SelfLoops" : 0,
        "SUID" : 2213,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 37.79927668941434,
        "y" : 332.40043721997915
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2209",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 5,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "human",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 5,
        "Indegree" : 0,
        "name" : "human",
        "SelfLoops" : 0,
        "SUID" : 2209,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 183.97637703156136,
        "y" : -48.48282139477794
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2195",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "main",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "main",
        "SelfLoops" : 0,
        "SUID" : 2195,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 472.8969357044449,
        "y" : -234.3692864840579
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2191",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "overhead",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "overhead",
        "SelfLoops" : 0,
        "SUID" : 2191,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -474.8965557648832,
        "y" : 48.89184626078793
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2185",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "grand",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "grand",
        "SelfLoops" : 0,
        "SUID" : 2185,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -328.48286621650044,
        "y" : 347.3764529861686
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2179",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "meek",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "meek",
        "SelfLoops" : 0,
        "SUID" : 2179,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 188.02158263662704,
        "y" : 388.24989899725847
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2169",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "famous",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 0,
        "name" : "famous",
        "SelfLoops" : 0,
        "SUID" : 2169,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -324.6683429733119,
        "y" : 73.07709212149314
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2165",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "digestive",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "digestive",
        "SelfLoops" : 0,
        "SUID" : 2165,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -388.07333240881707,
        "y" : -354.46950984232626
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2161",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "colorless",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "colorless",
        "SelfLoops" : 0,
        "SUID" : 2161,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 145.4569766719486,
        "y" : 507.21152562521934
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2157",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "thick",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 0,
        "name" : "thick",
        "SelfLoops" : 0,
        "SUID" : 2157,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -331.7665783679801,
        "y" : 24.84539026088521
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2153",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "important",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "important",
        "SelfLoops" : 0,
        "SUID" : 2153,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -361.88694371122966,
        "y" : 312.23538341971744
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2147",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "beefoid",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "beefoid",
        "SelfLoops" : 0,
        "SUID" : 2147,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 97.0502991580338,
        "y" : 420.0821278409983
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2143",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "honest",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "honest",
        "SelfLoops" : 0,
        "SUID" : 2143,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 380.31141717180503,
        "y" : -48.396084820522674
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2135",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "scary",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "scary",
        "SelfLoops" : 0,
        "SUID" : 2135,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -257.62636435288726,
        "y" : 513.9730110248174
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2129",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "social",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "social",
        "SelfLoops" : 0,
        "SUID" : 2129,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 98.08569847459614,
        "y" : 518.3531490151613
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2125",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "absolute",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "absolute",
        "SelfLoops" : 0,
        "SUID" : 2125,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 167.5068021430809,
        "y" : -448.365366140457
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2115",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "shit",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "shit",
        "SelfLoops" : 0,
        "SUID" : 2115,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 49.4664167428549,
        "y" : 428.1669546427063
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2109",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 4,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "many",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 4,
        "Indegree" : 0,
        "name" : "many",
        "SelfLoops" : 0,
        "SUID" : 2109,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 74.60892453113831,
        "y" : 226.29430279330154
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2101",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "asshole",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "asshole",
        "SelfLoops" : 0,
        "SUID" : 2101,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -316.22398842682134,
        "y" : -419.96884132749864
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2097",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "flaming",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "flaming",
        "SelfLoops" : 0,
        "SUID" : 2097,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 1.2765183955289103,
        "y" : 527.323840630989
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2087",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "exciting",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "exciting",
        "SelfLoops" : 0,
        "SUID" : 2087,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -363.15650991055696,
        "y" : -228.51867123566103
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2083",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "next",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 3,
        "Indegree" : 0,
        "name" : "next",
        "SelfLoops" : 0,
        "SUID" : 2083,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -157.5544993999839,
        "y" : -176.01553600520685
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2079",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "decent",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "decent",
        "SelfLoops" : 0,
        "SUID" : 2079,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 383.4483736917284,
        "y" : 0.4697773963407599
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2073",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "fair",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "fair",
        "SelfLoops" : 0,
        "SUID" : 2073,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 448.7088243083987,
        "y" : 361.74613320700416
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2069",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "friendly",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "friendly",
        "SelfLoops" : 0,
        "SUID" : 2069,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -276.0764056338144,
        "y" : -447.4705751945288
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2065",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "considerate",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "considerate",
        "SelfLoops" : 0,
        "SUID" : 2065,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -47.33544169570666,
        "y" : 525.0763740789853
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2057",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "soon",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "soon",
        "SelfLoops" : 0,
        "SUID" : 2057,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -391.56447264606,
        "y" : 273.89517684919474
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2053",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "ignorant",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "ignorant",
        "SelfLoops" : 0,
        "SUID" : 2053,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 389.056639996443,
        "y" : -186.27528684476385
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2041",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "established",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "established",
        "SelfLoops" : 0,
        "SUID" : 2041,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 448.7088243084023,
        "y" : -360.8065784143184
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2029",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "vicious",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "vicious",
        "SelfLoops" : 0,
        "SUID" : 2029,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -467.55468625770413,
        "y" : -95.8774843804681
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2025",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "mean",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "mean",
        "SelfLoops" : 0,
        "SUID" : 2025,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 479.90528195711124,
        "y" : 0.4697773963407599
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2017",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "wonderful",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 3,
        "Indegree" : 0,
        "name" : "wonderful",
        "SelfLoops" : 0,
        "SUID" : 2017,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -72.0496973145872,
        "y" : -225.35675813488143
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1999",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "casual",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 0,
        "name" : "casual",
        "SelfLoops" : 0,
        "SUID" : 1999,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -283.3891474838018,
        "y" : 24.637272971670086
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1995",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "frightening",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 3,
        "Indegree" : 0,
        "name" : "frightening",
        "SelfLoops" : 0,
        "SUID" : 1995,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -215.6651709084308,
        "y" : 96.96154648751917
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1985",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "crusty",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "crusty",
        "SelfLoops" : 0,
        "SUID" : 1985,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -46.91337995179879,
        "y" : 428.1669546427063
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1979",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "charming",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 0,
        "name" : "charming",
        "SelfLoops" : 0,
        "SUID" : 1979,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 370.9504194907207,
        "y" : 97.40549748755143
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1973",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "common",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "common",
        "SelfLoops" : 0,
        "SUID" : 1973,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -340.68474979733224,
        "y" : 462.83193490738995
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1969",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "pure",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 0,
        "name" : "pure",
        "SelfLoops" : 0,
        "SUID" : 1969,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 279.77669382728584,
        "y" : -183.78419702166116
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1961",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "fake",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "fake",
        "SelfLoops" : 0,
        "SUID" : 1961,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 470.1077230487598,
        "y" : 96.81703917315258
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1955",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "parental",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "parental",
        "SelfLoops" : 0,
        "SUID" : 1955,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 428.97369564189296,
        "y" : -47.72012095099342
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1945",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "divorced",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "divorced",
        "SelfLoops" : 0,
        "SUID" : 1945,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 525.3052181112972,
        "y" : -236.40613002470104
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1939",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "natural",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "natural",
        "SelfLoops" : 0,
        "SUID" : 1939,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -189.04512124483097,
        "y" : -490.807005518814
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1929",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "married",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "married",
        "SelfLoops" : 0,
        "SUID" : 1929,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 457.95501095185193,
        "y" : 143.7535788010132
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1921",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "awkward",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "awkward",
        "SelfLoops" : 0,
        "SUID" : 1921,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -140.87673391982622,
        "y" : 406.7204322676921
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1915",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "compatible",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "compatible",
        "SelfLoops" : 0,
        "SUID" : 1915,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -71.76880846242955,
        "y" : -569.9516929802185
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1907",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "true",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 3,
        "Indegree" : 0,
        "name" : "true",
        "SelfLoops" : 0,
        "SUID" : 1907,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -230.95268679145158,
        "y" : -48.96658896107283
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1903",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "enriching",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "enriching",
        "SelfLoops" : 0,
        "SUID" : 1903,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -142.90393988089068,
        "y" : 507.2115256252198
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1891",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "cutest",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "cutest",
        "SelfLoops" : 0,
        "SUID" : 1891,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 428.97369564189364,
        "y" : 48.65967574366766
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1883",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "round",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 0,
        "name" : "round",
        "SelfLoops" : 0,
        "SUID" : 1883,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 355.5166897267958,
        "y" : 143.8895389208044
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1879",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 5,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "giant",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 5,
        "Indegree" : 0,
        "name" : "giant",
        "SelfLoops" : 0,
        "SUID" : 1879,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -181.4484974409919,
        "y" : 49.32838832189111
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1875",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "underground",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "underground",
        "SelfLoops" : 0,
        "SUID" : 1875,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 1.2765183955259545,
        "y" : -526.3842858383075
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1869",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "humorless",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "humorless",
        "SelfLoops" : 0,
        "SUID" : 1869,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -417.21092141400914,
        "y" : -231.809700883917
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1861",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "lean",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 0,
        "name" : "lean",
        "SelfLoops" : 0,
        "SUID" : 1861,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 303.63641380176784,
        "y" : 142.21027427100705
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1853",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "dizzying",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "dizzying",
        "SelfLoops" : 0,
        "SUID" : 1853,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -538.521153696714,
        "y" : -311.18255389404897
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1847",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "personal",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 0,
        "name" : "personal",
        "SelfLoops" : 0,
        "SUID" : 1847,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 275.791128526546,
        "y" : 266.35895695270233
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1843",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "vantage",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "vantage",
        "SelfLoops" : 0,
        "SUID" : 1843,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 49.8884784867621,
        "y" : -524.1368192863039
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1835",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "original",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "original",
        "SelfLoops" : 0,
        "SUID" : 1835,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 254.45390862689237,
        "y" : -405.7157742720135
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1829",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "like",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "like",
        "SelfLoops" : 0,
        "SUID" : 1829,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -267.07565202363656,
        "y" : -336.0332008349942
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1821",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "taut",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "taut",
        "SelfLoops" : 0,
        "SUID" : 1821,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -310.3758128948611,
        "y" : -539.3278946959016
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1817",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "soft",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 0,
        "name" : "soft",
        "SelfLoops" : 0,
        "SUID" : 1817,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 109.9606483286085,
        "y" : 366.8617626815394
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1811",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "spirited",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "spirited",
        "SelfLoops" : 0,
        "SUID" : 1811,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 145.45697667194713,
        "y" : -506.27197083253816
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1805",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "tall",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 3,
        "Indegree" : 0,
        "name" : "tall",
        "SelfLoops" : 0,
        "SUID" : 1805,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 270.64347098879705,
        "y" : -94.71453866214347
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1801",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "skinny",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 0,
        "name" : "skinny",
        "SelfLoops" : 0,
        "SUID" : 1801,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -10.919424579975837,
        "y" : -333.2413758174646
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1793",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "graphic",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "graphic",
        "SelfLoops" : 0,
        "SUID" : 1793,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -267.07565202363645,
        "y" : 336.97275562767584
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1781",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "extra",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "extra",
        "SelfLoops" : 0,
        "SUID" : 1781,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -413.9055321631823,
        "y" : 398.38954133903076
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1777",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "hourly",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "hourly",
        "SelfLoops" : 0,
        "SUID" : 1777,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 519.1598900143493,
        "y" : -96.33940268272386
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1773",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 4,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "large",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 4,
        "Indegree" : 0,
        "name" : "large",
        "SelfLoops" : 0,
        "SUID" : 1773,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -23.59763922688694,
        "y" : 236.5960875419405
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1769",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "heartless",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "heartless",
        "SelfLoops" : 0,
        "SUID" : 1769,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 331.0359030075572,
        "y" : 347.37645298616803
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1765",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "hey",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "hey",
        "SelfLoops" : 0,
        "SUID" : 1765,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -227.71193023647413,
        "y" : -363.963250909744
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1761",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "flabbergasted",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "flabbergasted",
        "SelfLoops" : 0,
        "SUID" : 1761,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -303.06468956622217,
        "y" : 304.8109853580911
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1747",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 4,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "puzzled",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 4,
        "Indegree" : 0,
        "name" : "puzzled",
        "SelfLoops" : 0,
        "SUID" : 1747,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 119.96475896211132,
        "y" : 206.10892642105728
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1741",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "unable",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "unable",
        "SelfLoops" : 0,
        "SUID" : 1741,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -391.56447264606294,
        "y" : -272.9556220565089
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1737",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "awful",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "awful",
        "SelfLoops" : 0,
        "SUID" : 1737,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 254.45390862689874,
        "y" : 406.65532906469116
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1729",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "mannequin",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 0,
        "name" : "mannequin",
        "SelfLoops" : 0,
        "SUID" : 1729,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -259.08337816105666,
        "y" : 118.0764669932779
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1725",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "metallic",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "metallic",
        "SelfLoops" : 0,
        "SUID" : 1725,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 624.5811809763069,
        "y" : 0.4697773963407599
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1719",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "baffled",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 0,
        "name" : "baffled",
        "SelfLoops" : 0,
        "SUID" : 1719,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 37.799276689416615,
        "y" : -331.4608824272974
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1711",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "additional",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "additional",
        "SelfLoops" : 0,
        "SUID" : 1711,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -316.2239884268164,
        "y" : 420.90839612018385
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1707",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "mature",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "mature",
        "SelfLoops" : 0,
        "SUID" : 1707,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 331.0359030075515,
        "y" : -346.4368981934918
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1703",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "ax",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "ax",
        "SelfLoops" : 0,
        "SUID" : 1703,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -426.4206588508374,
        "y" : 48.65967574366766
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1699",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "adjacent",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "adjacent",
        "SelfLoops" : 0,
        "SUID" : 1699,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 389.0566399964457,
        "y" : 187.2148416374398
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1693",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "local",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "local",
        "SelfLoops" : 0,
        "SUID" : 1693,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 1.2765183955282282,
        "y" : 623.7744399771195
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1687",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "teenage",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 3,
        "Indegree" : 0,
        "name" : "teenage",
        "SelfLoops" : 0,
        "SUID" : 1687,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 218.18645508169664,
        "y" : -96.09334924733776
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1683",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "puss",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "puss",
        "SelfLoops" : 0,
        "SUID" : 1683,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 278.6294424248672,
        "y" : -447.47057519453085
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1679",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "sour",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "sour",
        "SelfLoops" : 0,
        "SUID" : 1679,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -353.6627688431407,
        "y" : 389.8196282006843
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1673",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "aged",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 0,
        "name" : "aged",
        "SelfLoops" : 0,
        "SUID" : 1673,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -263.03102072836066,
        "y" : 204.56142241549298
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1669",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "thrilled",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "thrilled",
        "SelfLoops" : 0,
        "SUID" : 1669,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -140.87673391982736,
        "y" : -405.78087747501024
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1663",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "latter",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "latter",
        "SelfLoops" : 0,
        "SUID" : 1663,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -83.69329480212173,
        "y" : -372.13652666425406
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1659",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "hearty",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "hearty",
        "SelfLoops" : 0,
        "SUID" : 1659,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 74.32184525349442,
        "y" : -569.9516929802173
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1655",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "slavic",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "slavic",
        "SelfLoops" : 0,
        "SUID" : 1655,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 260.17940114394264,
        "y" : 513.9730110248179
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1651",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "polite",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 0,
        "name" : "polite",
        "SelfLoops" : 0,
        "SUID" : 1651,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -324.6683429733116,
        "y" : -72.13753732881264
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1647",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "chipper",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "chipper",
        "SelfLoops" : 0,
        "SUID" : 1647,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -388.0733324088126,
        "y" : 355.4090646350128
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1641",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "pooped",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "pooped",
        "SelfLoops" : 0,
        "SUID" : 1641,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 73.75420831142219,
        "y" : 473.5791492892945
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1633",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "solid",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "solid",
        "SelfLoops" : 0,
        "SUID" : 1633,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -363.1565099105569,
        "y" : 229.45822602834255
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1621",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "silver",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "silver",
        "SelfLoops" : 0,
        "SUID" : 1621,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -522.7521813202393,
        "y" : 237.3456848173862
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1613",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "cocky",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "cocky",
        "SelfLoops" : 0,
        "SUID" : 1613,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -291.6950111999114,
        "y" : -378.01823582864677
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1607",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "fresh",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "fresh",
        "SelfLoops" : 0,
        "SUID" : 1607,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -426.4206588508374,
        "y" : -47.72012095098603
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1599",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "necessary",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "necessary",
        "SelfLoops" : 0,
        "SUID" : 1599,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 13.588491288929504,
        "y" : -381.50370637447287
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1595",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 5,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "bold",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 5,
        "Indegree" : 0,
        "name" : "bold",
        "SelfLoops" : 0,
        "SUID" : 1595,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -132.42173080198563,
        "y" : -133.32249979315299
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1591",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "risky",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "risky",
        "SelfLoops" : 0,
        "SUID" : 1591,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 74.32184525348953,
        "y" : 570.8912477728995
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1587",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 4,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "quick",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 4,
        "Indegree" : 0,
        "name" : "quick",
        "SelfLoops" : 0,
        "SUID" : 1587,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 193.35378151265218,
        "y" : 140.0429949340754
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1583",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "fabulous",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "fabulous",
        "SelfLoops" : 0,
        "SUID" : 1583,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -419.16210032831253,
        "y" : 317.9702842186887
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1579",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "comfortable",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 3,
        "Indegree" : 0,
        "name" : "comfortable",
        "SelfLoops" : 0,
        "SUID" : 1579,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 26.131257549304223,
        "y" : -235.658577533766
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1573",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "hasty",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "hasty",
        "SelfLoops" : 0,
        "SUID" : 1573,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -94.49726236697938,
        "y" : -419.1425730483165
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1565",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "dear",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 0,
        "name" : "dear",
        "SelfLoops" : 0,
        "SUID" : 1565,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 335.21045618015876,
        "y" : 0.4697773963407599
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1559",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "terrific",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "terrific",
        "SelfLoops" : 0,
        "SUID" : 1559,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 25.68357849060544,
        "y" : 575.0309743630842
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1553",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "low",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "low",
        "SelfLoops" : 0,
        "SUID" : 1553,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 508.0182666244069,
        "y" : 144.6502356727608
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1543",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "top",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 3,
        "Indegree" : 0,
        "name" : "top",
        "SelfLoops" : 0,
        "SUID" : 1543,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 233.52197306616802,
        "y" : -48.89019469875325
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1539",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "perfect",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "perfect",
        "SelfLoops" : 0,
        "SUID" : 1539,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 337.7794966268632,
        "y" : 268.82194781550527
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1535",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "crazy",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 3,
        "Indegree" : 0,
        "name" : "crazy",
        "SelfLoops" : 0,
        "SUID" : 1535,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 193.37290991043767,
        "y" : -139.07711231228473
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1529",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "distinctive",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "distinctive",
        "SelfLoops" : 0,
        "SUID" : 1529,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 574.2841513094105,
        "y" : -48.30035962182842
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1519",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "simple",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "simple",
        "SelfLoops" : 0,
        "SUID" : 1519,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -446.6638341953423,
        "y" : 277.822701425682
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1509",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 5,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "more",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 5,
        "Indegree" : 0,
        "name" : "more",
        "SelfLoops" : 0,
        "SUID" : 1509,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -47.629088080424594,
        "y" : -182.24266588339333
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1505",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Less",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "Less",
        "SelfLoops" : 0,
        "SUID" : 1505,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -361.47037329240834,
        "y" : 120.76117173226339
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1501",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "monotone",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "monotone",
        "SelfLoops" : 0,
        "SUID" : 1501,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -571.7311145183537,
        "y" : -48.30035962183729
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1497",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "grim",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 3,
        "Indegree" : 0,
        "name" : "grim",
        "SelfLoops" : 0,
        "SUID" : 1497,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 160.1655822823783,
        "y" : -175.96327913661497
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1493",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "ashen",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "ashen",
        "SelfLoops" : 0,
        "SUID" : 1493,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -516.6068532232919,
        "y" : 97.27895747541129
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1489",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "red",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 0,
        "name" : "red",
        "SelfLoops" : 0,
        "SUID" : 1489,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 61.4437830617037,
        "y" : -278.81235492775943
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1485",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "erotic",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "erotic",
        "SelfLoops" : 0,
        "SUID" : 1485,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -209.5087898442594,
        "y" : -429.24529929837746
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1469",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "uncalled",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "uncalled",
        "SelfLoops" : 0,
        "SUID" : 1469,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -540.9528422402836,
        "y" : -191.11204352313086
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1457",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "incredulous",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "incredulous",
        "SelfLoops" : 0,
        "SUID" : 1457,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 472.8969357044442,
        "y" : 235.30884127674108
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1449",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "loud",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 3,
        "Indegree" : 0,
        "name" : "loud",
        "SelfLoops" : 0,
        "SUID" : 1449,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -235.46338325992485,
        "y" : 160.38484278128908
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1445",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 7,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "few",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 7,
        "Indegree" : 0,
        "name" : "few",
        "SelfLoops" : 0,
        "SUID" : 1445,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -47.74184829861531,
        "y" : 183.15200149236296
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1435",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "enthusiastic",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "enthusiastic",
        "SelfLoops" : 0,
        "SUID" : 1435,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 215.69858409344658,
        "y" : -533.140053270392
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1425",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "impossible",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 0,
        "name" : "impossible",
        "SelfLoops" : 0,
        "SUID" : 1425,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -127.33485802417609,
        "y" : -254.6335801439609
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1421",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "shitless",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "shitless",
        "SelfLoops" : 0,
        "SUID" : 1421,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -118.69299320304856,
        "y" : -462.8797770388489
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1417",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "scared",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "scared",
        "SelfLoops" : 0,
        "SUID" : 1417,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -164.9537653520311,
        "y" : 449.30492093313615
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1409",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "goddamn",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 3,
        "Indegree" : 0,
        "name" : "goddamn",
        "SelfLoops" : 0,
        "SUID" : 1409,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -117.39481056626903,
        "y" : -205.17913153060118
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1405",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "clear",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "clear",
        "SelfLoops" : 0,
        "SUID" : 1405,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -500.7758816106489,
        "y" : -279.99352018532005
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1399",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "french",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 0,
        "name" : "french",
        "SelfLoops" : 0,
        "SUID" : 1399,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 62.207695387451736,
        "y" : 377.7531174087494
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1395",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "embarrassed",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 0,
        "name" : "embarrassed",
        "SelfLoops" : 0,
        "SUID" : 1395,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -59.37819049883615,
        "y" : 328.84895014225276
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1389",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "phoney",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 3,
        "Indegree" : 0,
        "name" : "phoney",
        "SelfLoops" : 0,
        "SUID" : 1389,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 282.8559700290085,
        "y" : -47.817090287267206
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1385",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 5,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "deep",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 5,
        "Indegree" : 0,
        "name" : "deep",
        "SelfLoops" : 0,
        "SUID" : 1385,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 50.26357984624417,
        "y" : -182.22084383106255
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1375",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "same",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 0,
        "name" : "same",
        "SelfLoops" : 0,
        "SUID" : 1375,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 13.386964036722247,
        "y" : -284.9631328983159
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1367",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "ugly",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "ugly",
        "SelfLoops" : 0,
        "SUID" : 1367,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -119.88078197147718,
        "y" : 562.6416214174737
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1351",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "litttle",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "litttle",
        "SelfLoops" : 0,
        "SUID" : 1351,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -386.5036032053896,
        "y" : -186.27528684475817
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1347",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "nervy",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "nervy",
        "SelfLoops" : 0,
        "SUID" : 1347,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 269.6286888146926,
        "y" : 336.9727556276757
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1339",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 4,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "happy",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 4,
        "Indegree" : 0,
        "name" : "happy",
        "SelfLoops" : 0,
        "SUID" : 1339,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -157.6560687772718,
        "y" : 176.8636287488215
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1329",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "annoyed",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 0,
        "name" : "annoyed",
        "SelfLoops" : 0,
        "SUID" : 1329,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 321.0518575478667,
        "y" : 96.67584411958023
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1325",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "startled",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "startled",
        "SelfLoops" : 0,
        "SUID" : 1325,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -22.965630661172785,
        "y" : -477.54466957948284
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1321",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "daytime",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "daytime",
        "SelfLoops" : 0,
        "SUID" : 1321,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -291.69501119990724,
        "y" : 378.95779062133147
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1313",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 6,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "suspicious",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 6,
        "Indegree" : 0,
        "name" : "suspicious",
        "SelfLoops" : 0,
        "SUID" : 1313,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 135.01147770161413,
        "y" : 134.22536020853693
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1299",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "tweedy",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "tweedy",
        "SelfLoops" : 0,
        "SUID" : 1299,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 421.715137119371,
        "y" : -317.0307294260042
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1293",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "satisfied",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "satisfied",
        "SelfLoops" : 0,
        "SUID" : 1293,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 73.75420831141571,
        "y" : -472.63959449661405
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1285",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "strategic",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 0,
        "name" : "strategic",
        "SelfLoops" : 0,
        "SUID" : 1285,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 175.23617764552853,
        "y" : 285.51347888432895
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1281",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "critical",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "critical",
        "SelfLoops" : 0,
        "SUID" : 1281,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -373.8247400172153,
        "y" : -72.70380333957974
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1277",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "concerned",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "concerned",
        "SelfLoops" : 0,
        "SUID" : 1277,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -413.90553216317886,
        "y" : -397.4499865463529
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1267",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "heraldic",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 0,
        "name" : "heraldic",
        "SelfLoops" : 0,
        "SUID" : 1267,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 303.6364138017692,
        "y" : -141.27071947832258
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1263",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "disappointed",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "disappointed",
        "SelfLoops" : 0,
        "SUID" : 1263,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -505.4652298333497,
        "y" : 144.65023567276364
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1259",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "headed",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "headed",
        "SelfLoops" : 0,
        "SUID" : 1259,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 477.4495925559387,
        "y" : -47.95229146811323
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1253",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "abnormal",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "abnormal",
        "SelfLoops" : 0,
        "SUID" : 1253,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 188.02158263662352,
        "y" : -387.31034420457854
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1247",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "catholic",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "catholic",
        "SelfLoops" : 0,
        "SUID" : 1247,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 355.52390612859176,
        "y" : -142.9321586604657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1241",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "normal",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "normal",
        "SelfLoops" : 0,
        "SUID" : 1241,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 557.7997649828488,
        "y" : 145.37716040441921
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1231",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "mammoth",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "mammoth",
        "SelfLoops" : 0,
        "SUID" : 1231,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -467.55468625770305,
        "y" : 96.81703917315474
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1225",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "dumb",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 0,
        "name" : "dumb",
        "SelfLoops" : 0,
        "SUID" : 1225,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -283.3794592679173,
        "y" : -23.811564275278897
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1221",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "busy",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 0,
        "name" : "busy",
        "SelfLoops" : 0,
        "SUID" : 1221,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 85.73955877476726,
        "y" : 323.54541809715965
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1211",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "least",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 0,
        "name" : "least",
        "SelfLoops" : 0,
        "SUID" : 1211,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 239.5302811211585,
        "y" : 299.2848900121837
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1207",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "heavy",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 0,
        "name" : "heavy",
        "SelfLoops" : 0,
        "SUID" : 1207,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -35.499820657398914,
        "y" : 380.8680264280681
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1203",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 12,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "cool",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 12,
        "Indegree" : 0,
        "name" : "cool",
        "SelfLoops" : 0,
        "SUID" : 1203,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -23.25856147816353,
        "y" : 139.10805805741256
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1189",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "rude",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "rude",
        "SelfLoops" : 0,
        "SUID" : 1189,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 305.6177263572747,
        "y" : -303.87143056541305
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1183",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "darn",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "darn",
        "SelfLoops" : 0,
        "SUID" : 1183,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 370.95204536662663,
        "y" : -96.45974204526442
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1179",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "miserable",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "miserable",
        "SelfLoops" : 0,
        "SUID" : 1179,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 416.4585689542413,
        "y" : -397.4499865463464
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1169",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 21,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "other",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 21,
        "Indegree" : 0,
        "name" : "other",
        "SelfLoops" : 0,
        "SUID" : 1169,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 39.54319957490918,
        "y" : -83.53167343817938
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1155",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "bullshit",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "bullshit",
        "SelfLoops" : 0,
        "SUID" : 1155,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 143.4297707108824,
        "y" : 406.7204322676921
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1141",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "glorious",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "glorious",
        "SelfLoops" : 0,
        "SUID" : 1141,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -353.66276884314567,
        "y" : -388.8800734079982
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1137",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 7,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "proud",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 7,
        "Indegree" : 0,
        "name" : "proud",
        "SelfLoops" : 0,
        "SUID" : 1137,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 50.200940850321444,
        "y" : 183.17718327113198
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1133",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "impressed",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 0,
        "name" : "impressed",
        "SelfLoops" : 0,
        "SUID" : 1133,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -331.76657836798,
        "y" : -23.905835468204828
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1127",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "popular",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 3,
        "Indegree" : 0,
        "name" : "popular",
        "SelfLoops" : 0,
        "SUID" : 1127,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 74.67701557363728,
        "y" : -225.33262532428375
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1117",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "dangerous",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "dangerous",
        "SelfLoops" : 0,
        "SUID" : 1117,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -300.2417802004354,
        "y" : -489.2270566286885
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1113",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 8,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "long",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 8,
        "Indegree" : 0,
        "name" : "long",
        "SelfLoops" : 0,
        "SUID" : 1113,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 71.68955904426866,
        "y" : -121.45046996095971
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1097",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "excited",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 3,
        "Indegree" : 0,
        "name" : "excited",
        "SelfLoops" : 0,
        "SUID" : 1097,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -215.60164220156736,
        "y" : -96.1646963509778
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1089",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "third",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 0,
        "name" : "third",
        "SelfLoops" : 0,
        "SUID" : 1089,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -275.18327884060153,
        "y" : -71.56208836502856
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1081",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 11,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "second",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 11,
        "Indegree" : 0,
        "name" : "second",
        "SelfLoops" : 0,
        "SUID" : 1081,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 71.6504955133205,
        "y" : 122.41257691189628
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1077",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "sweet",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 3,
        "Indegree" : 0,
        "name" : "sweet",
        "SelfLoops" : 0,
        "SUID" : 1077,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 190.0051687724075,
        "y" : -214.0065749127831
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1061",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "throbbing",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "throbbing",
        "SelfLoops" : 0,
        "SUID" : 1061,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 365.70954670160995,
        "y" : -228.51867123566598
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1055",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "prone",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "prone",
        "SelfLoops" : 0,
        "SUID" : 1055,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 380.31141717180526,
        "y" : 49.33563961320101
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1051",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 5,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "ill",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 5,
        "Indegree" : 0,
        "name" : "ill",
        "SelfLoops" : 0,
        "SUID" : 1051,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 1.3186821088419265,
        "y" : -188.6745947014091
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1045",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "absent",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "absent",
        "SelfLoops" : 0,
        "SUID" : 1045,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -233.5625454848756,
        "y" : -471.15063991257347
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1041",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "mistaken",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "mistaken",
        "SelfLoops" : 0,
        "SUID" : 1041,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -95.53266168353821,
        "y" : 518.3531490151618
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1035",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "confident",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 0,
        "name" : "confident",
        "SelfLoops" : 0,
        "SUID" : 1035,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -59.37819049883433,
        "y" : -327.9093953495716
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1031",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "short",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 0,
        "name" : "short",
        "SelfLoops" : 0,
        "SUID" : 1031,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 331.6518451179594,
        "y" : -48.151393891446446
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1027",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "clean",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 0,
        "name" : "clean",
        "SelfLoops" : 0,
        "SUID" : 1027,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -230.49841072919742,
        "y" : 240.8699792131822
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1023",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "tough",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 0,
        "name" : "tough",
        "SelfLoops" : 0,
        "SUID" : 1023,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 107.77023672560665,
        "y" : -264.62963250330375
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1017",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "exemplary",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "exemplary",
        "SelfLoops" : 0,
        "SUID" : 1017,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 477.73531964557344,
        "y" : -321.56016586004597
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1007",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "passing",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 0,
        "name" : "passing",
        "SelfLoops" : 0,
        "SUID" : 1007,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 321.0518575478676,
        "y" : -95.73628932689553
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "989",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "realistic",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "realistic",
        "SelfLoops" : 0,
        "SUID" : 989,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -538.5211536967142,
        "y" : 312.12210868673014
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "977",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 4,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "suburban",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 4,
        "Indegree" : 0,
        "name" : "suburban",
        "SelfLoops" : 0,
        "SUID" : 977,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 26.047108911167243,
        "y" : 236.6069746057326
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "971",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "light",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 3,
        "Indegree" : 0,
        "name" : "light",
        "SelfLoops" : 0,
        "SUID" : 971,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -23.500545204094465,
        "y" : -235.66674070236627
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "965",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 5,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "small",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 5,
        "Indegree" : 0,
        "name" : "small",
        "SelfLoops" : 0,
        "SUID" : 965,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -181.40149723854643,
        "y" : -48.56427075418037
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "961",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "modest",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "modest",
        "SelfLoops" : 0,
        "SUID" : 961,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -94.4972623669778,
        "y" : 420.0821278409983
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "955",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "crisp",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "crisp",
        "SelfLoops" : 0,
        "SUID" : 955,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -213.14554730238217,
        "y" : -533.1400532703954
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "951",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "matted",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "matted",
        "SelfLoops" : 0,
        "SUID" : 951,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 416.45856895423765,
        "y" : 398.3895413390319
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "945",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "dusty",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 0,
        "name" : "dusty",
        "SelfLoops" : 0,
        "SUID" : 945,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -83.84953287519443,
        "y" : 373.0404181822114
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "939",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "familiar",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 0,
        "name" : "familiar",
        "SelfLoops" : 0,
        "SUID" : 939,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -193.02592051183382,
        "y" : -271.1152682873281
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "935",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "single",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "single",
        "SelfLoops" : 0,
        "SUID" : 935,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -438.5631227455204,
        "y" : 189.21983273250078
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "931",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "mint",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "mint",
        "SelfLoops" : 0,
        "SUID" : 931,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 431.6799822840461,
        "y" : 0.4697773963407599
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "927",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 4,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "obvious",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 4,
        "Indegree" : 0,
        "name" : "obvious",
        "SelfLoops" : 0,
        "SUID" : 927,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -117.5019038373365,
        "y" : 206.05685012289155
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "923",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 5,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "hard",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 5,
        "Indegree" : 0,
        "name" : "hard",
        "SelfLoops" : 0,
        "SUID" : 923,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -162.49000622001273,
        "y" : -94.1670055655618
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "919",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "stiff",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 0,
        "name" : "stiff",
        "SelfLoops" : 0,
        "SUID" : 919,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 279.77669382728425,
        "y" : 184.72375181434518
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "915",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "sticky",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "sticky",
        "SelfLoops" : 0,
        "SUID" : 915,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -142.90393988089482,
        "y" : -506.27197083253714
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "909",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "likely",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 0,
        "name" : "likely",
        "SelfLoops" : 0,
        "SUID" : 909,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -151.41221114738266,
        "y" : -296.51174841784433
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "905",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "insensitive",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "insensitive",
        "SelfLoops" : 0,
        "SUID" : 905,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 441.11615953657736,
        "y" : 189.21983273249919
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "901",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "wicked",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 0,
        "name" : "wicked",
        "SelfLoops" : 0,
        "SUID" : 901,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 331.65184511795894,
        "y" : 49.09094868413149
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "897",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "gross",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "gross",
        "SelfLoops" : 0,
        "SUID" : 897,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -185.46854584557093,
        "y" : 388.24989899725847
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "893",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "much",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 3,
        "Indegree" : 0,
        "name" : "much",
        "SelfLoops" : 0,
        "SUID" : 893,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 151.03941660083888,
        "y" : -242.81952260275807
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "889",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "damaging",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "damaging",
        "SelfLoops" : 0,
        "SUID" : 889,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 543.5058790313429,
        "y" : -191.11204352312245
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "885",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "crumpled",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "crumpled",
        "SelfLoops" : 0,
        "SUID" : 885,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -378.6638806208709,
        "y" : 432.16592845354126
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "881",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 8,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "blue",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 8,
        "Indegree" : 0,
        "name" : "blue",
        "SelfLoops" : 0,
        "SUID" : 881,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -139.51598143496778,
        "y" : 0.3473006787041868
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "875",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "pink",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 0,
        "name" : "pink",
        "SelfLoops" : 0,
        "SUID" : 875,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -289.93037440869006,
        "y" : -162.96345174529438
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "871",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "petite",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "petite",
        "SelfLoops" : 0,
        "SUID" : 871,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -418.3358320491295,
        "y" : 96.24355815884655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "865",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "bumpy",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "bumpy",
        "SelfLoops" : 0,
        "SUID" : 865,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -227.71193023647373,
        "y" : 364.9028057024258
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "861",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "rapid",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "rapid",
        "SelfLoops" : 0,
        "SUID" : 861,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -622.0281441852508,
        "y" : 0.4697773963405325
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "857",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "nitrous",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "nitrous",
        "SelfLoops" : 0,
        "SUID" : 857,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 557.7997649828504,
        "y" : -144.43760561173178
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "853",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 8,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "real",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 8,
        "Indegree" : 0,
        "name" : "real",
        "SelfLoops" : 0,
        "SUID" : 853,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -106.52018132222975,
        "y" : -90.09740506522246
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "849",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "imaginary",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "imaginary",
        "SelfLoops" : 0,
        "SUID" : 849,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 508.0182666244076,
        "y" : -143.71068088007678
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "843",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "cheery",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "cheery",
        "SelfLoops" : 0,
        "SUID" : 843,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 212.06182663530467,
        "y" : -429.2452992983828
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "839",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "weary",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 3,
        "Indegree" : 0,
        "name" : "weary",
        "SelfLoops" : 0,
        "SUID" : 839,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 151.03941660083808,
        "y" : 243.75907739544016
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "827",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "empty",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 3,
        "Indegree" : 0,
        "name" : "empty",
        "SelfLoops" : 0,
        "SUID" : 827,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 270.64347098879637,
        "y" : 95.6540934548268
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "823",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 9,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "last",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 9,
        "Indegree" : 0,
        "name" : "last",
        "SelfLoops" : 0,
        "SUID" : 823,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 133.57971429471274,
        "y" : -47.68006542716694
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "819",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "pristine",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "pristine",
        "SelfLoops" : 0,
        "SUID" : 819,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 98.08569847459421,
        "y" : -517.4135942224801
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "815",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "yellow",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "yellow",
        "SelfLoops" : 0,
        "SUID" : 815,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -189.04512124482648,
        "y" : 491.7465603114972
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "811",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "dirty",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 0,
        "name" : "dirty",
        "SelfLoops" : 0,
        "SUID" : 811,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -263.03102072836,
        "y" : -203.62186762281232
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "799",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "tight",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 0,
        "name" : "tight",
        "SelfLoops" : 0,
        "SUID" : 799,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -235.40296368972236,
        "y" : -159.53469733097256
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "793",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 18,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "sorry",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 18,
        "Indegree" : 0,
        "name" : "sorry",
        "SelfLoops" : 0,
        "SUID" : 793,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -11.947904842929235,
        "y" : -90.88501044096347
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "783",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "weak",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "weak",
        "SelfLoops" : 0,
        "SUID" : 783,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -233.5625454848709,
        "y" : 472.09019470525755
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "779",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "random",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "random",
        "SelfLoops" : 0,
        "SUID" : 779,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 294.24804799095796,
        "y" : -378.0182358286542
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "771",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "dreary",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "dreary",
        "SelfLoops" : 0,
        "SUID" : 771,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 420.88886884018586,
        "y" : 96.24355815884655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "765",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "prime",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "prime",
        "SelfLoops" : 0,
        "SUID" : 765,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 1.2765183955278872,
        "y" : -622.834885184438
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "761",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 4,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "modern",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 4,
        "Indegree" : 0,
        "name" : "modern",
        "SelfLoops" : 0,
        "SUID" : 761,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 160.13172415145448,
        "y" : 176.93331942313728
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "757",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "sleek",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "sleek",
        "SelfLoops" : 0,
        "SUID" : 757,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -446.15578751734347,
        "y" : 361.746133207003
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "753",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "rich",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "rich",
        "SelfLoops" : 0,
        "SUID" : 753,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 525.8831150781731,
        "y" : -48.142182694891744
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "749",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "full",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 3,
        "Indegree" : 0,
        "name" : "full",
        "SelfLoops" : 0,
        "SUID" : 749,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 250.6801348572186,
        "y" : 139.81268273685612
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "745",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "strong",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "strong",
        "SelfLoops" : 0,
        "SUID" : 745,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 294.2480479909641,
        "y" : 378.957790621331
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "741",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 8,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "young",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 8,
        "Indegree" : 0,
        "name" : "young",
        "SelfLoops" : 0,
        "SUID" : 741,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -132.54554658964724,
        "y" : 134.13821120602643
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "737",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "loose",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 3,
        "Indegree" : 0,
        "name" : "loose",
        "SelfLoops" : 0,
        "SUID" : 737,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -236.156318339983,
        "y" : 0.39167407458057824
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "733",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "easy",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 3,
        "Indegree" : 0,
        "name" : "easy",
        "SelfLoops" : 0,
        "SUID" : 733,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -82.43406447631912,
        "y" : 273.6201892359743
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "725",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "bored",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 3,
        "Indegree" : 0,
        "name" : "bored",
        "SelfLoops" : 0,
        "SUID" : 725,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 61.42516710080042,
        "y" : 279.75591960865245
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "721",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 10,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "great",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 10,
        "Indegree" : 0,
        "name" : "great",
        "SelfLoops" : 0,
        "SUID" : 721,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 133.57751045673217,
        "y" : 48.625675360014384
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "715",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "possible",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 0,
        "name" : "possible",
        "SelfLoops" : 0,
        "SUID" : 715,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -151.41221114738403,
        "y" : 297.4513032105251
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "705",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 4,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "own",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 4,
        "Indegree" : 0,
        "name" : "own",
        "SelfLoops" : 0,
        "SUID" : 705,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -72.15492705057238,
        "y" : 226.2621175677848
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "701",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "legit",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "legit",
        "SelfLoops" : 0,
        "SUID" : 701,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 541.0741904877704,
        "y" : 312.12210868673014
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "697",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 10,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "sure",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 10,
        "Indegree" : 0,
        "name" : "sure",
        "SelfLoops" : 0,
        "SUID" : 697,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 109.12298090116678,
        "y" : 90.97769712763488
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "693",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "kinda",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "kinda",
        "SelfLoops" : 0,
        "SUID" : 693,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -475.1822828545148,
        "y" : 322.49972065273073
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "689",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "conditioned",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "conditioned",
        "SelfLoops" : 0,
        "SUID" : 689,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 525.8831150781726,
        "y" : 49.08173748757645
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "685",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 4,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "aware",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 4,
        "Indegree" : 0,
        "name" : "aware",
        "SelfLoops" : 0,
        "SUID" : 685,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 233.52061990235904,
        "y" : 49.83611588407416
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "675",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "dark",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 3,
        "Indegree" : 0,
        "name" : "dark",
        "SelfLoops" : 0,
        "SUID" : 675,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 120.01548895990243,
        "y" : -205.14008357757598
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "671",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "artificial",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "artificial",
        "SelfLoops" : 0,
        "SUID" : 671,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -175.41836252825095,
        "y" : -338.40224274676797
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "667",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 5,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "whole",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 5,
        "Indegree" : 0,
        "name" : "whole",
        "SelfLoops" : 0,
        "SUID" : 667,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 165.08521924599893,
        "y" : -94.09398310265647
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "661",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "sad",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "sad",
        "SelfLoops" : 0,
        "SUID" : 661,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -500.7758816106513,
        "y" : 280.9330749779972
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "657",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "complete",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 0,
        "name" : "complete",
        "SelfLoops" : 0,
        "SUID" : 657,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -130.80104540145214,
        "y" : 359.09331834421914
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "653",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 8,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "dead",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 8,
        "Indegree" : 0,
        "name" : "dead",
        "SelfLoops" : 0,
        "SUID" : 653,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -23.118935298474184,
        "y" : -138.1931406752559
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "647",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 7,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "only",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 7,
        "Indegree" : 0,
        "name" : "only",
        "SelfLoops" : 0,
        "SUID" : 647,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -93.368670675526,
        "y" : 164.231444033363
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "641",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 15,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "serious",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 15,
        "Indegree" : 0,
        "name" : "serious",
        "SelfLoops" : 0,
        "SUID" : 641,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -87.29203338895354,
        "y" : -25.533958211996378
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "637",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "eighth",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "eighth",
        "SelfLoops" : 0,
        "SUID" : 637,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -565.5308513989387,
        "y" : 97.65866147790848
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "631",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "favorite",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "favorite",
        "SelfLoops" : 0,
        "SUID" : 631,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 215.69858409344192,
        "y" : 534.0796080630753
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "625",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "touchy",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "touchy",
        "SelfLoops" : 0,
        "SUID" : 625,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 519.1598900143487,
        "y" : 97.27895747540822
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "619",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "careful",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 0,
        "name" : "careful",
        "SelfLoops" : 0,
        "SUID" : 619,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -204.96288096472955,
        "y" : -197.2267560189572
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "615",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "guilty",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "guilty",
        "SelfLoops" : 0,
        "SUID" : 615,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -429.12694549298976,
        "y" : 0.4697773963407599
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "611",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "drunk",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 0,
        "name" : "drunk",
        "SelfLoops" : 0,
        "SUID" : 611,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -106.54420660329731,
        "y" : 316.51813772285357
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "605",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "political",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "political",
        "SelfLoops" : 0,
        "SUID" : 605,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -571.7311145183542,
        "y" : 49.239914414513805
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "599",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 8,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "first",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 8,
        "Indegree" : 0,
        "name" : "first",
        "SelfLoops" : 0,
        "SUID" : 599,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -131.07290732244013,
        "y" : 48.49240249316938
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "593",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "different",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 3,
        "Indegree" : 0,
        "name" : "different",
        "SelfLoops" : 0,
        "SUID" : 593,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -230.98516062807033,
        "y" : 49.753349887990225
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "589",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "fascist",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "fascist",
        "SelfLoops" : 0,
        "SUID" : 589,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -251.90087183584654,
        "y" : -405.715774272007
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "581",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "european",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 3,
        "Indegree" : 0,
        "name" : "european",
        "SelfLoops" : 0,
        "SUID" : 581,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -127.3972027948895,
        "y" : 255.54169401578463
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "577",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "pebbled",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "pebbled",
        "SelfLoops" : 0,
        "SUID" : 577,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -386.50360320538954,
        "y" : 187.2148416374398
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "569",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 23,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "sick",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 23,
        "Indegree" : 0,
        "name" : "sick",
        "SelfLoops" : 0,
        "SUID" : 569,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 93.58352046356572,
        "y" : 0.4697773963407599
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "565",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "ninth",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 0,
        "name" : "ninth",
        "SelfLoops" : 0,
        "SUID" : 565,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -255.74481754505737,
        "y" : 283.3042870514687
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "557",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 16,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "high",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 16,
        "Indegree" : 0,
        "name" : "high",
        "SelfLoops" : 0,
        "SUID" : 557,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -59.21390373505119,
        "y" : -69.25461906037322
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "553",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "childish",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "childish",
        "SelfLoops" : 0,
        "SUID" : 553,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 25.5186674522231,
        "y" : 478.4842243721646
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "549",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "stupid",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 0,
        "name" : "stupid",
        "SelfLoops" : 0,
        "SUID" : 549,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 214.88504937928144,
        "y" : 257.14714354947967
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "543",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 6,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "new",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 6,
        "Indegree" : 0,
        "name" : "new",
        "SelfLoops" : 0,
        "SUID" : 543,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 165.07549246155554,
        "y" : 95.05038518116953
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "537",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "nervous",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 0,
        "name" : "nervous",
        "SelfLoops" : 0,
        "SUID" : 537,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 307.5430595957679,
        "y" : 229.06578068988415
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "533",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "pretty",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "pretty",
        "SelfLoops" : 0,
        "SUID" : 533,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -555.2467281917932,
        "y" : 145.37716040441717
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "529",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "specific",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 0,
        "name" : "specific",
        "SelfLoops" : 0,
        "SUID" : 529,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 85.73955877476953,
        "y" : -322.60586330447757
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "525",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "-",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 0,
        "name" : "-",
        "SelfLoops" : 0,
        "SUID" : 525,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -319.0894439253672,
        "y" : 208.84678468540483
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "521",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "non",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "non",
        "SelfLoops" : 0,
        "SUID" : 521,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -22.965630661166873,
        "y" : 478.4842243721646
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "515",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "physical",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "physical",
        "SelfLoops" : 0,
        "SUID" : 515,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 305.61772635727834,
        "y" : 304.810985358091
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "509",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 8,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "beautiful",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 8,
        "Indegree" : 0,
        "name" : "beautiful",
        "SelfLoops" : 0,
        "SUID" : 509,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -106.67758853934652,
        "y" : 90.84927620530834
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "505",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 14,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "bad",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 14,
        "Indegree" : 0,
        "name" : "bad",
        "SelfLoops" : 0,
        "SUID" : 505,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -59.26665641214992,
        "y" : 70.14837249552204
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "501",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "incredible",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 3,
        "Indegree" : 0,
        "name" : "incredible",
        "SelfLoops" : 0,
        "SUID" : 501,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 223.54039203364857,
        "y" : -179.0222270169017
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "497",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "brilliant",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "brilliant",
        "SelfLoops" : 0,
        "SUID" : 497,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 492.5533013106841,
        "y" : 190.79141703669666
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "493",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 25,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "little",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 25,
        "Indegree" : 0,
        "name" : "little",
        "SelfLoops" : 0,
        "SUID" : 493,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 78.89534207222323,
        "y" : 50.42876899780151
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "489",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "sly",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "sly",
        "SelfLoops" : 0,
        "SUID" : 489,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -71.20117152036596,
        "y" : 473.5791492892947
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "485",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "glassy",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "glassy",
        "SelfLoops" : 0,
        "SUID" : 485,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -46.913379951800835,
        "y" : -427.2273998500245
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "481",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 12,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "well",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 12,
        "Indegree" : 0,
        "name" : "well",
        "SelfLoops" : 0,
        "SUID" : 481,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 25.672027778622578,
        "y" : 139.13268567034845
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "477",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "pathetic",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "pathetic",
        "SelfLoops" : 0,
        "SUID" : 477,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -565.5308513989378,
        "y" : -96.71910668523185
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "473",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "special",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 0,
        "name" : "special",
        "SelfLoops" : 0,
        "SUID" : 473,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 334.26454725733413,
        "y" : 188.01790352739238
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "469",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "such",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "such",
        "SelfLoops" : 0,
        "SUID" : 469,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -523.3300782871161,
        "y" : 49.08173748757963
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "465",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 9,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "nice",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 9,
        "Indegree" : 0,
        "name" : "nice",
        "SelfLoops" : 0,
        "SUID" : 465,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 142.06907149783717,
        "y" : 0.4697773963407599
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "457",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 4,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "alright",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 4,
        "Indegree" : 0,
        "name" : "alright",
        "SelfLoops" : 0,
        "SUID" : 457,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 218.17851325972765,
        "y" : 97.05074179580947
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "451",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 6,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "huge",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 6,
        "Indegree" : 0,
        "name" : "huge",
        "SelfLoops" : 0,
        "SUID" : 451,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 190.42089519280626,
        "y" : 0.4697773963407599
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "447",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "syphilitic",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "syphilitic",
        "SelfLoops" : 0,
        "SUID" : 447,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 62.327929441330525,
        "y" : -376.7941251836124
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "443",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 15,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "right",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 15,
        "Indegree" : 0,
        "name" : "right",
        "SelfLoops" : 0,
        "SUID" : 443,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -87.30780125332251,
        "y" : 26.419747399000926
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "439",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "myocardial",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "myocardial",
        "SelfLoops" : 0,
        "SUID" : 439,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -23.130541699550353,
        "y" : 575.0309743630842
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "435",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "fit",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "fit",
        "SelfLoops" : 0,
        "SUID" : 435,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 390.62636919987096,
        "y" : -354.4695098423289
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "431",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "thankful",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "thankful",
        "SelfLoops" : 0,
        "SUID" : 431,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -470.3438989133867,
        "y" : 235.30884127674358
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "427",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "upset",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 0,
        "name" : "upset",
        "SelfLoops" : 0,
        "SUID" : 427,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -106.54420660329572,
        "y" : -315.5785829301726
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "423",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "unfair",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "unfair",
        "SelfLoops" : 0,
        "SUID" : 423,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -418.3358320491295,
        "y" : -95.30400336616503
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "419",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "angry",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 3,
        "Indegree" : 0,
        "name" : "angry",
        "SelfLoops" : 0,
        "SUID" : 419,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 238.70936797704815,
        "y" : 0.4697773963407599
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "415",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "enough",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 0,
        "name" : "enough",
        "SelfLoops" : 0,
        "SUID" : 415,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -82.37944146895813,
        "y" : -272.6973684174582
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "409",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 5,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "major",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 5,
        "Indegree" : 0,
        "name" : "major",
        "SelfLoops" : 0,
        "SUID" : 409,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 135.0344037560293,
        "y" : -133.26287896670988
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "405",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 8,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "cute",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 8,
        "Indegree" : 0,
        "name" : "cute",
        "SelfLoops" : 0,
        "SUID" : 405,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 25.760877340496677,
        "y" : -138.17746987572184
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "399",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 8,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "okay",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 8,
        "Indegree" : 0,
        "name" : "okay",
        "SelfLoops" : 0,
        "SUID" : 399,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -130.98915641198482,
        "y" : -47.783038861156456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "395",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "fruitful",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "fruitful",
        "SelfLoops" : 0,
        "SUID" : 395,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 441.11615953657395,
        "y" : -188.28027793982562
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "391",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 29,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "good",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 29,
        "Indegree" : 0,
        "name" : "good",
        "SelfLoops" : 0,
        "SUID" : 391,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 39.46726727910459,
        "y" : 84.50577760161173
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "387",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 5,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "fine",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 5,
        "Indegree" : 0,
        "name" : "fine",
        "SelfLoops" : 0,
        "SUID" : 387,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -93.24510711566484,
        "y" : -163.36323998645844
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "383",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "raspy",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "raspy",
        "SelfLoops" : 0,
        "SUID" : 383,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 156.0163834873474,
        "y" : -348.973924982033
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "379",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "choked",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "choked",
        "SelfLoops" : 0,
        "SUID" : 379,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 260.17940114394696,
        "y" : -513.0334562321342
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "375",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "clammy",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 0,
        "name" : "clammy",
        "SelfLoops" : 0,
        "SUID" : 375,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -168.5915079488678,
        "y" : -229.23321082707236
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "371",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 4,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "cold",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 4,
        "Indegree" : 0,
        "name" : "cold",
        "SelfLoops" : 0,
        "SUID" : 371,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -162.5840418799438,
        "y" : 94.94364711828666
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "367",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "lifeless",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 3,
        "Indegree" : 0,
        "name" : "lifeless",
        "SelfLoops" : 0,
        "SUID" : 367,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 13.355254272964544,
        "y" : 285.904031319217
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "361",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "middle",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 0,
        "name" : "middle",
        "SelfLoops" : 0,
        "SUID" : 361,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -259.03632219764177,
        "y" : -117.24103007358008
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "357",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "upper",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "upper",
        "SelfLoops" : 0,
        "SUID" : 357,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 49.466416742852175,
        "y" : -427.227399850025
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "353",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "early",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "early",
        "SelfLoops" : 0,
        "SUID" : 353,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -373.873749964029,
        "y" : 73.39167486405768
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "349",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "late",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 3,
        "Indegree" : 0,
        "name" : "late",
        "SelfLoops" : 0,
        "SUID" : 349,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 286.9662262481314,
        "y" : 0.4697773963407599
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "345",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "dry",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 0,
        "name" : "dry",
        "SelfLoops" : 0,
        "SUID" : 345,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 199.3561036296461,
        "y" : 327.30276975485356
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "341",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "fat",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 0,
        "name" : "fat",
        "SelfLoops" : 0,
        "SUID" : 341,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 249.98122613161547,
        "y" : -222.37062099285833
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "333",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 6,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "close",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 6,
        "Indegree" : 0,
        "name" : "close",
        "SelfLoops" : 0,
        "SUID" : 333,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 183.97469865984135,
        "y" : 49.42863974157126
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "327",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 8,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "wrong",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 8,
        "Indegree" : 0,
        "name" : "wrong",
        "SelfLoops" : 0,
        "SUID" : 327,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -69.05833286525967,
        "y" : -121.49559353815607
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "323",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 7,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "worried",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 7,
        "Indegree" : 0,
        "name" : "worried",
        "SelfLoops" : 0,
        "SUID" : 323,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 1.2278880498347462,
        "y" : 189.61414794201744
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "319",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "breathless",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "breathless",
        "SelfLoops" : 0,
        "SUID" : 319,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 199.42736562631444,
        "y" : -326.32001547097246
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "315",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 14,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "open",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 14,
        "Indegree" : 0,
        "name" : "open",
        "SelfLoops" : 0,
        "SUID" : 315,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -12.058116677157502,
        "y" : 91.80854319852915
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "311",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "tense",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "tense",
        "SelfLoops" : 0,
        "SUID" : 311,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -213.14554730238677,
        "y" : 534.0796080630748
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "305",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 14,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "big",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 14,
        "Indegree" : 0,
        "name" : "big",
        "SelfLoops" : 0,
        "SUID" : 305,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -69.23693505750714,
        "y" : 122.3319778162952
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "301",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "sadistic",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "sadistic",
        "SelfLoops" : 0,
        "SUID" : 301,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 25.518667452216732,
        "y" : -477.54466957948347
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "293",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 23,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "old",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 23,
        "Indegree" : 0,
        "name" : "old",
        "SelfLoops" : 0,
        "SUID" : 293,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 78.90286361246365,
        "y" : -49.47752642528553
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "289",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "aural",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "aural",
        "SelfLoops" : 0,
        "SUID" : 289,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -380.102056734029,
        "y" : -24.141386994819186
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "285",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "ready",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 0,
        "name" : "ready",
        "SelfLoops" : 0,
        "SUID" : 285,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : -343.1091937808125,
        "y" : 166.16168495170268
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "281",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "silent",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 3,
        "Indegree" : 0,
        "name" : "silent",
        "SelfLoops" : 0,
        "SUID" : 281,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 190.0051687724066,
        "y" : 214.9461297054654
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "277",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 183,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "ferris",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1147,
        "Indegree" : 1144,
        "name" : "ferris",
        "SelfLoops" : 3,
        "SUID" : 277,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 1.0
      },
      "position" : {
        "x" : 1.2765183955281145,
        "y" : 0.4697773963407599
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "275",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 9,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "black",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 9,
        "Indegree" : 0,
        "name" : "black",
        "SelfLoops" : 0,
        "SUID" : 275,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 484.0
      },
      "position" : {
        "x" : 109.13540685658563,
        "y" : -90.02333388298075
      },
      "selected" : false
    } ],
    "edges" : [ {
      "data" : {
        "id" : "3519",
        "source" : "3517",
        "target" : "277",
        "EdgeBetweenness" : 270.0,
        "shared_name" : "hideous (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "hideous (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3519,
        "BEND_MAP_ID" : 3519,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3499",
        "source" : "3497",
        "target" : "277",
        "EdgeBetweenness" : 280.0,
        "shared_name" : "gasp (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "gasp (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3499,
        "BEND_MAP_ID" : 3499,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3495",
        "source" : "3493",
        "target" : "277",
        "EdgeBetweenness" : 284.0,
        "shared_name" : "deathly (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "deathly (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3495,
        "BEND_MAP_ID" : 3495,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3485",
        "source" : "3483",
        "target" : "277",
        "EdgeBetweenness" : 289.0,
        "shared_name" : "sickly (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "sickly (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3485,
        "BEND_MAP_ID" : 3485,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3471",
        "source" : "3469",
        "target" : "277",
        "EdgeBetweenness" : 297.0,
        "shared_name" : "orange (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "orange (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3471,
        "BEND_MAP_ID" : 3471,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3455",
        "source" : "3453",
        "target" : "277",
        "EdgeBetweenness" : 307.0,
        "shared_name" : "dejected (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "dejected (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3455,
        "BEND_MAP_ID" : 3455,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3449",
        "source" : "3447",
        "target" : "277",
        "EdgeBetweenness" : 311.0,
        "shared_name" : "dumbfounded (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "dumbfounded (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3449,
        "BEND_MAP_ID" : 3449,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3437",
        "source" : "3435",
        "target" : "277",
        "EdgeBetweenness" : 318.0,
        "shared_name" : "key (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "key (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3437,
        "BEND_MAP_ID" : 3437,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3433",
        "source" : "3431",
        "target" : "277",
        "EdgeBetweenness" : 321.0,
        "shared_name" : "omnious (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "omnious (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3433,
        "BEND_MAP_ID" : 3433,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3421",
        "source" : "3419",
        "target" : "277",
        "EdgeBetweenness" : 329.0,
        "shared_name" : "worthy (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "worthy (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3421,
        "BEND_MAP_ID" : 3421,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3415",
        "source" : "3413",
        "target" : "277",
        "EdgeBetweenness" : 334.0,
        "shared_name" : "typewritten (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "typewritten (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3415,
        "BEND_MAP_ID" : 3415,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3411",
        "source" : "3409",
        "target" : "277",
        "EdgeBetweenness" : 335.0,
        "shared_name" : "significant (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "significant (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3411,
        "BEND_MAP_ID" : 3411,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3385",
        "source" : "3383",
        "target" : "277",
        "EdgeBetweenness" : 349.0,
        "shared_name" : "back (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "back (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3385,
        "BEND_MAP_ID" : 3385,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3379",
        "source" : "3377",
        "target" : "277",
        "EdgeBetweenness" : 352.0,
        "shared_name" : "hi (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "hi (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3379,
        "BEND_MAP_ID" : 3379,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3365",
        "source" : "3357",
        "target" : "277",
        "EdgeBetweenness" : 364.0,
        "shared_name" : "juvenile (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "juvenile (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3365,
        "BEND_MAP_ID" : 3365,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3359",
        "source" : "3357",
        "target" : "277",
        "EdgeBetweenness" : 364.0,
        "shared_name" : "juvenile (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "juvenile (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3359,
        "BEND_MAP_ID" : 3359,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3351",
        "source" : "3349",
        "target" : "277",
        "EdgeBetweenness" : 367.0,
        "shared_name" : "impish (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "impish (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3351,
        "BEND_MAP_ID" : 3351,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3333",
        "source" : "3331",
        "target" : "277",
        "EdgeBetweenness" : 375.0,
        "shared_name" : "brief (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "brief (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3333,
        "BEND_MAP_ID" : 3333,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3329",
        "source" : "3327",
        "target" : "277",
        "EdgeBetweenness" : 378.0,
        "shared_name" : "wooded (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "wooded (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3329,
        "BEND_MAP_ID" : 3329,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3323",
        "source" : "3321",
        "target" : "277",
        "EdgeBetweenness" : 380.0,
        "shared_name" : "impending (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "impending (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3323,
        "BEND_MAP_ID" : 3323,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3319",
        "source" : "3317",
        "target" : "277",
        "EdgeBetweenness" : 381.0,
        "shared_name" : "placcid (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "placcid (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3319,
        "BEND_MAP_ID" : 3319,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3315",
        "source" : "3313",
        "target" : "277",
        "EdgeBetweenness" : 384.0,
        "shared_name" : "unmanned (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "unmanned (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3315,
        "BEND_MAP_ID" : 3315,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3309",
        "source" : "3307",
        "target" : "277",
        "EdgeBetweenness" : 388.0,
        "shared_name" : "mighty (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "mighty (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3309,
        "BEND_MAP_ID" : 3309,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3303",
        "source" : "3301",
        "target" : "277",
        "EdgeBetweenness" : 390.0,
        "shared_name" : "u-2 (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "u-2 (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3303,
        "BEND_MAP_ID" : 3303,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3287",
        "source" : "3283",
        "target" : "277",
        "EdgeBetweenness" : 396.0,
        "shared_name" : "generic (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "generic (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3287,
        "BEND_MAP_ID" : 3287,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3285",
        "source" : "3283",
        "target" : "277",
        "EdgeBetweenness" : 396.0,
        "shared_name" : "generic (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "generic (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3285,
        "BEND_MAP_ID" : 3285,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3277",
        "source" : "3273",
        "target" : "277",
        "EdgeBetweenness" : 401.0,
        "shared_name" : "naked (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "naked (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3277,
        "BEND_MAP_ID" : 3277,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3275",
        "source" : "3273",
        "target" : "277",
        "EdgeBetweenness" : 401.0,
        "shared_name" : "naked (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "naked (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3275,
        "BEND_MAP_ID" : 3275,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3271",
        "source" : "3269",
        "target" : "277",
        "EdgeBetweenness" : 404.0,
        "shared_name" : "present (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "present (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3271,
        "BEND_MAP_ID" : 3271,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3261",
        "source" : "3259",
        "target" : "277",
        "EdgeBetweenness" : 407.0,
        "shared_name" : "less (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "less (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3261,
        "BEND_MAP_ID" : 3261,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3239",
        "source" : "3237",
        "target" : "277",
        "EdgeBetweenness" : 415.0,
        "shared_name" : "straight (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "straight (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3239,
        "BEND_MAP_ID" : 3239,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3231",
        "source" : "3229",
        "target" : "277",
        "EdgeBetweenness" : 418.0,
        "shared_name" : "wasted (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "wasted (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3231,
        "BEND_MAP_ID" : 3231,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3227",
        "source" : "3225",
        "target" : "277",
        "EdgeBetweenness" : 420.0,
        "shared_name" : "wooden (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "wooden (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3227,
        "BEND_MAP_ID" : 3227,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3457",
        "source" : "3219",
        "target" : "277",
        "EdgeBetweenness" : 422.0,
        "shared_name" : "bewildered (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "bewildered (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3457,
        "BEND_MAP_ID" : 3457,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3369",
        "source" : "3219",
        "target" : "277",
        "EdgeBetweenness" : 422.0,
        "shared_name" : "bewildered (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "bewildered (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3369,
        "BEND_MAP_ID" : 3369,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3325",
        "source" : "3219",
        "target" : "277",
        "EdgeBetweenness" : 422.0,
        "shared_name" : "bewildered (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "bewildered (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3325,
        "BEND_MAP_ID" : 3325,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3221",
        "source" : "3219",
        "target" : "277",
        "EdgeBetweenness" : 422.0,
        "shared_name" : "bewildered (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "bewildered (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3221,
        "BEND_MAP_ID" : 3221,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3199",
        "source" : "3197",
        "target" : "277",
        "EdgeBetweenness" : 428.0,
        "shared_name" : "shitty (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "shitty (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3199,
        "BEND_MAP_ID" : 3199,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3207",
        "source" : "3189",
        "target" : "277",
        "EdgeBetweenness" : 432.0,
        "shared_name" : "catatonic (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "catatonic (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3207,
        "BEND_MAP_ID" : 3207,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3191",
        "source" : "3189",
        "target" : "277",
        "EdgeBetweenness" : 432.0,
        "shared_name" : "catatonic (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "catatonic (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3191,
        "BEND_MAP_ID" : 3191,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3187",
        "source" : "3185",
        "target" : "277",
        "EdgeBetweenness" : 434.0,
        "shared_name" : "wild (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "wild (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3187,
        "BEND_MAP_ID" : 3187,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3183",
        "source" : "3181",
        "target" : "277",
        "EdgeBetweenness" : 438.0,
        "shared_name" : "wet (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "wet (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3183,
        "BEND_MAP_ID" : 3183,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3175",
        "source" : "3173",
        "target" : "277",
        "EdgeBetweenness" : 441.0,
        "shared_name" : "near (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "near (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3175,
        "BEND_MAP_ID" : 3175,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3171",
        "source" : "3169",
        "target" : "277",
        "EdgeBetweenness" : 443.0,
        "shared_name" : "conventional (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "conventional (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3171,
        "BEND_MAP_ID" : 3171,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3139",
        "source" : "3137",
        "target" : "277",
        "EdgeBetweenness" : 453.0,
        "shared_name" : "quiet (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "quiet (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3139,
        "BEND_MAP_ID" : 3139,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3135",
        "source" : "3133",
        "target" : "277",
        "EdgeBetweenness" : 455.0,
        "shared_name" : "rotund (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "rotund (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3135,
        "BEND_MAP_ID" : 3135,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3131",
        "source" : "3129",
        "target" : "277",
        "EdgeBetweenness" : 457.0,
        "shared_name" : "warm (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "warm (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3131,
        "BEND_MAP_ID" : 3131,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3123",
        "source" : "3121",
        "target" : "277",
        "EdgeBetweenness" : 461.0,
        "shared_name" : "myopic (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "myopic (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3123,
        "BEND_MAP_ID" : 3123,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3099",
        "source" : "3097",
        "target" : "277",
        "EdgeBetweenness" : 469.0,
        "shared_name" : "sexy (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "sexy (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3099,
        "BEND_MAP_ID" : 3099,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3089",
        "source" : "3087",
        "target" : "277",
        "EdgeBetweenness" : 474.0,
        "shared_name" : "slack (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "slack (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3089,
        "BEND_MAP_ID" : 3089,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3071",
        "source" : "3069",
        "target" : "277",
        "EdgeBetweenness" : 481.0,
        "shared_name" : "fixable (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "fixable (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3071,
        "BEND_MAP_ID" : 3071,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3059",
        "source" : "3057",
        "target" : "277",
        "EdgeBetweenness" : 484.0,
        "shared_name" : "vacant (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "vacant (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3059,
        "BEND_MAP_ID" : 3059,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3055",
        "source" : "3053",
        "target" : "277",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "mindless (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "mindless (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3055,
        "BEND_MAP_ID" : 3055,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3049",
        "source" : "3047",
        "target" : "277",
        "EdgeBetweenness" : 4.0,
        "shared_name" : "genuine (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "genuine (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3049,
        "BEND_MAP_ID" : 3049,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3045",
        "source" : "3043",
        "target" : "277",
        "EdgeBetweenness" : 5.0,
        "shared_name" : "thundering (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "thundering (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3045,
        "BEND_MAP_ID" : 3045,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3223",
        "source" : "3033",
        "target" : "277",
        "EdgeBetweenness" : 8.0,
        "shared_name" : "funny (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "funny (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3223,
        "BEND_MAP_ID" : 3223,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3035",
        "source" : "3033",
        "target" : "277",
        "EdgeBetweenness" : 8.0,
        "shared_name" : "funny (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "funny (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3035,
        "BEND_MAP_ID" : 3035,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3023",
        "source" : "3021",
        "target" : "277",
        "EdgeBetweenness" : 11.0,
        "shared_name" : "stunning (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "stunning (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3023,
        "BEND_MAP_ID" : 3023,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3011",
        "source" : "3009",
        "target" : "277",
        "EdgeBetweenness" : 17.0,
        "shared_name" : "scorching (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "scorching (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3011,
        "BEND_MAP_ID" : 3011,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3003",
        "source" : "3001",
        "target" : "277",
        "EdgeBetweenness" : 20.0,
        "shared_name" : "protective (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "protective (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3003,
        "BEND_MAP_ID" : 3003,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2999",
        "source" : "2997",
        "target" : "277",
        "EdgeBetweenness" : 23.0,
        "shared_name" : "alone (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "alone (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2999,
        "BEND_MAP_ID" : 2999,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2987",
        "source" : "2985",
        "target" : "277",
        "EdgeBetweenness" : 28.0,
        "shared_name" : "male (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "male (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2987,
        "BEND_MAP_ID" : 2987,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2981",
        "source" : "2979",
        "target" : "277",
        "EdgeBetweenness" : 32.0,
        "shared_name" : "fun (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "fun (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2981,
        "BEND_MAP_ID" : 2981,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2973",
        "source" : "2971",
        "target" : "277",
        "EdgeBetweenness" : 35.0,
        "shared_name" : "curious (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "curious (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2973,
        "BEND_MAP_ID" : 2973,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2953",
        "source" : "2951",
        "target" : "277",
        "EdgeBetweenness" : 43.0,
        "shared_name" : "willing (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "willing (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2953,
        "BEND_MAP_ID" : 2953,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2945",
        "source" : "2943",
        "target" : "277",
        "EdgeBetweenness" : 47.0,
        "shared_name" : "flattered (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "flattered (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2945,
        "BEND_MAP_ID" : 2945,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2941",
        "source" : "2939",
        "target" : "277",
        "EdgeBetweenness" : 50.0,
        "shared_name" : "substantial (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "substantial (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2941,
        "BEND_MAP_ID" : 2941,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2933",
        "source" : "2931",
        "target" : "277",
        "EdgeBetweenness" : 54.0,
        "shared_name" : "fleeting (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "fleeting (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2933,
        "BEND_MAP_ID" : 2933,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2927",
        "source" : "2925",
        "target" : "277",
        "EdgeBetweenness" : 57.0,
        "shared_name" : "broken (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "broken (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2927,
        "BEND_MAP_ID" : 2927,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2923",
        "source" : "2921",
        "target" : "277",
        "EdgeBetweenness" : 59.0,
        "shared_name" : "ceramic (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "ceramic (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2923,
        "BEND_MAP_ID" : 2923,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2919",
        "source" : "2917",
        "target" : "277",
        "EdgeBetweenness" : 61.0,
        "shared_name" : "unconscious (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "unconscious (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2919,
        "BEND_MAP_ID" : 2919,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3251",
        "source" : "2903",
        "target" : "277",
        "EdgeBetweenness" : 68.0,
        "shared_name" : "pissed (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "pissed (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3251,
        "BEND_MAP_ID" : 3251,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2905",
        "source" : "2903",
        "target" : "277",
        "EdgeBetweenness" : 68.0,
        "shared_name" : "pissed (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "pissed (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2905,
        "BEND_MAP_ID" : 2905,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2901",
        "source" : "2899",
        "target" : "277",
        "EdgeBetweenness" : 71.0,
        "shared_name" : "used (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "used (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2901,
        "BEND_MAP_ID" : 2901,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2989",
        "source" : "2895",
        "target" : "277",
        "EdgeBetweenness" : 73.0,
        "shared_name" : "weird (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "weird (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2989,
        "BEND_MAP_ID" : 2989,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2897",
        "source" : "2895",
        "target" : "277",
        "EdgeBetweenness" : 73.0,
        "shared_name" : "weird (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "weird (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2897,
        "BEND_MAP_ID" : 2897,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2891",
        "source" : "2889",
        "target" : "277",
        "EdgeBetweenness" : 76.0,
        "shared_name" : "pleasant (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "pleasant (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2891,
        "BEND_MAP_ID" : 2891,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2887",
        "source" : "2885",
        "target" : "277",
        "EdgeBetweenness" : 79.0,
        "shared_name" : "several (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "several (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2887,
        "BEND_MAP_ID" : 2887,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2881",
        "source" : "2879",
        "target" : "277",
        "EdgeBetweenness" : 80.0,
        "shared_name" : "excellent (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "excellent (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2881,
        "BEND_MAP_ID" : 2881,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2877",
        "source" : "2875",
        "target" : "277",
        "EdgeBetweenness" : 82.0,
        "shared_name" : "facinating (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "facinating (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2877,
        "BEND_MAP_ID" : 2877,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2873",
        "source" : "2871",
        "target" : "277",
        "EdgeBetweenness" : 85.0,
        "shared_name" : "steamy (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "steamy (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2873,
        "BEND_MAP_ID" : 2873,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2859",
        "source" : "2857",
        "target" : "277",
        "EdgeBetweenness" : 92.0,
        "shared_name" : "speedy (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "speedy (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2859,
        "BEND_MAP_ID" : 2859,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3005",
        "source" : "2827",
        "target" : "277",
        "EdgeBetweenness" : 102.0,
        "shared_name" : "bloody (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "bloody (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3005,
        "BEND_MAP_ID" : 3005,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2829",
        "source" : "2827",
        "target" : "277",
        "EdgeBetweenness" : 102.0,
        "shared_name" : "bloody (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "bloody (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2829,
        "BEND_MAP_ID" : 2829,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3477",
        "source" : "2823",
        "target" : "277",
        "EdgeBetweenness" : 104.0,
        "shared_name" : "floral (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "floral (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3477,
        "BEND_MAP_ID" : 3477,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3093",
        "source" : "2823",
        "target" : "277",
        "EdgeBetweenness" : 104.0,
        "shared_name" : "floral (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "floral (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3093,
        "BEND_MAP_ID" : 3093,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2825",
        "source" : "2823",
        "target" : "277",
        "EdgeBetweenness" : 104.0,
        "shared_name" : "floral (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "floral (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2825,
        "BEND_MAP_ID" : 2825,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2817",
        "source" : "2815",
        "target" : "277",
        "EdgeBetweenness" : 107.0,
        "shared_name" : "worthless (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "worthless (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2817,
        "BEND_MAP_ID" : 2817,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2813",
        "source" : "2811",
        "target" : "277",
        "EdgeBetweenness" : 109.0,
        "shared_name" : "messed (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "messed (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2813,
        "BEND_MAP_ID" : 2813,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2805",
        "source" : "2803",
        "target" : "277",
        "EdgeBetweenness" : 113.0,
        "shared_name" : "sizzling (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "sizzling (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2805,
        "BEND_MAP_ID" : 2805,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2801",
        "source" : "2799",
        "target" : "277",
        "EdgeBetweenness" : 116.0,
        "shared_name" : "obscene (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "obscene (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2801,
        "BEND_MAP_ID" : 2801,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2791",
        "source" : "2785",
        "target" : "277",
        "EdgeBetweenness" : 124.0,
        "shared_name" : "frozen (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "frozen (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2791,
        "BEND_MAP_ID" : 2791,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2787",
        "source" : "2785",
        "target" : "277",
        "EdgeBetweenness" : 124.0,
        "shared_name" : "frozen (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "frozen (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2787,
        "BEND_MAP_ID" : 2787,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2783",
        "source" : "2781",
        "target" : "277",
        "EdgeBetweenness" : 127.0,
        "shared_name" : "quizical (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "quizical (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2783,
        "BEND_MAP_ID" : 2783,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2773",
        "source" : "2771",
        "target" : "277",
        "EdgeBetweenness" : 129.0,
        "shared_name" : "cooked (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "cooked (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2773,
        "BEND_MAP_ID" : 2773,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2757",
        "source" : "2755",
        "target" : "277",
        "EdgeBetweenness" : 135.0,
        "shared_name" : "overall (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "overall (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2757,
        "BEND_MAP_ID" : 2757,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2751",
        "source" : "2749",
        "target" : "277",
        "EdgeBetweenness" : 140.0,
        "shared_name" : "furious (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "furious (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2751,
        "BEND_MAP_ID" : 2751,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2745",
        "source" : "2743",
        "target" : "277",
        "EdgeBetweenness" : 142.0,
        "shared_name" : "gigantic (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "gigantic (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2745,
        "BEND_MAP_ID" : 2745,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2739",
        "source" : "2737",
        "target" : "277",
        "EdgeBetweenness" : 146.0,
        "shared_name" : "fried (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "fried (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2739,
        "BEND_MAP_ID" : 2739,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2731",
        "source" : "2729",
        "target" : "277",
        "EdgeBetweenness" : 150.0,
        "shared_name" : "lonesome (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "lonesome (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2731,
        "BEND_MAP_ID" : 2731,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2723",
        "source" : "2721",
        "target" : "277",
        "EdgeBetweenness" : 154.0,
        "shared_name" : "orignal (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "orignal (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2723,
        "BEND_MAP_ID" : 2723,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2719",
        "source" : "2717",
        "target" : "277",
        "EdgeBetweenness" : 157.0,
        "shared_name" : "bare (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "bare (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2719,
        "BEND_MAP_ID" : 2719,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2713",
        "source" : "2711",
        "target" : "277",
        "EdgeBetweenness" : 159.0,
        "shared_name" : "strange (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "strange (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2713,
        "BEND_MAP_ID" : 2713,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2703",
        "source" : "2701",
        "target" : "277",
        "EdgeBetweenness" : 166.0,
        "shared_name" : "sappy (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "sappy (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2703,
        "BEND_MAP_ID" : 2703,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2699",
        "source" : "2697",
        "target" : "277",
        "EdgeBetweenness" : 168.0,
        "shared_name" : "terrible (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "terrible (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2699,
        "BEND_MAP_ID" : 2699,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2695",
        "source" : "2693",
        "target" : "277",
        "EdgeBetweenness" : 171.0,
        "shared_name" : "romantic (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "romantic (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2695,
        "BEND_MAP_ID" : 2695,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2689",
        "source" : "2687",
        "target" : "277",
        "EdgeBetweenness" : 174.0,
        "shared_name" : "depressed (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "depressed (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2689,
        "BEND_MAP_ID" : 2689,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2683",
        "source" : "2681",
        "target" : "277",
        "EdgeBetweenness" : 177.0,
        "shared_name" : "mammary (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "mammary (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2683,
        "BEND_MAP_ID" : 2683,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2677",
        "source" : "2675",
        "target" : "277",
        "EdgeBetweenness" : 181.0,
        "shared_name" : "false (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "false (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2677,
        "BEND_MAP_ID" : 2677,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2671",
        "source" : "2669",
        "target" : "277",
        "EdgeBetweenness" : 184.0,
        "shared_name" : "amazing (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "amazing (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2671,
        "BEND_MAP_ID" : 2671,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2667",
        "source" : "2665",
        "target" : "277",
        "EdgeBetweenness" : 187.0,
        "shared_name" : "schizophrenic (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "schizophrenic (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2667,
        "BEND_MAP_ID" : 2667,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2657",
        "source" : "2655",
        "target" : "277",
        "EdgeBetweenness" : 191.0,
        "shared_name" : "deserted (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "deserted (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2657,
        "BEND_MAP_ID" : 2657,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2653",
        "source" : "2651",
        "target" : "277",
        "EdgeBetweenness" : 193.0,
        "shared_name" : "garish (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "garish (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2653,
        "BEND_MAP_ID" : 2653,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2649",
        "source" : "2647",
        "target" : "277",
        "EdgeBetweenness" : 194.0,
        "shared_name" : "tassled (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "tassled (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2649,
        "BEND_MAP_ID" : 2649,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3401",
        "source" : "2625",
        "target" : "277",
        "EdgeBetweenness" : 203.0,
        "shared_name" : "smart (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "smart (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3401,
        "BEND_MAP_ID" : 3401,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2627",
        "source" : "2625",
        "target" : "277",
        "EdgeBetweenness" : 203.0,
        "shared_name" : "smart (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "smart (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2627,
        "BEND_MAP_ID" : 2627,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2623",
        "source" : "2621",
        "target" : "277",
        "EdgeBetweenness" : 205.0,
        "shared_name" : "litany (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "litany (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2623,
        "BEND_MAP_ID" : 2623,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2617",
        "source" : "2615",
        "target" : "277",
        "EdgeBetweenness" : 209.0,
        "shared_name" : "pre (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "pre (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2617,
        "BEND_MAP_ID" : 2617,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2839",
        "source" : "2609",
        "target" : "277",
        "EdgeBetweenness" : 212.0,
        "shared_name" : "further (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "further (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2839,
        "BEND_MAP_ID" : 2839,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2611",
        "source" : "2609",
        "target" : "277",
        "EdgeBetweenness" : 212.0,
        "shared_name" : "further (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "further (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2611,
        "BEND_MAP_ID" : 2611,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2837",
        "source" : "2605",
        "target" : "277",
        "EdgeBetweenness" : 214.0,
        "shared_name" : "nasty (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "nasty (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2837,
        "BEND_MAP_ID" : 2837,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2607",
        "source" : "2605",
        "target" : "277",
        "EdgeBetweenness" : 214.0,
        "shared_name" : "nasty (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "nasty (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2607,
        "BEND_MAP_ID" : 2607,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2635",
        "source" : "2601",
        "target" : "277",
        "EdgeBetweenness" : 218.0,
        "shared_name" : "weakened (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "weakened (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2635,
        "BEND_MAP_ID" : 2635,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2603",
        "source" : "2601",
        "target" : "277",
        "EdgeBetweenness" : 218.0,
        "shared_name" : "weakened (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "weakened (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2603,
        "BEND_MAP_ID" : 2603,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2835",
        "source" : "2597",
        "target" : "277",
        "EdgeBetweenness" : 221.0,
        "shared_name" : "afraid (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "afraid (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2835,
        "BEND_MAP_ID" : 2835,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2633",
        "source" : "2597",
        "target" : "277",
        "EdgeBetweenness" : 221.0,
        "shared_name" : "afraid (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "afraid (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2633,
        "BEND_MAP_ID" : 2633,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2599",
        "source" : "2597",
        "target" : "277",
        "EdgeBetweenness" : 221.0,
        "shared_name" : "afraid (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "afraid (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2599,
        "BEND_MAP_ID" : 2599,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3425",
        "source" : "2587",
        "target" : "277",
        "EdgeBetweenness" : 224.0,
        "shared_name" : "front (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "front (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3425,
        "BEND_MAP_ID" : 3425,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3081",
        "source" : "2587",
        "target" : "277",
        "EdgeBetweenness" : 224.0,
        "shared_name" : "front (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "front (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3081,
        "BEND_MAP_ID" : 3081,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2937",
        "source" : "2587",
        "target" : "277",
        "EdgeBetweenness" : 224.0,
        "shared_name" : "front (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "front (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2937,
        "BEND_MAP_ID" : 2937,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2797",
        "source" : "2587",
        "target" : "277",
        "EdgeBetweenness" : 224.0,
        "shared_name" : "front (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "front (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2797,
        "BEND_MAP_ID" : 2797,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2591",
        "source" : "2587",
        "target" : "277",
        "EdgeBetweenness" : 224.0,
        "shared_name" : "front (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "front (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2591,
        "BEND_MAP_ID" : 2591,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2589",
        "source" : "2587",
        "target" : "277",
        "EdgeBetweenness" : 224.0,
        "shared_name" : "front (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "front (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2589,
        "BEND_MAP_ID" : 2589,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2583",
        "source" : "2581",
        "target" : "277",
        "EdgeBetweenness" : 228.0,
        "shared_name" : "broad (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "broad (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2583,
        "BEND_MAP_ID" : 2583,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3211",
        "source" : "2575",
        "target" : "277",
        "EdgeBetweenness" : 231.0,
        "shared_name" : "closed (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "closed (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3211,
        "BEND_MAP_ID" : 3211,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3159",
        "source" : "2575",
        "target" : "277",
        "EdgeBetweenness" : 231.0,
        "shared_name" : "closed (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "closed (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3159,
        "BEND_MAP_ID" : 3159,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2577",
        "source" : "2575",
        "target" : "277",
        "EdgeBetweenness" : 231.0,
        "shared_name" : "closed (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "closed (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2577,
        "BEND_MAP_ID" : 2577,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2565",
        "source" : "2563",
        "target" : "277",
        "EdgeBetweenness" : 237.0,
        "shared_name" : "gritty (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "gritty (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2565,
        "BEND_MAP_ID" : 2565,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2571",
        "source" : "2551",
        "target" : "277",
        "EdgeBetweenness" : 242.0,
        "shared_name" : "wide (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "wide (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2571,
        "BEND_MAP_ID" : 2571,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2553",
        "source" : "2551",
        "target" : "277",
        "EdgeBetweenness" : 242.0,
        "shared_name" : "wide (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "wide (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2553,
        "BEND_MAP_ID" : 2553,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2549",
        "source" : "2547",
        "target" : "277",
        "EdgeBetweenness" : 244.0,
        "shared_name" : "rousing (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "rousing (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2549,
        "BEND_MAP_ID" : 2549,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2541",
        "source" : "2539",
        "target" : "277",
        "EdgeBetweenness" : 248.0,
        "shared_name" : "angleic (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "angleic (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2541,
        "BEND_MAP_ID" : 2541,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2531",
        "source" : "2529",
        "target" : "277",
        "EdgeBetweenness" : 253.0,
        "shared_name" : "maroon (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "maroon (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2531,
        "BEND_MAP_ID" : 2531,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2557",
        "source" : "2515",
        "target" : "277",
        "EdgeBetweenness" : 261.0,
        "shared_name" : "entire (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "entire (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2557,
        "BEND_MAP_ID" : 2557,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2545",
        "source" : "2515",
        "target" : "277",
        "EdgeBetweenness" : 261.0,
        "shared_name" : "entire (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "entire (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2545,
        "BEND_MAP_ID" : 2545,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2517",
        "source" : "2515",
        "target" : "277",
        "EdgeBetweenness" : 261.0,
        "shared_name" : "entire (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "entire (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2517,
        "BEND_MAP_ID" : 2517,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3347",
        "source" : "2507",
        "target" : "277",
        "EdgeBetweenness" : 265.0,
        "shared_name" : "interested (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "interested (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3347,
        "BEND_MAP_ID" : 3347,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2679",
        "source" : "2507",
        "target" : "277",
        "EdgeBetweenness" : 265.0,
        "shared_name" : "interested (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "interested (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2679,
        "BEND_MAP_ID" : 2679,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2509",
        "source" : "2507",
        "target" : "277",
        "EdgeBetweenness" : 265.0,
        "shared_name" : "interested (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "interested (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2509,
        "BEND_MAP_ID" : 2509,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2491",
        "source" : "2489",
        "target" : "277",
        "EdgeBetweenness" : 272.0,
        "shared_name" : "previous (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "previous (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2491,
        "BEND_MAP_ID" : 2491,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2477",
        "source" : "2475",
        "target" : "277",
        "EdgeBetweenness" : 278.0,
        "shared_name" : "homely (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "homely (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2477,
        "BEND_MAP_ID" : 2477,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2761",
        "source" : "2469",
        "target" : "277",
        "EdgeBetweenness" : 282.0,
        "shared_name" : "american (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "american (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2761,
        "BEND_MAP_ID" : 2761,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2481",
        "source" : "2469",
        "target" : "277",
        "EdgeBetweenness" : 282.0,
        "shared_name" : "american (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "american (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2481,
        "BEND_MAP_ID" : 2481,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2471",
        "source" : "2469",
        "target" : "277",
        "EdgeBetweenness" : 282.0,
        "shared_name" : "american (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "american (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2471,
        "BEND_MAP_ID" : 2471,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2465",
        "source" : "2463",
        "target" : "277",
        "EdgeBetweenness" : 286.0,
        "shared_name" : "underway (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "underway (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2465,
        "BEND_MAP_ID" : 2465,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2459",
        "source" : "2457",
        "target" : "277",
        "EdgeBetweenness" : 290.0,
        "shared_name" : "selfish (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "selfish (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2459,
        "BEND_MAP_ID" : 2459,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2451",
        "source" : "2449",
        "target" : "277",
        "EdgeBetweenness" : 293.0,
        "shared_name" : "bright (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "bright (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2451,
        "BEND_MAP_ID" : 2451,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2445",
        "source" : "2443",
        "target" : "277",
        "EdgeBetweenness" : 299.0,
        "shared_name" : "stinging (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "stinging (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2445,
        "BEND_MAP_ID" : 2445,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2435",
        "source" : "2431",
        "target" : "277",
        "EdgeBetweenness" : 305.0,
        "shared_name" : "foul (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "foul (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2435,
        "BEND_MAP_ID" : 2435,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2433",
        "source" : "2431",
        "target" : "277",
        "EdgeBetweenness" : 305.0,
        "shared_name" : "foul (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "foul (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2433,
        "BEND_MAP_ID" : 2433,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2423",
        "source" : "2421",
        "target" : "277",
        "EdgeBetweenness" : 312.0,
        "shared_name" : "far (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "far (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2423,
        "BEND_MAP_ID" : 2423,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2417",
        "source" : "2415",
        "target" : "277",
        "EdgeBetweenness" : 315.0,
        "shared_name" : "confusing (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "confusing (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2417,
        "BEND_MAP_ID" : 2417,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3475",
        "source" : "2407",
        "target" : "277",
        "EdgeBetweenness" : 322.0,
        "shared_name" : "jammed (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "jammed (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3475,
        "BEND_MAP_ID" : 3475,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3113",
        "source" : "2407",
        "target" : "277",
        "EdgeBetweenness" : 322.0,
        "shared_name" : "jammed (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "jammed (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3113,
        "BEND_MAP_ID" : 3113,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2409",
        "source" : "2407",
        "target" : "277",
        "EdgeBetweenness" : 322.0,
        "shared_name" : "jammed (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "jammed (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2409,
        "BEND_MAP_ID" : 2409,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2441",
        "source" : "2401",
        "target" : "277",
        "EdgeBetweenness" : 325.0,
        "shared_name" : "hot (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "hot (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2441,
        "BEND_MAP_ID" : 2441,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2439",
        "source" : "2401",
        "target" : "277",
        "EdgeBetweenness" : 325.0,
        "shared_name" : "hot (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "hot (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2439,
        "BEND_MAP_ID" : 2439,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2427",
        "source" : "2401",
        "target" : "277",
        "EdgeBetweenness" : 325.0,
        "shared_name" : "hot (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "hot (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2427,
        "BEND_MAP_ID" : 2427,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2405",
        "source" : "2401",
        "target" : "277",
        "EdgeBetweenness" : 325.0,
        "shared_name" : "hot (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "hot (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2405,
        "BEND_MAP_ID" : 2405,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2403",
        "source" : "2401",
        "target" : "277",
        "EdgeBetweenness" : 325.0,
        "shared_name" : "hot (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "hot (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2403,
        "BEND_MAP_ID" : 2403,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2399",
        "source" : "2397",
        "target" : "277",
        "EdgeBetweenness" : 327.0,
        "shared_name" : "rowdy (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "rowdy (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2399,
        "BEND_MAP_ID" : 2399,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2391",
        "source" : "2389",
        "target" : "277",
        "EdgeBetweenness" : 333.0,
        "shared_name" : "condescending (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "condescending (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2391,
        "BEND_MAP_ID" : 2391,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2383",
        "source" : "2381",
        "target" : "277",
        "EdgeBetweenness" : 337.0,
        "shared_name" : "outer (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "outer (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2383,
        "BEND_MAP_ID" : 2383,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2379",
        "source" : "2377",
        "target" : "277",
        "EdgeBetweenness" : 338.0,
        "shared_name" : "cavalier (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "cavalier (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2379,
        "BEND_MAP_ID" : 2379,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2371",
        "source" : "2369",
        "target" : "277",
        "EdgeBetweenness" : 343.0,
        "shared_name" : "reprehensible (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "reprehensible (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2371,
        "BEND_MAP_ID" : 2371,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2367",
        "source" : "2365",
        "target" : "277",
        "EdgeBetweenness" : 345.0,
        "shared_name" : "moral (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "moral (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2367,
        "BEND_MAP_ID" : 2367,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2359",
        "source" : "2357",
        "target" : "277",
        "EdgeBetweenness" : 350.0,
        "shared_name" : "obtuse (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "obtuse (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2359,
        "BEND_MAP_ID" : 2359,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2965",
        "source" : "2349",
        "target" : "277",
        "EdgeBetweenness" : 356.0,
        "shared_name" : "interesting (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "interesting (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2965,
        "BEND_MAP_ID" : 2965,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2351",
        "source" : "2349",
        "target" : "277",
        "EdgeBetweenness" : 356.0,
        "shared_name" : "interesting (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "interesting (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2351,
        "BEND_MAP_ID" : 2351,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2347",
        "source" : "2345",
        "target" : "277",
        "EdgeBetweenness" : 358.0,
        "shared_name" : "left (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "left (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2347,
        "BEND_MAP_ID" : 2347,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2337",
        "source" : "2335",
        "target" : "277",
        "EdgeBetweenness" : 362.0,
        "shared_name" : "chilling (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "chilling (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2337,
        "BEND_MAP_ID" : 2337,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2327",
        "source" : "2325",
        "target" : "277",
        "EdgeBetweenness" : 366.0,
        "shared_name" : "spooky (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "spooky (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2327,
        "BEND_MAP_ID" : 2327,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2323",
        "source" : "2321",
        "target" : "277",
        "EdgeBetweenness" : 371.0,
        "shared_name" : "fatty (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "fatty (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2323,
        "BEND_MAP_ID" : 2323,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2311",
        "source" : "2309",
        "target" : "277",
        "EdgeBetweenness" : 374.0,
        "shared_name" : "relaxed (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "relaxed (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2311,
        "BEND_MAP_ID" : 2311,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2305",
        "source" : "2303",
        "target" : "277",
        "EdgeBetweenness" : 377.0,
        "shared_name" : "aft (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "aft (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2305,
        "BEND_MAP_ID" : 2305,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2291",
        "source" : "2289",
        "target" : "277",
        "EdgeBetweenness" : 383.0,
        "shared_name" : "deadly (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "deadly (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2291,
        "BEND_MAP_ID" : 2291,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2727",
        "source" : "2285",
        "target" : "277",
        "EdgeBetweenness" : 386.0,
        "shared_name" : "dramatic (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "dramatic (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2727,
        "BEND_MAP_ID" : 2727,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2287",
        "source" : "2285",
        "target" : "277",
        "EdgeBetweenness" : 386.0,
        "shared_name" : "dramatic (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "dramatic (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2287,
        "BEND_MAP_ID" : 2287,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2273",
        "source" : "2271",
        "target" : "277",
        "EdgeBetweenness" : 392.0,
        "shared_name" : "global (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "global (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2273,
        "BEND_MAP_ID" : 2273,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2269",
        "source" : "2267",
        "target" : "277",
        "EdgeBetweenness" : 393.0,
        "shared_name" : "raggy (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "raggy (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2269,
        "BEND_MAP_ID" : 2269,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2263",
        "source" : "2261",
        "target" : "277",
        "EdgeBetweenness" : 395.0,
        "shared_name" : "polluted (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "polluted (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2263,
        "BEND_MAP_ID" : 2263,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2259",
        "source" : "2257",
        "target" : "277",
        "EdgeBetweenness" : 397.0,
        "shared_name" : "scenic (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "scenic (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2259,
        "BEND_MAP_ID" : 2259,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2361",
        "source" : "2251",
        "target" : "277",
        "EdgeBetweenness" : 399.0,
        "shared_name" : "nuclear (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "nuclear (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2361,
        "BEND_MAP_ID" : 2361,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2295",
        "source" : "2251",
        "target" : "277",
        "EdgeBetweenness" : 399.0,
        "shared_name" : "nuclear (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "nuclear (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2295,
        "BEND_MAP_ID" : 2295,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2281",
        "source" : "2251",
        "target" : "277",
        "EdgeBetweenness" : 399.0,
        "shared_name" : "nuclear (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "nuclear (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2281,
        "BEND_MAP_ID" : 2281,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2265",
        "source" : "2251",
        "target" : "277",
        "EdgeBetweenness" : 399.0,
        "shared_name" : "nuclear (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "nuclear (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2265,
        "BEND_MAP_ID" : 2265,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2253",
        "source" : "2251",
        "target" : "277",
        "EdgeBetweenness" : 399.0,
        "shared_name" : "nuclear (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "nuclear (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2253,
        "BEND_MAP_ID" : 2253,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2395",
        "source" : "2245",
        "target" : "277",
        "EdgeBetweenness" : 403.0,
        "shared_name" : "green (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "green (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2395,
        "BEND_MAP_ID" : 2395,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2247",
        "source" : "2245",
        "target" : "277",
        "EdgeBetweenness" : 403.0,
        "shared_name" : "green (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "green (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2247,
        "BEND_MAP_ID" : 2247,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2243",
        "source" : "2241",
        "target" : "277",
        "EdgeBetweenness" : 405.0,
        "shared_name" : "fetid (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "fetid (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2243,
        "BEND_MAP_ID" : 2243,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2235",
        "source" : "2233",
        "target" : "277",
        "EdgeBetweenness" : 408.0,
        "shared_name" : "blank (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "blank (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2235,
        "BEND_MAP_ID" : 2235,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2229",
        "source" : "2227",
        "target" : "277",
        "EdgeBetweenness" : 410.0,
        "shared_name" : "tiny (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "tiny (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2229,
        "BEND_MAP_ID" : 2229,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2479",
        "source" : "2217",
        "target" : "277",
        "EdgeBetweenness" : 412.0,
        "shared_name" : "german (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "german (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2479,
        "BEND_MAP_ID" : 2479,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2467",
        "source" : "2217",
        "target" : "277",
        "EdgeBetweenness" : 412.0,
        "shared_name" : "german (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "german (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2467,
        "BEND_MAP_ID" : 2467,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2219",
        "source" : "2217",
        "target" : "277",
        "EdgeBetweenness" : 412.0,
        "shared_name" : "german (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "german (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2219,
        "BEND_MAP_ID" : 2219,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2867",
        "source" : "2213",
        "target" : "277",
        "EdgeBetweenness" : 414.0,
        "shared_name" : "massive (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "massive (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2867,
        "BEND_MAP_ID" : 2867,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2215",
        "source" : "2213",
        "target" : "277",
        "EdgeBetweenness" : 414.0,
        "shared_name" : "massive (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "massive (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2215,
        "BEND_MAP_ID" : 2215,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3165",
        "source" : "2209",
        "target" : "277",
        "EdgeBetweenness" : 416.0,
        "shared_name" : "human (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "human (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3165,
        "BEND_MAP_ID" : 3165,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2855",
        "source" : "2209",
        "target" : "277",
        "EdgeBetweenness" : 416.0,
        "shared_name" : "human (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "human (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2855,
        "BEND_MAP_ID" : 2855,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2339",
        "source" : "2209",
        "target" : "277",
        "EdgeBetweenness" : 416.0,
        "shared_name" : "human (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "human (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2339,
        "BEND_MAP_ID" : 2339,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2231",
        "source" : "2209",
        "target" : "277",
        "EdgeBetweenness" : 416.0,
        "shared_name" : "human (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "human (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2231,
        "BEND_MAP_ID" : 2231,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2211",
        "source" : "2209",
        "target" : "277",
        "EdgeBetweenness" : 416.0,
        "shared_name" : "human (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "human (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2211,
        "BEND_MAP_ID" : 2211,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2197",
        "source" : "2195",
        "target" : "277",
        "EdgeBetweenness" : 421.0,
        "shared_name" : "main (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "main (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2197,
        "BEND_MAP_ID" : 2197,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2193",
        "source" : "2191",
        "target" : "277",
        "EdgeBetweenness" : 424.0,
        "shared_name" : "overhead (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "overhead (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2193,
        "BEND_MAP_ID" : 2193,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2187",
        "source" : "2185",
        "target" : "277",
        "EdgeBetweenness" : 425.0,
        "shared_name" : "grand (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "grand (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2187,
        "BEND_MAP_ID" : 2187,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2181",
        "source" : "2179",
        "target" : "277",
        "EdgeBetweenness" : 427.0,
        "shared_name" : "meek (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "meek (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2181,
        "BEND_MAP_ID" : 2181,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2223",
        "source" : "2169",
        "target" : "277",
        "EdgeBetweenness" : 429.0,
        "shared_name" : "famous (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "famous (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2223,
        "BEND_MAP_ID" : 2223,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2171",
        "source" : "2169",
        "target" : "277",
        "EdgeBetweenness" : 429.0,
        "shared_name" : "famous (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "famous (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2171,
        "BEND_MAP_ID" : 2171,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2167",
        "source" : "2165",
        "target" : "277",
        "EdgeBetweenness" : 431.0,
        "shared_name" : "digestive (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "digestive (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2167,
        "BEND_MAP_ID" : 2167,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2163",
        "source" : "2161",
        "target" : "277",
        "EdgeBetweenness" : 433.0,
        "shared_name" : "colorless (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "colorless (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2163,
        "BEND_MAP_ID" : 2163,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2869",
        "source" : "2157",
        "target" : "277",
        "EdgeBetweenness" : 437.0,
        "shared_name" : "thick (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "thick (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2869,
        "BEND_MAP_ID" : 2869,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2159",
        "source" : "2157",
        "target" : "277",
        "EdgeBetweenness" : 437.0,
        "shared_name" : "thick (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "thick (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2159,
        "BEND_MAP_ID" : 2159,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2155",
        "source" : "2153",
        "target" : "277",
        "EdgeBetweenness" : 439.0,
        "shared_name" : "important (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "important (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2155,
        "BEND_MAP_ID" : 2155,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2149",
        "source" : "2147",
        "target" : "277",
        "EdgeBetweenness" : 442.0,
        "shared_name" : "beefoid (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "beefoid (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2149,
        "BEND_MAP_ID" : 2149,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2145",
        "source" : "2143",
        "target" : "277",
        "EdgeBetweenness" : 444.0,
        "shared_name" : "honest (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "honest (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2145,
        "BEND_MAP_ID" : 2145,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2137",
        "source" : "2135",
        "target" : "277",
        "EdgeBetweenness" : 447.0,
        "shared_name" : "scary (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "scary (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2137,
        "BEND_MAP_ID" : 2137,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2131",
        "source" : "2129",
        "target" : "277",
        "EdgeBetweenness" : 448.0,
        "shared_name" : "social (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "social (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2131,
        "BEND_MAP_ID" : 2131,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2127",
        "source" : "2125",
        "target" : "277",
        "EdgeBetweenness" : 449.0,
        "shared_name" : "absolute (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "absolute (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2127,
        "BEND_MAP_ID" : 2127,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2117",
        "source" : "2115",
        "target" : "277",
        "EdgeBetweenness" : 451.0,
        "shared_name" : "shit (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "shit (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2117,
        "BEND_MAP_ID" : 2117,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3039",
        "source" : "2109",
        "target" : "277",
        "EdgeBetweenness" : 454.0,
        "shared_name" : "many (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "many (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3039,
        "BEND_MAP_ID" : 3039,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3037",
        "source" : "2109",
        "target" : "277",
        "EdgeBetweenness" : 454.0,
        "shared_name" : "many (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "many (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3037,
        "BEND_MAP_ID" : 3037,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2853",
        "source" : "2109",
        "target" : "277",
        "EdgeBetweenness" : 454.0,
        "shared_name" : "many (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "many (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2853,
        "BEND_MAP_ID" : 2853,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2111",
        "source" : "2109",
        "target" : "277",
        "EdgeBetweenness" : 454.0,
        "shared_name" : "many (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "many (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2111,
        "BEND_MAP_ID" : 2111,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2103",
        "source" : "2101",
        "target" : "277",
        "EdgeBetweenness" : 458.0,
        "shared_name" : "asshole (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "asshole (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2103,
        "BEND_MAP_ID" : 2103,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2099",
        "source" : "2097",
        "target" : "277",
        "EdgeBetweenness" : 460.0,
        "shared_name" : "flaming (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "flaming (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2099,
        "BEND_MAP_ID" : 2099,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2089",
        "source" : "2087",
        "target" : "277",
        "EdgeBetweenness" : 462.0,
        "shared_name" : "exciting (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "exciting (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2089,
        "BEND_MAP_ID" : 2089,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3459",
        "source" : "2083",
        "target" : "277",
        "EdgeBetweenness" : 464.0,
        "shared_name" : "next (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "next (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3459,
        "BEND_MAP_ID" : 3459,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3027",
        "source" : "2083",
        "target" : "277",
        "EdgeBetweenness" : 464.0,
        "shared_name" : "next (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "next (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3027,
        "BEND_MAP_ID" : 3027,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2085",
        "source" : "2083",
        "target" : "277",
        "EdgeBetweenness" : 464.0,
        "shared_name" : "next (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "next (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2085,
        "BEND_MAP_ID" : 2085,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2081",
        "source" : "2079",
        "target" : "277",
        "EdgeBetweenness" : 466.0,
        "shared_name" : "decent (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "decent (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2081,
        "BEND_MAP_ID" : 2081,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2075",
        "source" : "2073",
        "target" : "277",
        "EdgeBetweenness" : 468.0,
        "shared_name" : "fair (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "fair (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2075,
        "BEND_MAP_ID" : 2075,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2071",
        "source" : "2069",
        "target" : "277",
        "EdgeBetweenness" : 471.0,
        "shared_name" : "friendly (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "friendly (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2071,
        "BEND_MAP_ID" : 2071,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2067",
        "source" : "2065",
        "target" : "277",
        "EdgeBetweenness" : 473.0,
        "shared_name" : "considerate (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "considerate (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2067,
        "BEND_MAP_ID" : 2067,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2059",
        "source" : "2057",
        "target" : "277",
        "EdgeBetweenness" : 476.0,
        "shared_name" : "soon (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "soon (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2059,
        "BEND_MAP_ID" : 2059,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2055",
        "source" : "2053",
        "target" : "277",
        "EdgeBetweenness" : 478.0,
        "shared_name" : "ignorant (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "ignorant (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2055,
        "BEND_MAP_ID" : 2055,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2043",
        "source" : "2041",
        "target" : "277",
        "EdgeBetweenness" : 483.0,
        "shared_name" : "established (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "established (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2043,
        "BEND_MAP_ID" : 2043,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2031",
        "source" : "2029",
        "target" : "277",
        "EdgeBetweenness" : 1.0,
        "shared_name" : "vicious (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "vicious (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2031,
        "BEND_MAP_ID" : 2031,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2027",
        "source" : "2025",
        "target" : "277",
        "EdgeBetweenness" : 3.0,
        "shared_name" : "mean (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "mean (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2027,
        "BEND_MAP_ID" : 2027,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2051",
        "source" : "2017",
        "target" : "277",
        "EdgeBetweenness" : 6.0,
        "shared_name" : "wonderful (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "wonderful (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2051,
        "BEND_MAP_ID" : 2051,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2021",
        "source" : "2017",
        "target" : "277",
        "EdgeBetweenness" : 6.0,
        "shared_name" : "wonderful (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "wonderful (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2021,
        "BEND_MAP_ID" : 2021,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2019",
        "source" : "2017",
        "target" : "277",
        "EdgeBetweenness" : 6.0,
        "shared_name" : "wonderful (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "wonderful (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2019,
        "BEND_MAP_ID" : 2019,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2307",
        "source" : "1999",
        "target" : "277",
        "EdgeBetweenness" : 10.0,
        "shared_name" : "casual (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "casual (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2307,
        "BEND_MAP_ID" : 2307,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2001",
        "source" : "1999",
        "target" : "277",
        "EdgeBetweenness" : 10.0,
        "shared_name" : "casual (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "casual (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2001,
        "BEND_MAP_ID" : 2001,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3013",
        "source" : "1995",
        "target" : "277",
        "EdgeBetweenness" : 12.0,
        "shared_name" : "frightening (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "frightening (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3013,
        "BEND_MAP_ID" : 3013,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2331",
        "source" : "1995",
        "target" : "277",
        "EdgeBetweenness" : 12.0,
        "shared_name" : "frightening (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "frightening (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2331,
        "BEND_MAP_ID" : 2331,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1997",
        "source" : "1995",
        "target" : "277",
        "EdgeBetweenness" : 12.0,
        "shared_name" : "frightening (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "frightening (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1997,
        "BEND_MAP_ID" : 1997,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1987",
        "source" : "1985",
        "target" : "277",
        "EdgeBetweenness" : 16.0,
        "shared_name" : "crusty (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "crusty (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1987,
        "BEND_MAP_ID" : 1987,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2047",
        "source" : "1979",
        "target" : "277",
        "EdgeBetweenness" : 19.0,
        "shared_name" : "charming (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "charming (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2047,
        "BEND_MAP_ID" : 2047,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1981",
        "source" : "1979",
        "target" : "277",
        "EdgeBetweenness" : 19.0,
        "shared_name" : "charming (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "charming (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1981,
        "BEND_MAP_ID" : 1981,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1975",
        "source" : "1973",
        "target" : "277",
        "EdgeBetweenness" : 22.0,
        "shared_name" : "common (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "common (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1975,
        "BEND_MAP_ID" : 1975,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3529",
        "source" : "1969",
        "target" : "277",
        "EdgeBetweenness" : 25.0,
        "shared_name" : "pure (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "pure (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3529,
        "BEND_MAP_ID" : 3529,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1971",
        "source" : "1969",
        "target" : "277",
        "EdgeBetweenness" : 25.0,
        "shared_name" : "pure (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "pure (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1971,
        "BEND_MAP_ID" : 1971,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1963",
        "source" : "1961",
        "target" : "277",
        "EdgeBetweenness" : 27.0,
        "shared_name" : "fake (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "fake (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1963,
        "BEND_MAP_ID" : 1963,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1957",
        "source" : "1955",
        "target" : "277",
        "EdgeBetweenness" : 31.0,
        "shared_name" : "parental (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "parental (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1957,
        "BEND_MAP_ID" : 1957,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1947",
        "source" : "1945",
        "target" : "277",
        "EdgeBetweenness" : 36.0,
        "shared_name" : "divorced (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "divorced (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1947,
        "BEND_MAP_ID" : 1947,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1941",
        "source" : "1939",
        "target" : "277",
        "EdgeBetweenness" : 39.0,
        "shared_name" : "natural (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "natural (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1941,
        "BEND_MAP_ID" : 1941,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1931",
        "source" : "1929",
        "target" : "277",
        "EdgeBetweenness" : 42.0,
        "shared_name" : "married (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "married (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1931,
        "BEND_MAP_ID" : 1931,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1923",
        "source" : "1921",
        "target" : "277",
        "EdgeBetweenness" : 46.0,
        "shared_name" : "awkward (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "awkward (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1923,
        "BEND_MAP_ID" : 1923,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1917",
        "source" : "1915",
        "target" : "277",
        "EdgeBetweenness" : 49.0,
        "shared_name" : "compatible (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "compatible (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1917,
        "BEND_MAP_ID" : 1917,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2691",
        "source" : "1907",
        "target" : "277",
        "EdgeBetweenness" : 53.0,
        "shared_name" : "true (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "true (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2691,
        "BEND_MAP_ID" : 2691,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2503",
        "source" : "1907",
        "target" : "277",
        "EdgeBetweenness" : 53.0,
        "shared_name" : "true (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "true (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2503,
        "BEND_MAP_ID" : 2503,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1909",
        "source" : "1907",
        "target" : "277",
        "EdgeBetweenness" : 53.0,
        "shared_name" : "true (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "true (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1909,
        "BEND_MAP_ID" : 1909,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1905",
        "source" : "1903",
        "target" : "277",
        "EdgeBetweenness" : 56.0,
        "shared_name" : "enriching (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "enriching (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1905,
        "BEND_MAP_ID" : 1905,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1893",
        "source" : "1891",
        "target" : "277",
        "EdgeBetweenness" : 62.0,
        "shared_name" : "cutest (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "cutest (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1893,
        "BEND_MAP_ID" : 1893,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2205",
        "source" : "1883",
        "target" : "277",
        "EdgeBetweenness" : 65.0,
        "shared_name" : "round (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "round (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2205,
        "BEND_MAP_ID" : 2205,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1885",
        "source" : "1883",
        "target" : "277",
        "EdgeBetweenness" : 65.0,
        "shared_name" : "round (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "round (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1885,
        "BEND_MAP_ID" : 1885,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2769",
        "source" : "1879",
        "target" : "277",
        "EdgeBetweenness" : 67.0,
        "shared_name" : "giant (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "giant (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2769,
        "BEND_MAP_ID" : 2769,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2207",
        "source" : "1879",
        "target" : "277",
        "EdgeBetweenness" : 67.0,
        "shared_name" : "giant (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "giant (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2207,
        "BEND_MAP_ID" : 2207,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2201",
        "source" : "1879",
        "target" : "277",
        "EdgeBetweenness" : 67.0,
        "shared_name" : "giant (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "giant (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2201,
        "BEND_MAP_ID" : 2201,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1897",
        "source" : "1879",
        "target" : "277",
        "EdgeBetweenness" : 67.0,
        "shared_name" : "giant (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "giant (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1897,
        "BEND_MAP_ID" : 1897,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1881",
        "source" : "1879",
        "target" : "277",
        "EdgeBetweenness" : 67.0,
        "shared_name" : "giant (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "giant (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1881,
        "BEND_MAP_ID" : 1881,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1877",
        "source" : "1875",
        "target" : "277",
        "EdgeBetweenness" : 70.0,
        "shared_name" : "underground (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "underground (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1877,
        "BEND_MAP_ID" : 1877,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1871",
        "source" : "1869",
        "target" : "277",
        "EdgeBetweenness" : 74.0,
        "shared_name" : "humorless (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "humorless (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1871,
        "BEND_MAP_ID" : 1871,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2355",
        "source" : "1861",
        "target" : "277",
        "EdgeBetweenness" : 78.0,
        "shared_name" : "lean (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "lean (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2355,
        "BEND_MAP_ID" : 2355,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1863",
        "source" : "1861",
        "target" : "277",
        "EdgeBetweenness" : 78.0,
        "shared_name" : "lean (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "lean (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1863,
        "BEND_MAP_ID" : 1863,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1855",
        "source" : "1853",
        "target" : "277",
        "EdgeBetweenness" : 81.0,
        "shared_name" : "dizzying (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "dizzying (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1855,
        "BEND_MAP_ID" : 1855,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2393",
        "source" : "1847",
        "target" : "277",
        "EdgeBetweenness" : 84.0,
        "shared_name" : "personal (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "personal (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2393,
        "BEND_MAP_ID" : 2393,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1849",
        "source" : "1847",
        "target" : "277",
        "EdgeBetweenness" : 84.0,
        "shared_name" : "personal (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "personal (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1849,
        "BEND_MAP_ID" : 1849,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1845",
        "source" : "1843",
        "target" : "277",
        "EdgeBetweenness" : 88.0,
        "shared_name" : "vantage (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "vantage (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1845,
        "BEND_MAP_ID" : 1845,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1837",
        "source" : "1835",
        "target" : "277",
        "EdgeBetweenness" : 91.0,
        "shared_name" : "original (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "original (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1837,
        "BEND_MAP_ID" : 1837,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1831",
        "source" : "1829",
        "target" : "277",
        "EdgeBetweenness" : 93.0,
        "shared_name" : "like (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "like (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1831,
        "BEND_MAP_ID" : 1831,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1823",
        "source" : "1821",
        "target" : "277",
        "EdgeBetweenness" : 95.0,
        "shared_name" : "taut (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "taut (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1823,
        "BEND_MAP_ID" : 1823,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3127",
        "source" : "1817",
        "target" : "277",
        "EdgeBetweenness" : 96.0,
        "shared_name" : "soft (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "soft (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3127,
        "BEND_MAP_ID" : 3127,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1819",
        "source" : "1817",
        "target" : "277",
        "EdgeBetweenness" : 96.0,
        "shared_name" : "soft (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "soft (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1819,
        "BEND_MAP_ID" : 1819,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1813",
        "source" : "1811",
        "target" : "277",
        "EdgeBetweenness" : 98.0,
        "shared_name" : "spirited (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "spirited (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1813,
        "BEND_MAP_ID" : 1813,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1841",
        "source" : "1805",
        "target" : "277",
        "EdgeBetweenness" : 100.0,
        "shared_name" : "tall (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "tall (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1841,
        "BEND_MAP_ID" : 1841,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1839",
        "source" : "1805",
        "target" : "277",
        "EdgeBetweenness" : 100.0,
        "shared_name" : "tall (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "tall (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1839,
        "BEND_MAP_ID" : 1839,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1807",
        "source" : "1805",
        "target" : "277",
        "EdgeBetweenness" : 100.0,
        "shared_name" : "tall (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "tall (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1807,
        "BEND_MAP_ID" : 1807,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3119",
        "source" : "1801",
        "target" : "277",
        "EdgeBetweenness" : 103.0,
        "shared_name" : "skinny (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "skinny (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3119,
        "BEND_MAP_ID" : 3119,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1803",
        "source" : "1801",
        "target" : "277",
        "EdgeBetweenness" : 103.0,
        "shared_name" : "skinny (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "skinny (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1803,
        "BEND_MAP_ID" : 1803,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1795",
        "source" : "1793",
        "target" : "277",
        "EdgeBetweenness" : 106.0,
        "shared_name" : "graphic (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "graphic (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1795,
        "BEND_MAP_ID" : 1795,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1783",
        "source" : "1781",
        "target" : "277",
        "EdgeBetweenness" : 112.0,
        "shared_name" : "extra (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "extra (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1783,
        "BEND_MAP_ID" : 1783,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1779",
        "source" : "1777",
        "target" : "277",
        "EdgeBetweenness" : 115.0,
        "shared_name" : "hourly (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "hourly (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1779,
        "BEND_MAP_ID" : 1779,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2915",
        "source" : "1773",
        "target" : "277",
        "EdgeBetweenness" : 118.0,
        "shared_name" : "large (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "large (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2915,
        "BEND_MAP_ID" : 2915,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2645",
        "source" : "1773",
        "target" : "277",
        "EdgeBetweenness" : 118.0,
        "shared_name" : "large (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "large (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2645,
        "BEND_MAP_ID" : 2645,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2641",
        "source" : "1773",
        "target" : "277",
        "EdgeBetweenness" : 118.0,
        "shared_name" : "large (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "large (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2641,
        "BEND_MAP_ID" : 2641,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1775",
        "source" : "1773",
        "target" : "277",
        "EdgeBetweenness" : 118.0,
        "shared_name" : "large (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "large (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1775,
        "BEND_MAP_ID" : 1775,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1771",
        "source" : "1769",
        "target" : "277",
        "EdgeBetweenness" : 120.0,
        "shared_name" : "heartless (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "heartless (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1771,
        "BEND_MAP_ID" : 1771,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1767",
        "source" : "1765",
        "target" : "277",
        "EdgeBetweenness" : 121.0,
        "shared_name" : "hey (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "hey (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1767,
        "BEND_MAP_ID" : 1767,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1763",
        "source" : "1761",
        "target" : "277",
        "EdgeBetweenness" : 123.0,
        "shared_name" : "flabbergasted (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "flabbergasted (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1763,
        "BEND_MAP_ID" : 1763,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3343",
        "source" : "1747",
        "target" : "277",
        "EdgeBetweenness" : 130.0,
        "shared_name" : "puzzled (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "puzzled (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3343,
        "BEND_MAP_ID" : 3343,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2983",
        "source" : "1747",
        "target" : "277",
        "EdgeBetweenness" : 130.0,
        "shared_name" : "puzzled (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "puzzled (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2983,
        "BEND_MAP_ID" : 2983,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1873",
        "source" : "1747",
        "target" : "277",
        "EdgeBetweenness" : 130.0,
        "shared_name" : "puzzled (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "puzzled (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1873,
        "BEND_MAP_ID" : 1873,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1749",
        "source" : "1747",
        "target" : "277",
        "EdgeBetweenness" : 130.0,
        "shared_name" : "puzzled (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "puzzled (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1749,
        "BEND_MAP_ID" : 1749,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1743",
        "source" : "1741",
        "target" : "277",
        "EdgeBetweenness" : 132.0,
        "shared_name" : "unable (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "unable (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1743,
        "BEND_MAP_ID" : 1743,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1739",
        "source" : "1737",
        "target" : "277",
        "EdgeBetweenness" : 134.0,
        "shared_name" : "awful (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "awful (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1739,
        "BEND_MAP_ID" : 1739,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1733",
        "source" : "1729",
        "target" : "277",
        "EdgeBetweenness" : 136.0,
        "shared_name" : "mannequin (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "mannequin (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1733,
        "BEND_MAP_ID" : 1733,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1731",
        "source" : "1729",
        "target" : "277",
        "EdgeBetweenness" : 136.0,
        "shared_name" : "mannequin (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "mannequin (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1731,
        "BEND_MAP_ID" : 1731,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1727",
        "source" : "1725",
        "target" : "277",
        "EdgeBetweenness" : 139.0,
        "shared_name" : "metallic (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "metallic (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1727,
        "BEND_MAP_ID" : 1727,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2795",
        "source" : "1719",
        "target" : "277",
        "EdgeBetweenness" : 143.0,
        "shared_name" : "baffled (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "baffled (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2795,
        "BEND_MAP_ID" : 2795,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1721",
        "source" : "1719",
        "target" : "277",
        "EdgeBetweenness" : 143.0,
        "shared_name" : "baffled (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "baffled (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1721,
        "BEND_MAP_ID" : 1721,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1713",
        "source" : "1711",
        "target" : "277",
        "EdgeBetweenness" : 147.0,
        "shared_name" : "additional (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "additional (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1713,
        "BEND_MAP_ID" : 1713,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1709",
        "source" : "1707",
        "target" : "277",
        "EdgeBetweenness" : 149.0,
        "shared_name" : "mature (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "mature (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1709,
        "BEND_MAP_ID" : 1709,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1705",
        "source" : "1703",
        "target" : "277",
        "EdgeBetweenness" : 151.0,
        "shared_name" : "ax (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "ax (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1705,
        "BEND_MAP_ID" : 1705,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1701",
        "source" : "1699",
        "target" : "277",
        "EdgeBetweenness" : 152.0,
        "shared_name" : "adjacent (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "adjacent (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1701,
        "BEND_MAP_ID" : 1701,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1695",
        "source" : "1693",
        "target" : "277",
        "EdgeBetweenness" : 156.0,
        "shared_name" : "local (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "local (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1695,
        "BEND_MAP_ID" : 1695,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3233",
        "source" : "1687",
        "target" : "277",
        "EdgeBetweenness" : 160.0,
        "shared_name" : "teenage (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "teenage (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3233,
        "BEND_MAP_ID" : 3233,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3157",
        "source" : "1687",
        "target" : "277",
        "EdgeBetweenness" : 160.0,
        "shared_name" : "teenage (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "teenage (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3157,
        "BEND_MAP_ID" : 3157,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1689",
        "source" : "1687",
        "target" : "277",
        "EdgeBetweenness" : 160.0,
        "shared_name" : "teenage (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "teenage (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1689,
        "BEND_MAP_ID" : 1689,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1685",
        "source" : "1683",
        "target" : "277",
        "EdgeBetweenness" : 162.0,
        "shared_name" : "puss (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "puss (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1685,
        "BEND_MAP_ID" : 1685,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1681",
        "source" : "1679",
        "target" : "277",
        "EdgeBetweenness" : 164.0,
        "shared_name" : "sour (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "sour (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1681,
        "BEND_MAP_ID" : 1681,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1859",
        "source" : "1673",
        "target" : "277",
        "EdgeBetweenness" : 167.0,
        "shared_name" : "aged (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "aged (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1859,
        "BEND_MAP_ID" : 1859,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1675",
        "source" : "1673",
        "target" : "277",
        "EdgeBetweenness" : 167.0,
        "shared_name" : "aged (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "aged (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1675,
        "BEND_MAP_ID" : 1675,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1671",
        "source" : "1669",
        "target" : "277",
        "EdgeBetweenness" : 170.0,
        "shared_name" : "thrilled (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "thrilled (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1671,
        "BEND_MAP_ID" : 1671,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1665",
        "source" : "1663",
        "target" : "277",
        "EdgeBetweenness" : 173.0,
        "shared_name" : "latter (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "latter (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1665,
        "BEND_MAP_ID" : 1665,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1661",
        "source" : "1659",
        "target" : "277",
        "EdgeBetweenness" : 176.0,
        "shared_name" : "hearty (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "hearty (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1661,
        "BEND_MAP_ID" : 1661,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1657",
        "source" : "1655",
        "target" : "277",
        "EdgeBetweenness" : 179.0,
        "shared_name" : "slavic (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "slavic (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1657,
        "BEND_MAP_ID" : 1657,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2063",
        "source" : "1651",
        "target" : "277",
        "EdgeBetweenness" : 180.0,
        "shared_name" : "polite (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "polite (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2063,
        "BEND_MAP_ID" : 2063,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1653",
        "source" : "1651",
        "target" : "277",
        "EdgeBetweenness" : 180.0,
        "shared_name" : "polite (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "polite (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1653,
        "BEND_MAP_ID" : 1653,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1649",
        "source" : "1647",
        "target" : "277",
        "EdgeBetweenness" : 183.0,
        "shared_name" : "chipper (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "chipper (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1649,
        "BEND_MAP_ID" : 1649,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1643",
        "source" : "1641",
        "target" : "277",
        "EdgeBetweenness" : 186.0,
        "shared_name" : "pooped (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "pooped (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1643,
        "BEND_MAP_ID" : 1643,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1635",
        "source" : "1633",
        "target" : "277",
        "EdgeBetweenness" : 190.0,
        "shared_name" : "solid (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "solid (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1635,
        "BEND_MAP_ID" : 1635,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1623",
        "source" : "1621",
        "target" : "277",
        "EdgeBetweenness" : 196.0,
        "shared_name" : "silver (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "silver (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1623,
        "BEND_MAP_ID" : 1623,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1615",
        "source" : "1613",
        "target" : "277",
        "EdgeBetweenness" : 199.0,
        "shared_name" : "cocky (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "cocky (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1615,
        "BEND_MAP_ID" : 1615,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1609",
        "source" : "1607",
        "target" : "277",
        "EdgeBetweenness" : 200.0,
        "shared_name" : "fresh (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "fresh (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1609,
        "BEND_MAP_ID" : 1609,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1601",
        "source" : "1599",
        "target" : "277",
        "EdgeBetweenness" : 204.0,
        "shared_name" : "necessary (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "necessary (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1601,
        "BEND_MAP_ID" : 1601,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3337",
        "source" : "1595",
        "target" : "277",
        "EdgeBetweenness" : 206.0,
        "shared_name" : "bold (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "bold (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3337,
        "BEND_MAP_ID" : 3337,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3263",
        "source" : "1595",
        "target" : "277",
        "EdgeBetweenness" : 206.0,
        "shared_name" : "bold (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "bold (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3263,
        "BEND_MAP_ID" : 3263,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3179",
        "source" : "1595",
        "target" : "277",
        "EdgeBetweenness" : 206.0,
        "shared_name" : "bold (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "bold (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3179,
        "BEND_MAP_ID" : 3179,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2183",
        "source" : "1595",
        "target" : "277",
        "EdgeBetweenness" : 206.0,
        "shared_name" : "bold (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "bold (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2183,
        "BEND_MAP_ID" : 2183,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1597",
        "source" : "1595",
        "target" : "277",
        "EdgeBetweenness" : 206.0,
        "shared_name" : "bold (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "bold (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1597,
        "BEND_MAP_ID" : 1597,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1593",
        "source" : "1591",
        "target" : "277",
        "EdgeBetweenness" : 208.0,
        "shared_name" : "risky (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "risky (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1593,
        "BEND_MAP_ID" : 1593,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3339",
        "source" : "1587",
        "target" : "277",
        "EdgeBetweenness" : 211.0,
        "shared_name" : "quick (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "quick (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3339,
        "BEND_MAP_ID" : 3339,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3031",
        "source" : "1587",
        "target" : "277",
        "EdgeBetweenness" : 211.0,
        "shared_name" : "quick (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "quick (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3031,
        "BEND_MAP_ID" : 3031,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3007",
        "source" : "1587",
        "target" : "277",
        "EdgeBetweenness" : 211.0,
        "shared_name" : "quick (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "quick (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3007,
        "BEND_MAP_ID" : 3007,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1589",
        "source" : "1587",
        "target" : "277",
        "EdgeBetweenness" : 211.0,
        "shared_name" : "quick (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "quick (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1589,
        "BEND_MAP_ID" : 1589,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1585",
        "source" : "1583",
        "target" : "277",
        "EdgeBetweenness" : 213.0,
        "shared_name" : "fabulous (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "fabulous (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1585,
        "BEND_MAP_ID" : 1585,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1953",
        "source" : "1579",
        "target" : "277",
        "EdgeBetweenness" : 216.0,
        "shared_name" : "comfortable (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "comfortable (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1953,
        "BEND_MAP_ID" : 1953,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1951",
        "source" : "1579",
        "target" : "277",
        "EdgeBetweenness" : 216.0,
        "shared_name" : "comfortable (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "comfortable (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1951,
        "BEND_MAP_ID" : 1951,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1581",
        "source" : "1579",
        "target" : "277",
        "EdgeBetweenness" : 216.0,
        "shared_name" : "comfortable (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "comfortable (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1581,
        "BEND_MAP_ID" : 1581,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1575",
        "source" : "1573",
        "target" : "277",
        "EdgeBetweenness" : 220.0,
        "shared_name" : "hasty (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "hasty (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1575,
        "BEND_MAP_ID" : 1575,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2023",
        "source" : "1565",
        "target" : "277",
        "EdgeBetweenness" : 223.0,
        "shared_name" : "dear (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "dear (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2023,
        "BEND_MAP_ID" : 2023,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1567",
        "source" : "1565",
        "target" : "277",
        "EdgeBetweenness" : 223.0,
        "shared_name" : "dear (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "dear (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1567,
        "BEND_MAP_ID" : 1567,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1561",
        "source" : "1559",
        "target" : "277",
        "EdgeBetweenness" : 226.0,
        "shared_name" : "terrific (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "terrific (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1561,
        "BEND_MAP_ID" : 1561,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1555",
        "source" : "1553",
        "target" : "277",
        "EdgeBetweenness" : 230.0,
        "shared_name" : "low (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "low (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1555,
        "BEND_MAP_ID" : 1555,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3105",
        "source" : "1543",
        "target" : "277",
        "EdgeBetweenness" : 234.0,
        "shared_name" : "top (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "top (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3105,
        "BEND_MAP_ID" : 3105,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3017",
        "source" : "1543",
        "target" : "277",
        "EdgeBetweenness" : 234.0,
        "shared_name" : "top (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "top (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3017,
        "BEND_MAP_ID" : 3017,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1545",
        "source" : "1543",
        "target" : "277",
        "EdgeBetweenness" : 234.0,
        "shared_name" : "top (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "top (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1545,
        "BEND_MAP_ID" : 1545,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1541",
        "source" : "1539",
        "target" : "277",
        "EdgeBetweenness" : 236.0,
        "shared_name" : "perfect (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "perfect (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1541,
        "BEND_MAP_ID" : 1541,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3527",
        "source" : "1535",
        "target" : "277",
        "EdgeBetweenness" : 238.0,
        "shared_name" : "crazy (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "crazy (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3527,
        "BEND_MAP_ID" : 3527,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1751",
        "source" : "1535",
        "target" : "277",
        "EdgeBetweenness" : 238.0,
        "shared_name" : "crazy (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "crazy (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1751,
        "BEND_MAP_ID" : 1751,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1537",
        "source" : "1535",
        "target" : "277",
        "EdgeBetweenness" : 238.0,
        "shared_name" : "crazy (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "crazy (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1537,
        "BEND_MAP_ID" : 1537,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1531",
        "source" : "1529",
        "target" : "277",
        "EdgeBetweenness" : 240.0,
        "shared_name" : "distinctive (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "distinctive (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1531,
        "BEND_MAP_ID" : 1531,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1521",
        "source" : "1519",
        "target" : "277",
        "EdgeBetweenness" : 246.0,
        "shared_name" : "simple (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "simple (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1521,
        "BEND_MAP_ID" : 1521,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3255",
        "source" : "1509",
        "target" : "277",
        "EdgeBetweenness" : 251.0,
        "shared_name" : "more (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "more (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3255,
        "BEND_MAP_ID" : 3255,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3109",
        "source" : "1509",
        "target" : "277",
        "EdgeBetweenness" : 251.0,
        "shared_name" : "more (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "more (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3109,
        "BEND_MAP_ID" : 3109,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3095",
        "source" : "1509",
        "target" : "277",
        "EdgeBetweenness" : 251.0,
        "shared_name" : "more (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "more (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3095,
        "BEND_MAP_ID" : 3095,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2847",
        "source" : "1509",
        "target" : "277",
        "EdgeBetweenness" : 251.0,
        "shared_name" : "more (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "more (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2847,
        "BEND_MAP_ID" : 2847,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1511",
        "source" : "1509",
        "target" : "277",
        "EdgeBetweenness" : 251.0,
        "shared_name" : "more (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "more (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1511,
        "BEND_MAP_ID" : 1511,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1507",
        "source" : "1505",
        "target" : "277",
        "EdgeBetweenness" : 252.0,
        "shared_name" : "Less (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "Less (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1507,
        "BEND_MAP_ID" : 1507,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1503",
        "source" : "1501",
        "target" : "277",
        "EdgeBetweenness" : 256.0,
        "shared_name" : "monotone (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "monotone (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1503,
        "BEND_MAP_ID" : 1503,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2561",
        "source" : "1497",
        "target" : "277",
        "EdgeBetweenness" : 258.0,
        "shared_name" : "grim (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "grim (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2561,
        "BEND_MAP_ID" : 2561,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2501",
        "source" : "1497",
        "target" : "277",
        "EdgeBetweenness" : 258.0,
        "shared_name" : "grim (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "grim (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2501,
        "BEND_MAP_ID" : 2501,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1499",
        "source" : "1497",
        "target" : "277",
        "EdgeBetweenness" : 258.0,
        "shared_name" : "grim (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "grim (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1499,
        "BEND_MAP_ID" : 1499,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1495",
        "source" : "1493",
        "target" : "277",
        "EdgeBetweenness" : 260.0,
        "shared_name" : "ashen (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "ashen (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1495,
        "BEND_MAP_ID" : 1495,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3201",
        "source" : "1489",
        "target" : "277",
        "EdgeBetweenness" : 263.0,
        "shared_name" : "red (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "red (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3201,
        "BEND_MAP_ID" : 3201,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1491",
        "source" : "1489",
        "target" : "277",
        "EdgeBetweenness" : 263.0,
        "shared_name" : "red (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "red (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1491,
        "BEND_MAP_ID" : 1491,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1487",
        "source" : "1485",
        "target" : "277",
        "EdgeBetweenness" : 264.0,
        "shared_name" : "erotic (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "erotic (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1487,
        "BEND_MAP_ID" : 1487,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1471",
        "source" : "1469",
        "target" : "277",
        "EdgeBetweenness" : 269.0,
        "shared_name" : "uncalled (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "uncalled (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1471,
        "BEND_MAP_ID" : 1471,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1459",
        "source" : "1457",
        "target" : "277",
        "EdgeBetweenness" : 275.0,
        "shared_name" : "incredulous (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "incredulous (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1459,
        "BEND_MAP_ID" : 1459,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2413",
        "source" : "1449",
        "target" : "277",
        "EdgeBetweenness" : 279.0,
        "shared_name" : "loud (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "loud (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2413,
        "BEND_MAP_ID" : 2413,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2343",
        "source" : "1449",
        "target" : "277",
        "EdgeBetweenness" : 279.0,
        "shared_name" : "loud (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "loud (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2343,
        "BEND_MAP_ID" : 2343,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1451",
        "source" : "1449",
        "target" : "277",
        "EdgeBetweenness" : 279.0,
        "shared_name" : "loud (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "loud (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1451,
        "BEND_MAP_ID" : 1451,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3107",
        "source" : "1445",
        "target" : "277",
        "EdgeBetweenness" : 283.0,
        "shared_name" : "few (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "few (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3107,
        "BEND_MAP_ID" : 3107,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3079",
        "source" : "1445",
        "target" : "277",
        "EdgeBetweenness" : 283.0,
        "shared_name" : "few (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "few (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3079,
        "BEND_MAP_ID" : 3079,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2947",
        "source" : "1445",
        "target" : "277",
        "EdgeBetweenness" : 283.0,
        "shared_name" : "few (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "few (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2947,
        "BEND_MAP_ID" : 2947,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2819",
        "source" : "1445",
        "target" : "277",
        "EdgeBetweenness" : 283.0,
        "shared_name" : "few (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "few (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2819,
        "BEND_MAP_ID" : 2819,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2511",
        "source" : "1445",
        "target" : "277",
        "EdgeBetweenness" : 283.0,
        "shared_name" : "few (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "few (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2511,
        "BEND_MAP_ID" : 2511,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2487",
        "source" : "1445",
        "target" : "277",
        "EdgeBetweenness" : 283.0,
        "shared_name" : "few (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "few (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2487,
        "BEND_MAP_ID" : 2487,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1447",
        "source" : "1445",
        "target" : "277",
        "EdgeBetweenness" : 283.0,
        "shared_name" : "few (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "few (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1447,
        "BEND_MAP_ID" : 1447,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1437",
        "source" : "1435",
        "target" : "277",
        "EdgeBetweenness" : 288.0,
        "shared_name" : "enthusiastic (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "enthusiastic (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1437,
        "BEND_MAP_ID" : 1437,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2497",
        "source" : "1425",
        "target" : "277",
        "EdgeBetweenness" : 294.0,
        "shared_name" : "impossible (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "impossible (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2497,
        "BEND_MAP_ID" : 2497,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1427",
        "source" : "1425",
        "target" : "277",
        "EdgeBetweenness" : 294.0,
        "shared_name" : "impossible (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "impossible (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1427,
        "BEND_MAP_ID" : 1427,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1423",
        "source" : "1421",
        "target" : "277",
        "EdgeBetweenness" : 296.0,
        "shared_name" : "shitless (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "shitless (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1423,
        "BEND_MAP_ID" : 1423,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1419",
        "source" : "1417",
        "target" : "277",
        "EdgeBetweenness" : 300.0,
        "shared_name" : "scared (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "scared (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1419,
        "BEND_MAP_ID" : 1419,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1755",
        "source" : "1409",
        "target" : "277",
        "EdgeBetweenness" : 303.0,
        "shared_name" : "goddamn (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "goddamn (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1755,
        "BEND_MAP_ID" : 1755,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1745",
        "source" : "1409",
        "target" : "277",
        "EdgeBetweenness" : 303.0,
        "shared_name" : "goddamn (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "goddamn (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1745,
        "BEND_MAP_ID" : 1745,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1411",
        "source" : "1409",
        "target" : "277",
        "EdgeBetweenness" : 303.0,
        "shared_name" : "goddamn (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "goddamn (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1411,
        "BEND_MAP_ID" : 1411,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1407",
        "source" : "1405",
        "target" : "277",
        "EdgeBetweenness" : 306.0,
        "shared_name" : "clear (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "clear (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1407,
        "BEND_MAP_ID" : 1407,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2005",
        "source" : "1399",
        "target" : "277",
        "EdgeBetweenness" : 310.0,
        "shared_name" : "french (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "french (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2005,
        "BEND_MAP_ID" : 2005,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1401",
        "source" : "1399",
        "target" : "277",
        "EdgeBetweenness" : 310.0,
        "shared_name" : "french (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "french (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1401,
        "BEND_MAP_ID" : 1401,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2661",
        "source" : "1395",
        "target" : "277",
        "EdgeBetweenness" : 314.0,
        "shared_name" : "embarrassed (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "embarrassed (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2661,
        "BEND_MAP_ID" : 2661,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1397",
        "source" : "1395",
        "target" : "277",
        "EdgeBetweenness" : 314.0,
        "shared_name" : "embarrassed (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "embarrassed (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1397,
        "BEND_MAP_ID" : 1397,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3249",
        "source" : "1389",
        "target" : "277",
        "EdgeBetweenness" : 317.0,
        "shared_name" : "phoney (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "phoney (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3249,
        "BEND_MAP_ID" : 3249,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1463",
        "source" : "1389",
        "target" : "277",
        "EdgeBetweenness" : 317.0,
        "shared_name" : "phoney (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "phoney (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1463,
        "BEND_MAP_ID" : 1463,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1391",
        "source" : "1389",
        "target" : "277",
        "EdgeBetweenness" : 317.0,
        "shared_name" : "phoney (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "phoney (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1391,
        "BEND_MAP_ID" : 1391,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3503",
        "source" : "1385",
        "target" : "277",
        "EdgeBetweenness" : 320.0,
        "shared_name" : "deep (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "deep (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3503,
        "BEND_MAP_ID" : 3503,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3111",
        "source" : "1385",
        "target" : "277",
        "EdgeBetweenness" : 320.0,
        "shared_name" : "deep (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "deep (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3111,
        "BEND_MAP_ID" : 3111,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1901",
        "source" : "1385",
        "target" : "277",
        "EdgeBetweenness" : 320.0,
        "shared_name" : "deep (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "deep (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1901,
        "BEND_MAP_ID" : 1901,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1443",
        "source" : "1385",
        "target" : "277",
        "EdgeBetweenness" : 320.0,
        "shared_name" : "deep (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "deep (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1443,
        "BEND_MAP_ID" : 1443,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1387",
        "source" : "1385",
        "target" : "277",
        "EdgeBetweenness" : 320.0,
        "shared_name" : "deep (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "deep (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1387,
        "BEND_MAP_ID" : 1387,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3491",
        "source" : "1375",
        "target" : "277",
        "EdgeBetweenness" : 326.0,
        "shared_name" : "same (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "same (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3491,
        "BEND_MAP_ID" : 3491,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1377",
        "source" : "1375",
        "target" : "277",
        "EdgeBetweenness" : 326.0,
        "shared_name" : "same (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "same (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1377,
        "BEND_MAP_ID" : 1377,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1369",
        "source" : "1367",
        "target" : "277",
        "EdgeBetweenness" : 331.0,
        "shared_name" : "ugly (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "ugly (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1369,
        "BEND_MAP_ID" : 1369,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1353",
        "source" : "1351",
        "target" : "277",
        "EdgeBetweenness" : 339.0,
        "shared_name" : "litttle (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "litttle (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1353,
        "BEND_MAP_ID" : 1353,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1349",
        "source" : "1347",
        "target" : "277",
        "EdgeBetweenness" : 341.0,
        "shared_name" : "nervy (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "nervy (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1349,
        "BEND_MAP_ID" : 1349,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3521",
        "source" : "1339",
        "target" : "277",
        "EdgeBetweenness" : 347.0,
        "shared_name" : "happy (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "happy (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3521,
        "BEND_MAP_ID" : 3521,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2851",
        "source" : "1339",
        "target" : "277",
        "EdgeBetweenness" : 347.0,
        "shared_name" : "happy (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "happy (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2851,
        "BEND_MAP_ID" : 2851,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2095",
        "source" : "1339",
        "target" : "277",
        "EdgeBetweenness" : 347.0,
        "shared_name" : "happy (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "happy (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2095,
        "BEND_MAP_ID" : 2095,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1341",
        "source" : "1339",
        "target" : "277",
        "EdgeBetweenness" : 347.0,
        "shared_name" : "happy (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "happy (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1341,
        "BEND_MAP_ID" : 1341,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1895",
        "source" : "1329",
        "target" : "277",
        "EdgeBetweenness" : 351.0,
        "shared_name" : "annoyed (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "annoyed (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1895,
        "BEND_MAP_ID" : 1895,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1331",
        "source" : "1329",
        "target" : "277",
        "EdgeBetweenness" : 351.0,
        "shared_name" : "annoyed (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "annoyed (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1331,
        "BEND_MAP_ID" : 1331,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1327",
        "source" : "1325",
        "target" : "277",
        "EdgeBetweenness" : 355.0,
        "shared_name" : "startled (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "startled (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1327,
        "BEND_MAP_ID" : 1327,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1323",
        "source" : "1321",
        "target" : "277",
        "EdgeBetweenness" : 357.0,
        "shared_name" : "daytime (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "daytime (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1323,
        "BEND_MAP_ID" : 1323,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2637",
        "source" : "1313",
        "target" : "277",
        "EdgeBetweenness" : 361.0,
        "shared_name" : "suspicious (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "suspicious (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2637,
        "BEND_MAP_ID" : 2637,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1571",
        "source" : "1313",
        "target" : "277",
        "EdgeBetweenness" : 361.0,
        "shared_name" : "suspicious (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "suspicious (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1571,
        "BEND_MAP_ID" : 1571,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1551",
        "source" : "1313",
        "target" : "277",
        "EdgeBetweenness" : 361.0,
        "shared_name" : "suspicious (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "suspicious (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1551,
        "BEND_MAP_ID" : 1551,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1523",
        "source" : "1313",
        "target" : "277",
        "EdgeBetweenness" : 361.0,
        "shared_name" : "suspicious (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "suspicious (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1523,
        "BEND_MAP_ID" : 1523,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1441",
        "source" : "1313",
        "target" : "277",
        "EdgeBetweenness" : 361.0,
        "shared_name" : "suspicious (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "suspicious (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1441,
        "BEND_MAP_ID" : 1441,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1315",
        "source" : "1313",
        "target" : "277",
        "EdgeBetweenness" : 361.0,
        "shared_name" : "suspicious (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "suspicious (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1315,
        "BEND_MAP_ID" : 1315,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1301",
        "source" : "1299",
        "target" : "277",
        "EdgeBetweenness" : 369.0,
        "shared_name" : "tweedy (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "tweedy (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1301,
        "BEND_MAP_ID" : 1301,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1295",
        "source" : "1293",
        "target" : "277",
        "EdgeBetweenness" : 372.0,
        "shared_name" : "satisfied (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "satisfied (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1295,
        "BEND_MAP_ID" : 1295,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1291",
        "source" : "1285",
        "target" : "277",
        "EdgeBetweenness" : 373.0,
        "shared_name" : "strategic (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "strategic (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1291,
        "BEND_MAP_ID" : 1291,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1287",
        "source" : "1285",
        "target" : "277",
        "EdgeBetweenness" : 373.0,
        "shared_name" : "strategic (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "strategic (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1287,
        "BEND_MAP_ID" : 1287,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1283",
        "source" : "1281",
        "target" : "277",
        "EdgeBetweenness" : 376.0,
        "shared_name" : "critical (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "critical (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1283,
        "BEND_MAP_ID" : 1283,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1279",
        "source" : "1277",
        "target" : "277",
        "EdgeBetweenness" : 379.0,
        "shared_name" : "concerned (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "concerned (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1279,
        "BEND_MAP_ID" : 1279,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1481",
        "source" : "1267",
        "target" : "277",
        "EdgeBetweenness" : 382.0,
        "shared_name" : "heraldic (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "heraldic (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1481,
        "BEND_MAP_ID" : 1481,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1269",
        "source" : "1267",
        "target" : "277",
        "EdgeBetweenness" : 382.0,
        "shared_name" : "heraldic (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "heraldic (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1269,
        "BEND_MAP_ID" : 1269,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1265",
        "source" : "1263",
        "target" : "277",
        "EdgeBetweenness" : 385.0,
        "shared_name" : "disappointed (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "disappointed (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1265,
        "BEND_MAP_ID" : 1265,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1261",
        "source" : "1259",
        "target" : "277",
        "EdgeBetweenness" : 387.0,
        "shared_name" : "headed (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "headed (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1261,
        "BEND_MAP_ID" : 1261,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1255",
        "source" : "1253",
        "target" : "277",
        "EdgeBetweenness" : 389.0,
        "shared_name" : "abnormal (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "abnormal (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1255,
        "BEND_MAP_ID" : 1255,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1249",
        "source" : "1247",
        "target" : "277",
        "EdgeBetweenness" : 391.0,
        "shared_name" : "catholic (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "catholic (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1249,
        "BEND_MAP_ID" : 1249,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1243",
        "source" : "1241",
        "target" : "277",
        "EdgeBetweenness" : 394.0,
        "shared_name" : "normal (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "normal (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1243,
        "BEND_MAP_ID" : 1243,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1233",
        "source" : "1231",
        "target" : "277",
        "EdgeBetweenness" : 398.0,
        "shared_name" : "mammoth (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "mammoth (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1233,
        "BEND_MAP_ID" : 1233,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1251",
        "source" : "1225",
        "target" : "277",
        "EdgeBetweenness" : 400.0,
        "shared_name" : "dumb (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "dumb (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1251,
        "BEND_MAP_ID" : 1251,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1227",
        "source" : "1225",
        "target" : "277",
        "EdgeBetweenness" : 400.0,
        "shared_name" : "dumb (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "dumb (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1227,
        "BEND_MAP_ID" : 1227,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2009",
        "source" : "1221",
        "target" : "277",
        "EdgeBetweenness" : 402.0,
        "shared_name" : "busy (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "busy (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2009,
        "BEND_MAP_ID" : 2009,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1223",
        "source" : "1221",
        "target" : "277",
        "EdgeBetweenness" : 402.0,
        "shared_name" : "busy (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "busy (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1223,
        "BEND_MAP_ID" : 1223,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3161",
        "source" : "1211",
        "target" : "277",
        "EdgeBetweenness" : 406.0,
        "shared_name" : "least (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "least (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3161,
        "BEND_MAP_ID" : 3161,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1213",
        "source" : "1211",
        "target" : "277",
        "EdgeBetweenness" : 406.0,
        "shared_name" : "least (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "least (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1213,
        "BEND_MAP_ID" : 1213,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2003",
        "source" : "1207",
        "target" : "277",
        "EdgeBetweenness" : 409.0,
        "shared_name" : "heavy (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "heavy (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2003,
        "BEND_MAP_ID" : 2003,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1209",
        "source" : "1207",
        "target" : "277",
        "EdgeBetweenness" : 409.0,
        "shared_name" : "heavy (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "heavy (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1209,
        "BEND_MAP_ID" : 1209,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3489",
        "source" : "1203",
        "target" : "277",
        "EdgeBetweenness" : 411.0,
        "shared_name" : "cool (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "cool (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3489,
        "BEND_MAP_ID" : 3489,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3487",
        "source" : "1203",
        "target" : "277",
        "EdgeBetweenness" : 411.0,
        "shared_name" : "cool (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "cool (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3487,
        "BEND_MAP_ID" : 3487,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3481",
        "source" : "1203",
        "target" : "277",
        "EdgeBetweenness" : 411.0,
        "shared_name" : "cool (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "cool (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3481,
        "BEND_MAP_ID" : 3481,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3389",
        "source" : "1203",
        "target" : "277",
        "EdgeBetweenness" : 411.0,
        "shared_name" : "cool (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "cool (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3389,
        "BEND_MAP_ID" : 3389,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3353",
        "source" : "1203",
        "target" : "277",
        "EdgeBetweenness" : 411.0,
        "shared_name" : "cool (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "cool (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3353,
        "BEND_MAP_ID" : 3353,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3293",
        "source" : "1203",
        "target" : "277",
        "EdgeBetweenness" : 411.0,
        "shared_name" : "cool (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "cool (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3293,
        "BEND_MAP_ID" : 3293,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3247",
        "source" : "1203",
        "target" : "277",
        "EdgeBetweenness" : 411.0,
        "shared_name" : "cool (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "cool (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3247,
        "BEND_MAP_ID" : 3247,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2863",
        "source" : "1203",
        "target" : "277",
        "EdgeBetweenness" : 411.0,
        "shared_name" : "cool (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "cool (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2863,
        "BEND_MAP_ID" : 2863,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2107",
        "source" : "1203",
        "target" : "277",
        "EdgeBetweenness" : 411.0,
        "shared_name" : "cool (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "cool (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2107,
        "BEND_MAP_ID" : 2107,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1983",
        "source" : "1203",
        "target" : "277",
        "EdgeBetweenness" : 411.0,
        "shared_name" : "cool (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "cool (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1983,
        "BEND_MAP_ID" : 1983,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1965",
        "source" : "1203",
        "target" : "277",
        "EdgeBetweenness" : 411.0,
        "shared_name" : "cool (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "cool (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1965,
        "BEND_MAP_ID" : 1965,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1205",
        "source" : "1203",
        "target" : "277",
        "EdgeBetweenness" : 411.0,
        "shared_name" : "cool (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "cool (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1205,
        "BEND_MAP_ID" : 1205,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1191",
        "source" : "1189",
        "target" : "277",
        "EdgeBetweenness" : 413.0,
        "shared_name" : "rude (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "rude (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1191,
        "BEND_MAP_ID" : 1191,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1185",
        "source" : "1183",
        "target" : "277",
        "EdgeBetweenness" : 417.0,
        "shared_name" : "darn (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "darn (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1185,
        "BEND_MAP_ID" : 1185,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1181",
        "source" : "1179",
        "target" : "277",
        "EdgeBetweenness" : 419.0,
        "shared_name" : "miserable (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "miserable (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1181,
        "BEND_MAP_ID" : 1181,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3429",
        "source" : "1169",
        "target" : "277",
        "EdgeBetweenness" : 423.0,
        "shared_name" : "other (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "other (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3429,
        "BEND_MAP_ID" : 3429,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3407",
        "source" : "1169",
        "target" : "277",
        "EdgeBetweenness" : 423.0,
        "shared_name" : "other (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "other (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3407,
        "BEND_MAP_ID" : 3407,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3215",
        "source" : "1169",
        "target" : "277",
        "EdgeBetweenness" : 423.0,
        "shared_name" : "other (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "other (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3215,
        "BEND_MAP_ID" : 3215,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3195",
        "source" : "1169",
        "target" : "277",
        "EdgeBetweenness" : 423.0,
        "shared_name" : "other (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "other (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3195,
        "BEND_MAP_ID" : 3195,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3149",
        "source" : "1169",
        "target" : "277",
        "EdgeBetweenness" : 423.0,
        "shared_name" : "other (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "other (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3149,
        "BEND_MAP_ID" : 3149,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3147",
        "source" : "1169",
        "target" : "277",
        "EdgeBetweenness" : 423.0,
        "shared_name" : "other (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "other (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3147,
        "BEND_MAP_ID" : 3147,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2967",
        "source" : "1169",
        "target" : "277",
        "EdgeBetweenness" : 423.0,
        "shared_name" : "other (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "other (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2967,
        "BEND_MAP_ID" : 2967,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2753",
        "source" : "1169",
        "target" : "277",
        "EdgeBetweenness" : 423.0,
        "shared_name" : "other (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "other (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2753,
        "BEND_MAP_ID" : 2753,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2663",
        "source" : "1169",
        "target" : "277",
        "EdgeBetweenness" : 423.0,
        "shared_name" : "other (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "other (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2663,
        "BEND_MAP_ID" : 2663,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2513",
        "source" : "1169",
        "target" : "277",
        "EdgeBetweenness" : 423.0,
        "shared_name" : "other (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "other (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2513,
        "BEND_MAP_ID" : 2513,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2173",
        "source" : "1169",
        "target" : "277",
        "EdgeBetweenness" : 423.0,
        "shared_name" : "other (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "other (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2173,
        "BEND_MAP_ID" : 2173,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2133",
        "source" : "1169",
        "target" : "277",
        "EdgeBetweenness" : 423.0,
        "shared_name" : "other (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "other (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2133,
        "BEND_MAP_ID" : 2133,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2121",
        "source" : "1169",
        "target" : "277",
        "EdgeBetweenness" : 423.0,
        "shared_name" : "other (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "other (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2121,
        "BEND_MAP_ID" : 2121,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1993",
        "source" : "1169",
        "target" : "277",
        "EdgeBetweenness" : 423.0,
        "shared_name" : "other (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "other (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1993,
        "BEND_MAP_ID" : 1993,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1943",
        "source" : "1169",
        "target" : "277",
        "EdgeBetweenness" : 423.0,
        "shared_name" : "other (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "other (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1943,
        "BEND_MAP_ID" : 1943,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1933",
        "source" : "1169",
        "target" : "277",
        "EdgeBetweenness" : 423.0,
        "shared_name" : "other (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "other (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1933,
        "BEND_MAP_ID" : 1933,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1645",
        "source" : "1169",
        "target" : "277",
        "EdgeBetweenness" : 423.0,
        "shared_name" : "other (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "other (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1645,
        "BEND_MAP_ID" : 1645,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1361",
        "source" : "1169",
        "target" : "277",
        "EdgeBetweenness" : 423.0,
        "shared_name" : "other (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "other (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1361,
        "BEND_MAP_ID" : 1361,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1359",
        "source" : "1169",
        "target" : "277",
        "EdgeBetweenness" : 423.0,
        "shared_name" : "other (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "other (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1359,
        "BEND_MAP_ID" : 1359,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1357",
        "source" : "1169",
        "target" : "277",
        "EdgeBetweenness" : 423.0,
        "shared_name" : "other (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "other (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1357,
        "BEND_MAP_ID" : 1357,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1171",
        "source" : "1169",
        "target" : "277",
        "EdgeBetweenness" : 423.0,
        "shared_name" : "other (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "other (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1171,
        "BEND_MAP_ID" : 1171,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1157",
        "source" : "1155",
        "target" : "277",
        "EdgeBetweenness" : 426.0,
        "shared_name" : "bullshit (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "bullshit (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1157,
        "BEND_MAP_ID" : 1157,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1143",
        "source" : "1141",
        "target" : "277",
        "EdgeBetweenness" : 430.0,
        "shared_name" : "glorious (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "glorious (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1143,
        "BEND_MAP_ID" : 1143,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3473",
        "source" : "1137",
        "target" : "277",
        "EdgeBetweenness" : 435.0,
        "shared_name" : "proud (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "proud (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3473,
        "BEND_MAP_ID" : 3473,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3341",
        "source" : "1137",
        "target" : "277",
        "EdgeBetweenness" : 435.0,
        "shared_name" : "proud (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "proud (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3341,
        "BEND_MAP_ID" : 3341,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3335",
        "source" : "1137",
        "target" : "277",
        "EdgeBetweenness" : 435.0,
        "shared_name" : "proud (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "proud (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3335,
        "BEND_MAP_ID" : 3335,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2959",
        "source" : "1137",
        "target" : "277",
        "EdgeBetweenness" : 435.0,
        "shared_name" : "proud (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "proud (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2959,
        "BEND_MAP_ID" : 2959,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1717",
        "source" : "1137",
        "target" : "277",
        "EdgeBetweenness" : 435.0,
        "shared_name" : "proud (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "proud (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1717,
        "BEND_MAP_ID" : 1717,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1527",
        "source" : "1137",
        "target" : "277",
        "EdgeBetweenness" : 435.0,
        "shared_name" : "proud (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "proud (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1527,
        "BEND_MAP_ID" : 1527,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1139",
        "source" : "1137",
        "target" : "277",
        "EdgeBetweenness" : 435.0,
        "shared_name" : "proud (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "proud (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1139,
        "BEND_MAP_ID" : 1139,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2015",
        "source" : "1133",
        "target" : "277",
        "EdgeBetweenness" : 436.0,
        "shared_name" : "impressed (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "impressed (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2015,
        "BEND_MAP_ID" : 2015,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1135",
        "source" : "1133",
        "target" : "277",
        "EdgeBetweenness" : 436.0,
        "shared_name" : "impressed (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "impressed (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1135,
        "BEND_MAP_ID" : 1135,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2849",
        "source" : "1127",
        "target" : "277",
        "EdgeBetweenness" : 440.0,
        "shared_name" : "popular (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "popular (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2849,
        "BEND_MAP_ID" : 2849,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2495",
        "source" : "1127",
        "target" : "277",
        "EdgeBetweenness" : 440.0,
        "shared_name" : "popular (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "popular (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2495,
        "BEND_MAP_ID" : 2495,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1129",
        "source" : "1127",
        "target" : "277",
        "EdgeBetweenness" : 440.0,
        "shared_name" : "popular (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "popular (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1129,
        "BEND_MAP_ID" : 1129,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1119",
        "source" : "1117",
        "target" : "277",
        "EdgeBetweenness" : 445.0,
        "shared_name" : "dangerous (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "dangerous (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1119,
        "BEND_MAP_ID" : 1119,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3363",
        "source" : "1113",
        "target" : "277",
        "EdgeBetweenness" : 446.0,
        "shared_name" : "long (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "long (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3363,
        "BEND_MAP_ID" : 3363,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3235",
        "source" : "1113",
        "target" : "277",
        "EdgeBetweenness" : 446.0,
        "shared_name" : "long (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "long (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3235,
        "BEND_MAP_ID" : 3235,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2913",
        "source" : "1113",
        "target" : "277",
        "EdgeBetweenness" : 446.0,
        "shared_name" : "long (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "long (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2913,
        "BEND_MAP_ID" : 2913,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2429",
        "source" : "1113",
        "target" : "277",
        "EdgeBetweenness" : 446.0,
        "shared_name" : "long (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "long (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2429,
        "BEND_MAP_ID" : 2429,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2425",
        "source" : "1113",
        "target" : "277",
        "EdgeBetweenness" : 446.0,
        "shared_name" : "long (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "long (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2425,
        "BEND_MAP_ID" : 2425,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2237",
        "source" : "1113",
        "target" : "277",
        "EdgeBetweenness" : 446.0,
        "shared_name" : "long (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "long (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2237,
        "BEND_MAP_ID" : 2237,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1799",
        "source" : "1113",
        "target" : "277",
        "EdgeBetweenness" : 446.0,
        "shared_name" : "long (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "long (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1799,
        "BEND_MAP_ID" : 1799,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1115",
        "source" : "1113",
        "target" : "277",
        "EdgeBetweenness" : 446.0,
        "shared_name" : "long (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "long (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1115,
        "BEND_MAP_ID" : 1115,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2585",
        "source" : "1097",
        "target" : "277",
        "EdgeBetweenness" : 450.0,
        "shared_name" : "excited (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "excited (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2585,
        "BEND_MAP_ID" : 2585,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1667",
        "source" : "1097",
        "target" : "277",
        "EdgeBetweenness" : 450.0,
        "shared_name" : "excited (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "excited (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1667,
        "BEND_MAP_ID" : 1667,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1099",
        "source" : "1097",
        "target" : "277",
        "EdgeBetweenness" : 450.0,
        "shared_name" : "excited (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "excited (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1099,
        "BEND_MAP_ID" : 1099,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1095",
        "source" : "1089",
        "target" : "277",
        "EdgeBetweenness" : 452.0,
        "shared_name" : "third (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "third (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1095,
        "BEND_MAP_ID" : 1095,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1091",
        "source" : "1089",
        "target" : "277",
        "EdgeBetweenness" : 452.0,
        "shared_name" : "third (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "third (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1091,
        "BEND_MAP_ID" : 1091,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2199",
        "source" : "1081",
        "target" : "277",
        "EdgeBetweenness" : 456.0,
        "shared_name" : "second (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "second (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2199,
        "BEND_MAP_ID" : 2199,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2013",
        "source" : "1081",
        "target" : "277",
        "EdgeBetweenness" : 456.0,
        "shared_name" : "second (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "second (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2013,
        "BEND_MAP_ID" : 2013,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1453",
        "source" : "1081",
        "target" : "277",
        "EdgeBetweenness" : 456.0,
        "shared_name" : "second (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "second (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1453,
        "BEND_MAP_ID" : 1453,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1373",
        "source" : "1081",
        "target" : "277",
        "EdgeBetweenness" : 456.0,
        "shared_name" : "second (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "second (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1373,
        "BEND_MAP_ID" : 1373,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1195",
        "source" : "1081",
        "target" : "277",
        "EdgeBetweenness" : 456.0,
        "shared_name" : "second (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "second (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1195,
        "BEND_MAP_ID" : 1195,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1173",
        "source" : "1081",
        "target" : "277",
        "EdgeBetweenness" : 456.0,
        "shared_name" : "second (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "second (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1173,
        "BEND_MAP_ID" : 1173,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1103",
        "source" : "1081",
        "target" : "277",
        "EdgeBetweenness" : 456.0,
        "shared_name" : "second (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "second (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1103,
        "BEND_MAP_ID" : 1103,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1093",
        "source" : "1081",
        "target" : "277",
        "EdgeBetweenness" : 456.0,
        "shared_name" : "second (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "second (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1093,
        "BEND_MAP_ID" : 1093,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1087",
        "source" : "1081",
        "target" : "277",
        "EdgeBetweenness" : 456.0,
        "shared_name" : "second (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "second (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1087,
        "BEND_MAP_ID" : 1087,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1085",
        "source" : "1081",
        "target" : "277",
        "EdgeBetweenness" : 456.0,
        "shared_name" : "second (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "second (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1085,
        "BEND_MAP_ID" : 1085,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1083",
        "source" : "1081",
        "target" : "277",
        "EdgeBetweenness" : 456.0,
        "shared_name" : "second (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "second (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1083,
        "BEND_MAP_ID" : 1083,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3515",
        "source" : "1077",
        "target" : "277",
        "EdgeBetweenness" : 459.0,
        "shared_name" : "sweet (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "sweet (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3515,
        "BEND_MAP_ID" : 3515,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1433",
        "source" : "1077",
        "target" : "277",
        "EdgeBetweenness" : 459.0,
        "shared_name" : "sweet (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "sweet (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1433,
        "BEND_MAP_ID" : 1433,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1079",
        "source" : "1077",
        "target" : "277",
        "EdgeBetweenness" : 459.0,
        "shared_name" : "sweet (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "sweet (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1079,
        "BEND_MAP_ID" : 1079,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1063",
        "source" : "1061",
        "target" : "277",
        "EdgeBetweenness" : 463.0,
        "shared_name" : "throbbing (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "throbbing (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1063,
        "BEND_MAP_ID" : 1063,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1057",
        "source" : "1055",
        "target" : "277",
        "EdgeBetweenness" : 465.0,
        "shared_name" : "prone (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "prone (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1057,
        "BEND_MAP_ID" : 1057,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3371",
        "source" : "1051",
        "target" : "277",
        "EdgeBetweenness" : 467.0,
        "shared_name" : "ill (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "ill (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3371,
        "BEND_MAP_ID" : 3371,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2833",
        "source" : "1051",
        "target" : "277",
        "EdgeBetweenness" : 467.0,
        "shared_name" : "ill (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "ill (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2833,
        "BEND_MAP_ID" : 2833,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2631",
        "source" : "1051",
        "target" : "277",
        "EdgeBetweenness" : 467.0,
        "shared_name" : "ill (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "ill (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2631,
        "BEND_MAP_ID" : 2631,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2595",
        "source" : "1051",
        "target" : "277",
        "EdgeBetweenness" : 467.0,
        "shared_name" : "ill (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "ill (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2595,
        "BEND_MAP_ID" : 2595,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1053",
        "source" : "1051",
        "target" : "277",
        "EdgeBetweenness" : 467.0,
        "shared_name" : "ill (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "ill (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1053,
        "BEND_MAP_ID" : 1053,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1047",
        "source" : "1045",
        "target" : "277",
        "EdgeBetweenness" : 470.0,
        "shared_name" : "absent (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "absent (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1047,
        "BEND_MAP_ID" : 1047,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1043",
        "source" : "1041",
        "target" : "277",
        "EdgeBetweenness" : 472.0,
        "shared_name" : "mistaken (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "mistaken (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1043,
        "BEND_MAP_ID" : 1043,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1617",
        "source" : "1035",
        "target" : "277",
        "EdgeBetweenness" : 475.0,
        "shared_name" : "confident (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "confident (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1617,
        "BEND_MAP_ID" : 1617,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1037",
        "source" : "1035",
        "target" : "277",
        "EdgeBetweenness" : 475.0,
        "shared_name" : "confident (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "confident (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1037,
        "BEND_MAP_ID" : 1037,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1431",
        "source" : "1031",
        "target" : "277",
        "EdgeBetweenness" : 477.0,
        "shared_name" : "short (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "short (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1431,
        "BEND_MAP_ID" : 1431,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1033",
        "source" : "1031",
        "target" : "277",
        "EdgeBetweenness" : 477.0,
        "shared_name" : "short (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "short (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1033,
        "BEND_MAP_ID" : 1033,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1865",
        "source" : "1027",
        "target" : "277",
        "EdgeBetweenness" : 479.0,
        "shared_name" : "clean (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "clean (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1865,
        "BEND_MAP_ID" : 1865,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1029",
        "source" : "1027",
        "target" : "277",
        "EdgeBetweenness" : 479.0,
        "shared_name" : "clean (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "clean (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1029,
        "BEND_MAP_ID" : 1029,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1867",
        "source" : "1023",
        "target" : "277",
        "EdgeBetweenness" : 480.0,
        "shared_name" : "tough (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "tough (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1867,
        "BEND_MAP_ID" : 1867,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1025",
        "source" : "1023",
        "target" : "277",
        "EdgeBetweenness" : 480.0,
        "shared_name" : "tough (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "tough (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1025,
        "BEND_MAP_ID" : 1025,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1019",
        "source" : "1017",
        "target" : "277",
        "EdgeBetweenness" : 482.0,
        "shared_name" : "exemplary (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "exemplary (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1019,
        "BEND_MAP_ID" : 1019,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1065",
        "source" : "1007",
        "target" : "277",
        "EdgeBetweenness" : 485.0,
        "shared_name" : "passing (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "passing (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1065,
        "BEND_MAP_ID" : 1065,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1009",
        "source" : "1007",
        "target" : "277",
        "EdgeBetweenness" : 485.0,
        "shared_name" : "passing (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "passing (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1009,
        "BEND_MAP_ID" : 1009,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "991",
        "source" : "989",
        "target" : "277",
        "EdgeBetweenness" : 7.0,
        "shared_name" : "realistic (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "realistic (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 991,
        "BEND_MAP_ID" : 991,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2411",
        "source" : "977",
        "target" : "277",
        "EdgeBetweenness" : 9.0,
        "shared_name" : "suburban (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "suburban (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2411,
        "BEND_MAP_ID" : 2411,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1605",
        "source" : "977",
        "target" : "277",
        "EdgeBetweenness" : 9.0,
        "shared_name" : "suburban (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "suburban (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1605,
        "BEND_MAP_ID" : 1605,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1001",
        "source" : "977",
        "target" : "277",
        "EdgeBetweenness" : 9.0,
        "shared_name" : "suburban (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "suburban (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1001,
        "BEND_MAP_ID" : 1001,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "979",
        "source" : "977",
        "target" : "277",
        "EdgeBetweenness" : 9.0,
        "shared_name" : "suburban (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "suburban (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 979,
        "BEND_MAP_ID" : 979,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3041",
        "source" : "971",
        "target" : "277",
        "EdgeBetweenness" : 13.0,
        "shared_name" : "light (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "light (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3041,
        "BEND_MAP_ID" : 3041,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1691",
        "source" : "971",
        "target" : "277",
        "EdgeBetweenness" : 13.0,
        "shared_name" : "light (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "light (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1691,
        "BEND_MAP_ID" : 1691,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "973",
        "source" : "971",
        "target" : "277",
        "EdgeBetweenness" : 13.0,
        "shared_name" : "light (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "light (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 973,
        "BEND_MAP_ID" : 973,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2807",
        "source" : "965",
        "target" : "277",
        "EdgeBetweenness" : 14.0,
        "shared_name" : "small (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "small (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2807,
        "BEND_MAP_ID" : 2807,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2363",
        "source" : "965",
        "target" : "277",
        "EdgeBetweenness" : 14.0,
        "shared_name" : "small (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "small (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2363,
        "BEND_MAP_ID" : 2363,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1631",
        "source" : "965",
        "target" : "277",
        "EdgeBetweenness" : 14.0,
        "shared_name" : "small (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "small (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1631,
        "BEND_MAP_ID" : 1631,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1479",
        "source" : "965",
        "target" : "277",
        "EdgeBetweenness" : 14.0,
        "shared_name" : "small (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "small (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1479,
        "BEND_MAP_ID" : 1479,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "967",
        "source" : "965",
        "target" : "277",
        "EdgeBetweenness" : 14.0,
        "shared_name" : "small (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "small (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 967,
        "BEND_MAP_ID" : 967,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "963",
        "source" : "961",
        "target" : "277",
        "EdgeBetweenness" : 15.0,
        "shared_name" : "modest (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "modest (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 963,
        "BEND_MAP_ID" : 963,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "957",
        "source" : "955",
        "target" : "277",
        "EdgeBetweenness" : 18.0,
        "shared_name" : "crisp (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "crisp (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 957,
        "BEND_MAP_ID" : 957,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "953",
        "source" : "951",
        "target" : "277",
        "EdgeBetweenness" : 21.0,
        "shared_name" : "matted (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "matted (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 953,
        "BEND_MAP_ID" : 953,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1305",
        "source" : "945",
        "target" : "277",
        "EdgeBetweenness" : 24.0,
        "shared_name" : "dusty (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "dusty (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1305,
        "BEND_MAP_ID" : 1305,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "947",
        "source" : "945",
        "target" : "277",
        "EdgeBetweenness" : 24.0,
        "shared_name" : "dusty (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "dusty (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 947,
        "BEND_MAP_ID" : 947,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2733",
        "source" : "939",
        "target" : "277",
        "EdgeBetweenness" : 26.0,
        "shared_name" : "familiar (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "familiar (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2733,
        "BEND_MAP_ID" : 2733,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "941",
        "source" : "939",
        "target" : "277",
        "EdgeBetweenness" : 26.0,
        "shared_name" : "familiar (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "familiar (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 941,
        "BEND_MAP_ID" : 941,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "937",
        "source" : "935",
        "target" : "277",
        "EdgeBetweenness" : 29.0,
        "shared_name" : "single (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "single (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 937,
        "BEND_MAP_ID" : 937,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "933",
        "source" : "931",
        "target" : "277",
        "EdgeBetweenness" : 30.0,
        "shared_name" : "mint (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "mint (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 933,
        "BEND_MAP_ID" : 933,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1547",
        "source" : "927",
        "target" : "277",
        "EdgeBetweenness" : 33.0,
        "shared_name" : "obvious (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "obvious (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1547,
        "BEND_MAP_ID" : 1547,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1335",
        "source" : "927",
        "target" : "277",
        "EdgeBetweenness" : 33.0,
        "shared_name" : "obvious (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "obvious (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1335,
        "BEND_MAP_ID" : 1335,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1307",
        "source" : "927",
        "target" : "277",
        "EdgeBetweenness" : 33.0,
        "shared_name" : "obvious (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "obvious (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1307,
        "BEND_MAP_ID" : 1307,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "929",
        "source" : "927",
        "target" : "277",
        "EdgeBetweenness" : 33.0,
        "shared_name" : "obvious (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "obvious (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 929,
        "BEND_MAP_ID" : 929,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2483",
        "source" : "923",
        "target" : "277",
        "EdgeBetweenness" : 34.0,
        "shared_name" : "hard (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "hard (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2483,
        "BEND_MAP_ID" : 2483,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1319",
        "source" : "923",
        "target" : "277",
        "EdgeBetweenness" : 34.0,
        "shared_name" : "hard (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "hard (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1319,
        "BEND_MAP_ID" : 1319,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1237",
        "source" : "923",
        "target" : "277",
        "EdgeBetweenness" : 34.0,
        "shared_name" : "hard (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "hard (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1237,
        "BEND_MAP_ID" : 1237,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1109",
        "source" : "923",
        "target" : "277",
        "EdgeBetweenness" : 34.0,
        "shared_name" : "hard (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "hard (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1109,
        "BEND_MAP_ID" : 1109,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "925",
        "source" : "923",
        "target" : "277",
        "EdgeBetweenness" : 34.0,
        "shared_name" : "hard (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "hard (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 925,
        "BEND_MAP_ID" : 925,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1735",
        "source" : "919",
        "target" : "277",
        "EdgeBetweenness" : 37.0,
        "shared_name" : "stiff (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "stiff (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1735,
        "BEND_MAP_ID" : 1735,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "921",
        "source" : "919",
        "target" : "277",
        "EdgeBetweenness" : 37.0,
        "shared_name" : "stiff (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "stiff (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 921,
        "BEND_MAP_ID" : 921,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "917",
        "source" : "915",
        "target" : "277",
        "EdgeBetweenness" : 38.0,
        "shared_name" : "sticky (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "sticky (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 917,
        "BEND_MAP_ID" : 917,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1549",
        "source" : "909",
        "target" : "277",
        "EdgeBetweenness" : 40.0,
        "shared_name" : "likely (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "likely (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1549,
        "BEND_MAP_ID" : 1549,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "911",
        "source" : "909",
        "target" : "277",
        "EdgeBetweenness" : 40.0,
        "shared_name" : "likely (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "likely (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 911,
        "BEND_MAP_ID" : 911,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "907",
        "source" : "905",
        "target" : "277",
        "EdgeBetweenness" : 41.0,
        "shared_name" : "insensitive (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "insensitive (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 907,
        "BEND_MAP_ID" : 907,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2037",
        "source" : "901",
        "target" : "277",
        "EdgeBetweenness" : 44.0,
        "shared_name" : "wicked (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "wicked (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2037,
        "BEND_MAP_ID" : 2037,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "903",
        "source" : "901",
        "target" : "277",
        "EdgeBetweenness" : 44.0,
        "shared_name" : "wicked (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "wicked (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 903,
        "BEND_MAP_ID" : 903,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "899",
        "source" : "897",
        "target" : "277",
        "EdgeBetweenness" : 45.0,
        "shared_name" : "gross (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "gross (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 899,
        "BEND_MAP_ID" : 899,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3423",
        "source" : "893",
        "target" : "277",
        "EdgeBetweenness" : 48.0,
        "shared_name" : "much (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "much (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3423,
        "BEND_MAP_ID" : 3423,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2909",
        "source" : "893",
        "target" : "277",
        "EdgeBetweenness" : 48.0,
        "shared_name" : "much (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "much (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2909,
        "BEND_MAP_ID" : 2909,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "895",
        "source" : "893",
        "target" : "277",
        "EdgeBetweenness" : 48.0,
        "shared_name" : "much (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "much (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 895,
        "BEND_MAP_ID" : 895,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "891",
        "source" : "889",
        "target" : "277",
        "EdgeBetweenness" : 51.0,
        "shared_name" : "damaging (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "damaging (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 891,
        "BEND_MAP_ID" : 891,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "887",
        "source" : "885",
        "target" : "277",
        "EdgeBetweenness" : 52.0,
        "shared_name" : "crumpled (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "crumpled (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 887,
        "BEND_MAP_ID" : 887,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3311",
        "source" : "881",
        "target" : "277",
        "EdgeBetweenness" : 55.0,
        "shared_name" : "blue (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "blue (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3311,
        "BEND_MAP_ID" : 3311,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2707",
        "source" : "881",
        "target" : "277",
        "EdgeBetweenness" : 55.0,
        "shared_name" : "blue (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "blue (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2707,
        "BEND_MAP_ID" : 2707,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2569",
        "source" : "881",
        "target" : "277",
        "EdgeBetweenness" : 55.0,
        "shared_name" : "blue (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "blue (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2569,
        "BEND_MAP_ID" : 2569,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2455",
        "source" : "881",
        "target" : "277",
        "EdgeBetweenness" : 55.0,
        "shared_name" : "blue (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "blue (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2455,
        "BEND_MAP_ID" : 2455,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1637",
        "source" : "881",
        "target" : "277",
        "EdgeBetweenness" : 55.0,
        "shared_name" : "blue (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "blue (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1637,
        "BEND_MAP_ID" : 1637,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1625",
        "source" : "881",
        "target" : "277",
        "EdgeBetweenness" : 55.0,
        "shared_name" : "blue (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "blue (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1625,
        "BEND_MAP_ID" : 1625,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "943",
        "source" : "881",
        "target" : "277",
        "EdgeBetweenness" : 55.0,
        "shared_name" : "blue (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "blue (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 943,
        "BEND_MAP_ID" : 943,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "883",
        "source" : "881",
        "target" : "277",
        "EdgeBetweenness" : 55.0,
        "shared_name" : "blue (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "blue (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 883,
        "BEND_MAP_ID" : 883,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "879",
        "source" : "875",
        "target" : "277",
        "EdgeBetweenness" : 58.0,
        "shared_name" : "pink (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "pink (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 879,
        "BEND_MAP_ID" : 879,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "877",
        "source" : "875",
        "target" : "277",
        "EdgeBetweenness" : 58.0,
        "shared_name" : "pink (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "pink (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 877,
        "BEND_MAP_ID" : 877,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "873",
        "source" : "871",
        "target" : "277",
        "EdgeBetweenness" : 60.0,
        "shared_name" : "petite (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "petite (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 873,
        "BEND_MAP_ID" : 873,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "867",
        "source" : "865",
        "target" : "277",
        "EdgeBetweenness" : 63.0,
        "shared_name" : "bumpy (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "bumpy (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 867,
        "BEND_MAP_ID" : 867,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "863",
        "source" : "861",
        "target" : "277",
        "EdgeBetweenness" : 64.0,
        "shared_name" : "rapid (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "rapid (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 863,
        "BEND_MAP_ID" : 863,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "859",
        "source" : "857",
        "target" : "277",
        "EdgeBetweenness" : 66.0,
        "shared_name" : "nitrous (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "nitrous (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 859,
        "BEND_MAP_ID" : 859,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3141",
        "source" : "853",
        "target" : "277",
        "EdgeBetweenness" : 69.0,
        "shared_name" : "real (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "real (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3141,
        "BEND_MAP_ID" : 3141,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3125",
        "source" : "853",
        "target" : "277",
        "EdgeBetweenness" : 69.0,
        "shared_name" : "real (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "real (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3125,
        "BEND_MAP_ID" : 3125,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2883",
        "source" : "853",
        "target" : "277",
        "EdgeBetweenness" : 69.0,
        "shared_name" : "real (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "real (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2883,
        "BEND_MAP_ID" : 2883,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2299",
        "source" : "853",
        "target" : "277",
        "EdgeBetweenness" : 69.0,
        "shared_name" : "real (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "real (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2299,
        "BEND_MAP_ID" : 2299,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1517",
        "source" : "853",
        "target" : "277",
        "EdgeBetweenness" : 69.0,
        "shared_name" : "real (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "real (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1517,
        "BEND_MAP_ID" : 1517,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "985",
        "source" : "853",
        "target" : "277",
        "EdgeBetweenness" : 69.0,
        "shared_name" : "real (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "real (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 985,
        "BEND_MAP_ID" : 985,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "975",
        "source" : "853",
        "target" : "277",
        "EdgeBetweenness" : 69.0,
        "shared_name" : "real (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "real (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 975,
        "BEND_MAP_ID" : 975,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "855",
        "source" : "853",
        "target" : "277",
        "EdgeBetweenness" : 69.0,
        "shared_name" : "real (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "real (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 855,
        "BEND_MAP_ID" : 855,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "851",
        "source" : "849",
        "target" : "277",
        "EdgeBetweenness" : 72.0,
        "shared_name" : "imaginary (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "imaginary (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 851,
        "BEND_MAP_ID" : 851,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "845",
        "source" : "843",
        "target" : "277",
        "EdgeBetweenness" : 75.0,
        "shared_name" : "cheery (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "cheery (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 845,
        "BEND_MAP_ID" : 845,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2385",
        "source" : "839",
        "target" : "277",
        "EdgeBetweenness" : 77.0,
        "shared_name" : "weary (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "weary (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2385,
        "BEND_MAP_ID" : 2385,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1165",
        "source" : "839",
        "target" : "277",
        "EdgeBetweenness" : 77.0,
        "shared_name" : "weary (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "weary (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1165,
        "BEND_MAP_ID" : 1165,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "841",
        "source" : "839",
        "target" : "277",
        "EdgeBetweenness" : 77.0,
        "shared_name" : "weary (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "weary (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 841,
        "BEND_MAP_ID" : 841,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3117",
        "source" : "827",
        "target" : "277",
        "EdgeBetweenness" : 83.0,
        "shared_name" : "empty (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "empty (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3117,
        "BEND_MAP_ID" : 3117,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2705",
        "source" : "827",
        "target" : "277",
        "EdgeBetweenness" : 83.0,
        "shared_name" : "empty (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "empty (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2705,
        "BEND_MAP_ID" : 2705,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "829",
        "source" : "827",
        "target" : "277",
        "EdgeBetweenness" : 83.0,
        "shared_name" : "empty (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "empty (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 829,
        "BEND_MAP_ID" : 829,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3077",
        "source" : "823",
        "target" : "277",
        "EdgeBetweenness" : 86.0,
        "shared_name" : "last (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "last (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3077,
        "BEND_MAP_ID" : 3077,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3025",
        "source" : "823",
        "target" : "277",
        "EdgeBetweenness" : 86.0,
        "shared_name" : "last (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "last (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3025,
        "BEND_MAP_ID" : 3025,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2949",
        "source" : "823",
        "target" : "277",
        "EdgeBetweenness" : 86.0,
        "shared_name" : "last (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "last (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2949,
        "BEND_MAP_ID" : 2949,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1415",
        "source" : "823",
        "target" : "277",
        "EdgeBetweenness" : 86.0,
        "shared_name" : "last (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "last (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1415,
        "BEND_MAP_ID" : 1415,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1175",
        "source" : "823",
        "target" : "277",
        "EdgeBetweenness" : 86.0,
        "shared_name" : "last (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "last (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1175,
        "BEND_MAP_ID" : 1175,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1125",
        "source" : "823",
        "target" : "277",
        "EdgeBetweenness" : 86.0,
        "shared_name" : "last (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "last (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1125,
        "BEND_MAP_ID" : 1125,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1039",
        "source" : "823",
        "target" : "277",
        "EdgeBetweenness" : 86.0,
        "shared_name" : "last (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "last (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1039,
        "BEND_MAP_ID" : 1039,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "835",
        "source" : "823",
        "target" : "277",
        "EdgeBetweenness" : 86.0,
        "shared_name" : "last (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "last (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 835,
        "BEND_MAP_ID" : 835,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "825",
        "source" : "823",
        "target" : "277",
        "EdgeBetweenness" : 86.0,
        "shared_name" : "last (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "last (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 825,
        "BEND_MAP_ID" : 825,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "821",
        "source" : "819",
        "target" : "277",
        "EdgeBetweenness" : 87.0,
        "shared_name" : "pristine (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "pristine (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 821,
        "BEND_MAP_ID" : 821,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "817",
        "source" : "815",
        "target" : "277",
        "EdgeBetweenness" : 89.0,
        "shared_name" : "yellow (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "yellow (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 817,
        "BEND_MAP_ID" : 817,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "949",
        "source" : "811",
        "target" : "277",
        "EdgeBetweenness" : 90.0,
        "shared_name" : "dirty (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "dirty (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 949,
        "BEND_MAP_ID" : 949,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "813",
        "source" : "811",
        "target" : "277",
        "EdgeBetweenness" : 90.0,
        "shared_name" : "dirty (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "dirty (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 813,
        "BEND_MAP_ID" : 813,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "809",
        "source" : "799",
        "target" : "277",
        "EdgeBetweenness" : 94.0,
        "shared_name" : "tight (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "tight (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 809,
        "BEND_MAP_ID" : 809,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "801",
        "source" : "799",
        "target" : "277",
        "EdgeBetweenness" : 94.0,
        "shared_name" : "tight (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "tight (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 801,
        "BEND_MAP_ID" : 801,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3479",
        "source" : "793",
        "target" : "277",
        "EdgeBetweenness" : 97.0,
        "shared_name" : "sorry (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "sorry (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3479,
        "BEND_MAP_ID" : 3479,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3075",
        "source" : "793",
        "target" : "277",
        "EdgeBetweenness" : 97.0,
        "shared_name" : "sorry (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "sorry (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3075,
        "BEND_MAP_ID" : 3075,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2861",
        "source" : "793",
        "target" : "277",
        "EdgeBetweenness" : 97.0,
        "shared_name" : "sorry (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "sorry (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2861,
        "BEND_MAP_ID" : 2861,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2831",
        "source" : "793",
        "target" : "277",
        "EdgeBetweenness" : 97.0,
        "shared_name" : "sorry (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "sorry (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2831,
        "BEND_MAP_ID" : 2831,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2629",
        "source" : "793",
        "target" : "277",
        "EdgeBetweenness" : 97.0,
        "shared_name" : "sorry (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "sorry (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2629,
        "BEND_MAP_ID" : 2629,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2593",
        "source" : "793",
        "target" : "277",
        "EdgeBetweenness" : 97.0,
        "shared_name" : "sorry (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "sorry (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2593,
        "BEND_MAP_ID" : 2593,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2387",
        "source" : "793",
        "target" : "277",
        "EdgeBetweenness" : 97.0,
        "shared_name" : "sorry (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "sorry (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2387,
        "BEND_MAP_ID" : 2387,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2007",
        "source" : "793",
        "target" : "277",
        "EdgeBetweenness" : 97.0,
        "shared_name" : "sorry (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "sorry (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2007,
        "BEND_MAP_ID" : 2007,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1991",
        "source" : "793",
        "target" : "277",
        "EdgeBetweenness" : 97.0,
        "shared_name" : "sorry (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "sorry (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1991,
        "BEND_MAP_ID" : 1991,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1533",
        "source" : "793",
        "target" : "277",
        "EdgeBetweenness" : 97.0,
        "shared_name" : "sorry (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "sorry (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1533,
        "BEND_MAP_ID" : 1533,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1515",
        "source" : "793",
        "target" : "277",
        "EdgeBetweenness" : 97.0,
        "shared_name" : "sorry (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "sorry (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1515,
        "BEND_MAP_ID" : 1515,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1467",
        "source" : "793",
        "target" : "277",
        "EdgeBetweenness" : 97.0,
        "shared_name" : "sorry (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "sorry (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1467,
        "BEND_MAP_ID" : 1467,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1393",
        "source" : "793",
        "target" : "277",
        "EdgeBetweenness" : 97.0,
        "shared_name" : "sorry (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "sorry (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1393,
        "BEND_MAP_ID" : 1393,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1379",
        "source" : "793",
        "target" : "277",
        "EdgeBetweenness" : 97.0,
        "shared_name" : "sorry (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "sorry (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1379,
        "BEND_MAP_ID" : 1379,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1069",
        "source" : "793",
        "target" : "277",
        "EdgeBetweenness" : 97.0,
        "shared_name" : "sorry (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "sorry (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1069,
        "BEND_MAP_ID" : 1069,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1067",
        "source" : "793",
        "target" : "277",
        "EdgeBetweenness" : 97.0,
        "shared_name" : "sorry (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "sorry (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1067,
        "BEND_MAP_ID" : 1067,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "995",
        "source" : "793",
        "target" : "277",
        "EdgeBetweenness" : 97.0,
        "shared_name" : "sorry (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "sorry (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 995,
        "BEND_MAP_ID" : 995,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "795",
        "source" : "793",
        "target" : "277",
        "EdgeBetweenness" : 97.0,
        "shared_name" : "sorry (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "sorry (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 795,
        "BEND_MAP_ID" : 795,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "785",
        "source" : "783",
        "target" : "277",
        "EdgeBetweenness" : 99.0,
        "shared_name" : "weak (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "weak (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 785,
        "BEND_MAP_ID" : 785,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "781",
        "source" : "779",
        "target" : "277",
        "EdgeBetweenness" : 101.0,
        "shared_name" : "random (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "random (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 781,
        "BEND_MAP_ID" : 781,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "773",
        "source" : "771",
        "target" : "277",
        "EdgeBetweenness" : 105.0,
        "shared_name" : "dreary (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "dreary (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 773,
        "BEND_MAP_ID" : 773,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "767",
        "source" : "765",
        "target" : "277",
        "EdgeBetweenness" : 108.0,
        "shared_name" : "prime (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "prime (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 767,
        "BEND_MAP_ID" : 767,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2777",
        "source" : "761",
        "target" : "277",
        "EdgeBetweenness" : 110.0,
        "shared_name" : "modern (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "modern (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2777,
        "BEND_MAP_ID" : 2777,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1611",
        "source" : "761",
        "target" : "277",
        "EdgeBetweenness" : 110.0,
        "shared_name" : "modern (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "modern (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1611,
        "BEND_MAP_ID" : 1611,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "999",
        "source" : "761",
        "target" : "277",
        "EdgeBetweenness" : 110.0,
        "shared_name" : "modern (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "modern (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 999,
        "BEND_MAP_ID" : 999,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "763",
        "source" : "761",
        "target" : "277",
        "EdgeBetweenness" : 110.0,
        "shared_name" : "modern (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "modern (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 763,
        "BEND_MAP_ID" : 763,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "759",
        "source" : "757",
        "target" : "277",
        "EdgeBetweenness" : 111.0,
        "shared_name" : "sleek (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "sleek (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 759,
        "BEND_MAP_ID" : 759,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "755",
        "source" : "753",
        "target" : "277",
        "EdgeBetweenness" : 114.0,
        "shared_name" : "rich (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "rich (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 755,
        "BEND_MAP_ID" : 755,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2319",
        "source" : "749",
        "target" : "277",
        "EdgeBetweenness" : 117.0,
        "shared_name" : "full (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "full (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2319,
        "BEND_MAP_ID" : 2319,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2315",
        "source" : "749",
        "target" : "277",
        "EdgeBetweenness" : 117.0,
        "shared_name" : "full (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "full (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2315,
        "BEND_MAP_ID" : 2315,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "751",
        "source" : "749",
        "target" : "277",
        "EdgeBetweenness" : 117.0,
        "shared_name" : "full (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "full (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 751,
        "BEND_MAP_ID" : 751,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "747",
        "source" : "745",
        "target" : "277",
        "EdgeBetweenness" : 119.0,
        "shared_name" : "strong (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "strong (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 747,
        "BEND_MAP_ID" : 747,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3381",
        "source" : "741",
        "target" : "277",
        "EdgeBetweenness" : 122.0,
        "shared_name" : "young (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "young (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3381,
        "BEND_MAP_ID" : 3381,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3091",
        "source" : "741",
        "target" : "277",
        "EdgeBetweenness" : 122.0,
        "shared_name" : "young (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "young (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3091,
        "BEND_MAP_ID" : 3091,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2419",
        "source" : "741",
        "target" : "277",
        "EdgeBetweenness" : 122.0,
        "shared_name" : "young (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "young (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2419,
        "BEND_MAP_ID" : 2419,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2333",
        "source" : "741",
        "target" : "277",
        "EdgeBetweenness" : 122.0,
        "shared_name" : "young (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "young (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2333,
        "BEND_MAP_ID" : 2333,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2329",
        "source" : "741",
        "target" : "277",
        "EdgeBetweenness" : 122.0,
        "shared_name" : "young (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "young (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2329,
        "BEND_MAP_ID" : 2329,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2313",
        "source" : "741",
        "target" : "277",
        "EdgeBetweenness" : 122.0,
        "shared_name" : "young (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "young (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2313,
        "BEND_MAP_ID" : 2313,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1919",
        "source" : "741",
        "target" : "277",
        "EdgeBetweenness" : 122.0,
        "shared_name" : "young (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "young (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1919,
        "BEND_MAP_ID" : 1919,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "743",
        "source" : "741",
        "target" : "277",
        "EdgeBetweenness" : 122.0,
        "shared_name" : "young (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "young (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 743,
        "BEND_MAP_ID" : 743,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3403",
        "source" : "737",
        "target" : "277",
        "EdgeBetweenness" : 125.0,
        "shared_name" : "loose (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "loose (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3403,
        "BEND_MAP_ID" : 3403,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3355",
        "source" : "737",
        "target" : "277",
        "EdgeBetweenness" : 125.0,
        "shared_name" : "loose (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "loose (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3355,
        "BEND_MAP_ID" : 3355,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "739",
        "source" : "737",
        "target" : "277",
        "EdgeBetweenness" : 125.0,
        "shared_name" : "loose (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "loose (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 739,
        "BEND_MAP_ID" : 739,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "913",
        "source" : "733",
        "target" : "277",
        "EdgeBetweenness" : 126.0,
        "shared_name" : "easy (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "easy (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 913,
        "BEND_MAP_ID" : 913,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "807",
        "source" : "733",
        "target" : "277",
        "EdgeBetweenness" : 126.0,
        "shared_name" : "easy (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "easy (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 807,
        "BEND_MAP_ID" : 807,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "735",
        "source" : "733",
        "target" : "277",
        "EdgeBetweenness" : 126.0,
        "shared_name" : "easy (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "easy (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 735,
        "BEND_MAP_ID" : 735,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2793",
        "source" : "725",
        "target" : "277",
        "EdgeBetweenness" : 128.0,
        "shared_name" : "bored (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "bored (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2793,
        "BEND_MAP_ID" : 2793,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1677",
        "source" : "725",
        "target" : "277",
        "EdgeBetweenness" : 128.0,
        "shared_name" : "bored (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "bored (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1677,
        "BEND_MAP_ID" : 1677,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "727",
        "source" : "725",
        "target" : "277",
        "EdgeBetweenness" : 128.0,
        "shared_name" : "bored (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "bored (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 727,
        "BEND_MAP_ID" : 727,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3523",
        "source" : "721",
        "target" : "277",
        "EdgeBetweenness" : 131.0,
        "shared_name" : "great (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "great (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3523,
        "BEND_MAP_ID" : 3523,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3417",
        "source" : "721",
        "target" : "277",
        "EdgeBetweenness" : 131.0,
        "shared_name" : "great (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "great (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3417,
        "BEND_MAP_ID" : 3417,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3387",
        "source" : "721",
        "target" : "277",
        "EdgeBetweenness" : 131.0,
        "shared_name" : "great (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "great (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3387,
        "BEND_MAP_ID" : 3387,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2929",
        "source" : "721",
        "target" : "277",
        "EdgeBetweenness" : 131.0,
        "shared_name" : "great (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "great (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2929,
        "BEND_MAP_ID" : 2929,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1887",
        "source" : "721",
        "target" : "277",
        "EdgeBetweenness" : 131.0,
        "shared_name" : "great (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "great (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1887,
        "BEND_MAP_ID" : 1887,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1577",
        "source" : "721",
        "target" : "277",
        "EdgeBetweenness" : 131.0,
        "shared_name" : "great (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "great (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1577,
        "BEND_MAP_ID" : 1577,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1429",
        "source" : "721",
        "target" : "277",
        "EdgeBetweenness" : 131.0,
        "shared_name" : "great (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "great (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1429,
        "BEND_MAP_ID" : 1429,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1217",
        "source" : "721",
        "target" : "277",
        "EdgeBetweenness" : 131.0,
        "shared_name" : "great (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "great (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1217,
        "BEND_MAP_ID" : 1217,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1201",
        "source" : "721",
        "target" : "277",
        "EdgeBetweenness" : 131.0,
        "shared_name" : "great (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "great (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1201,
        "BEND_MAP_ID" : 1201,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "723",
        "source" : "721",
        "target" : "277",
        "EdgeBetweenness" : 131.0,
        "shared_name" : "great (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "great (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 723,
        "BEND_MAP_ID" : 723,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1381",
        "source" : "715",
        "target" : "277",
        "EdgeBetweenness" : 133.0,
        "shared_name" : "possible (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "possible (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1381,
        "BEND_MAP_ID" : 1381,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "717",
        "source" : "715",
        "target" : "277",
        "EdgeBetweenness" : 133.0,
        "shared_name" : "possible (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "possible (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 717,
        "BEND_MAP_ID" : 717,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2375",
        "source" : "705",
        "target" : "277",
        "EdgeBetweenness" : 137.0,
        "shared_name" : "own (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "own (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2375,
        "BEND_MAP_ID" : 2375,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2373",
        "source" : "705",
        "target" : "277",
        "EdgeBetweenness" : 137.0,
        "shared_name" : "own (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "own (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2373,
        "BEND_MAP_ID" : 2373,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "719",
        "source" : "705",
        "target" : "277",
        "EdgeBetweenness" : 137.0,
        "shared_name" : "own (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "own (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 719,
        "BEND_MAP_ID" : 719,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "707",
        "source" : "705",
        "target" : "277",
        "EdgeBetweenness" : 137.0,
        "shared_name" : "own (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "own (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 707,
        "BEND_MAP_ID" : 707,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "703",
        "source" : "701",
        "target" : "277",
        "EdgeBetweenness" : 138.0,
        "shared_name" : "legit (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "legit (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 703,
        "BEND_MAP_ID" : 703,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3393",
        "source" : "697",
        "target" : "277",
        "EdgeBetweenness" : 141.0,
        "shared_name" : "sure (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "sure (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3393,
        "BEND_MAP_ID" : 3393,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3375",
        "source" : "697",
        "target" : "277",
        "EdgeBetweenness" : 141.0,
        "shared_name" : "sure (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "sure (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3375,
        "BEND_MAP_ID" : 3375,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2493",
        "source" : "697",
        "target" : "277",
        "EdgeBetweenness" : 141.0,
        "shared_name" : "sure (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "sure (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2493,
        "BEND_MAP_ID" : 2493,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2177",
        "source" : "697",
        "target" : "277",
        "EdgeBetweenness" : 141.0,
        "shared_name" : "sure (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "sure (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2177,
        "BEND_MAP_ID" : 2177,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1791",
        "source" : "697",
        "target" : "277",
        "EdgeBetweenness" : 141.0,
        "shared_name" : "sure (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "sure (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1791,
        "BEND_MAP_ID" : 1791,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1403",
        "source" : "697",
        "target" : "277",
        "EdgeBetweenness" : 141.0,
        "shared_name" : "sure (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "sure (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1403,
        "BEND_MAP_ID" : 1403,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1337",
        "source" : "697",
        "target" : "277",
        "EdgeBetweenness" : 141.0,
        "shared_name" : "sure (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "sure (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1337,
        "BEND_MAP_ID" : 1337,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1219",
        "source" : "697",
        "target" : "277",
        "EdgeBetweenness" : 141.0,
        "shared_name" : "sure (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "sure (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1219,
        "BEND_MAP_ID" : 1219,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1101",
        "source" : "697",
        "target" : "277",
        "EdgeBetweenness" : 141.0,
        "shared_name" : "sure (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "sure (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1101,
        "BEND_MAP_ID" : 1101,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "699",
        "source" : "697",
        "target" : "277",
        "EdgeBetweenness" : 141.0,
        "shared_name" : "sure (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "sure (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 699,
        "BEND_MAP_ID" : 699,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "695",
        "source" : "693",
        "target" : "277",
        "EdgeBetweenness" : 144.0,
        "shared_name" : "kinda (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "kinda (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 695,
        "BEND_MAP_ID" : 695,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "691",
        "source" : "689",
        "target" : "277",
        "EdgeBetweenness" : 145.0,
        "shared_name" : "conditioned (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "conditioned (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 691,
        "BEND_MAP_ID" : 691,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1715",
        "source" : "685",
        "target" : "277",
        "EdgeBetweenness" : 148.0,
        "shared_name" : "aware (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "aware (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1715,
        "BEND_MAP_ID" : 1715,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1015",
        "source" : "685",
        "target" : "277",
        "EdgeBetweenness" : 148.0,
        "shared_name" : "aware (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "aware (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1015,
        "BEND_MAP_ID" : 1015,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1005",
        "source" : "685",
        "target" : "277",
        "EdgeBetweenness" : 148.0,
        "shared_name" : "aware (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "aware (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1005,
        "BEND_MAP_ID" : 1005,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "687",
        "source" : "685",
        "target" : "277",
        "EdgeBetweenness" : 148.0,
        "shared_name" : "aware (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "aware (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 687,
        "BEND_MAP_ID" : 687,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1815",
        "source" : "675",
        "target" : "277",
        "EdgeBetweenness" : 153.0,
        "shared_name" : "dark (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "dark (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1815,
        "BEND_MAP_ID" : 1815,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "769",
        "source" : "675",
        "target" : "277",
        "EdgeBetweenness" : 153.0,
        "shared_name" : "dark (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "dark (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 769,
        "BEND_MAP_ID" : 769,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "677",
        "source" : "675",
        "target" : "277",
        "EdgeBetweenness" : 153.0,
        "shared_name" : "dark (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "dark (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 677,
        "BEND_MAP_ID" : 677,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "673",
        "source" : "671",
        "target" : "277",
        "EdgeBetweenness" : 155.0,
        "shared_name" : "artificial (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "artificial (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 673,
        "BEND_MAP_ID" : 673,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3267",
        "source" : "667",
        "target" : "277",
        "EdgeBetweenness" : 158.0,
        "shared_name" : "whole (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "whole (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3267,
        "BEND_MAP_ID" : 3267,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2907",
        "source" : "667",
        "target" : "277",
        "EdgeBetweenness" : 158.0,
        "shared_name" : "whole (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "whole (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2907,
        "BEND_MAP_ID" : 2907,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1075",
        "source" : "667",
        "target" : "277",
        "EdgeBetweenness" : 158.0,
        "shared_name" : "whole (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "whole (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1075,
        "BEND_MAP_ID" : 1075,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "731",
        "source" : "667",
        "target" : "277",
        "EdgeBetweenness" : 158.0,
        "shared_name" : "whole (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "whole (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 731,
        "BEND_MAP_ID" : 731,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "669",
        "source" : "667",
        "target" : "277",
        "EdgeBetweenness" : 158.0,
        "shared_name" : "whole (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "whole (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 669,
        "BEND_MAP_ID" : 669,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "663",
        "source" : "661",
        "target" : "277",
        "EdgeBetweenness" : 161.0,
        "shared_name" : "sad (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "sad (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 663,
        "BEND_MAP_ID" : 663,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "791",
        "source" : "657",
        "target" : "277",
        "EdgeBetweenness" : 163.0,
        "shared_name" : "complete (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "complete (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 791,
        "BEND_MAP_ID" : 791,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "659",
        "source" : "657",
        "target" : "277",
        "EdgeBetweenness" : 163.0,
        "shared_name" : "complete (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "complete (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 659,
        "BEND_MAP_ID" : 659,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2297",
        "source" : "653",
        "target" : "277",
        "EdgeBetweenness" : 165.0,
        "shared_name" : "dead (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "dead (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2297,
        "BEND_MAP_ID" : 2297,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1343",
        "source" : "653",
        "target" : "277",
        "EdgeBetweenness" : 165.0,
        "shared_name" : "dead (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "dead (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1343,
        "BEND_MAP_ID" : 1343,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1317",
        "source" : "653",
        "target" : "277",
        "EdgeBetweenness" : 165.0,
        "shared_name" : "dead (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "dead (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1317,
        "BEND_MAP_ID" : 1317,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1311",
        "source" : "653",
        "target" : "277",
        "EdgeBetweenness" : 165.0,
        "shared_name" : "dead (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "dead (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1311,
        "BEND_MAP_ID" : 1311,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1309",
        "source" : "653",
        "target" : "277",
        "EdgeBetweenness" : 165.0,
        "shared_name" : "dead (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "dead (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1309,
        "BEND_MAP_ID" : 1309,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1021",
        "source" : "653",
        "target" : "277",
        "EdgeBetweenness" : 165.0,
        "shared_name" : "dead (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "dead (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1021,
        "BEND_MAP_ID" : 1021,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "993",
        "source" : "653",
        "target" : "277",
        "EdgeBetweenness" : 165.0,
        "shared_name" : "dead (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "dead (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 993,
        "BEND_MAP_ID" : 993,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "655",
        "source" : "653",
        "target" : "277",
        "EdgeBetweenness" : 165.0,
        "shared_name" : "dead (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "dead (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 655,
        "BEND_MAP_ID" : 655,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3279",
        "source" : "647",
        "target" : "277",
        "EdgeBetweenness" : 169.0,
        "shared_name" : "only (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "only (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3279,
        "BEND_MAP_ID" : 3279,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2843",
        "source" : "647",
        "target" : "277",
        "EdgeBetweenness" : 169.0,
        "shared_name" : "only (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "only (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2843,
        "BEND_MAP_ID" : 2843,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2113",
        "source" : "647",
        "target" : "277",
        "EdgeBetweenness" : 169.0,
        "shared_name" : "only (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "only (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2113,
        "BEND_MAP_ID" : 2113,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1925",
        "source" : "647",
        "target" : "277",
        "EdgeBetweenness" : 169.0,
        "shared_name" : "only (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "only (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1925,
        "BEND_MAP_ID" : 1925,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1289",
        "source" : "647",
        "target" : "277",
        "EdgeBetweenness" : 169.0,
        "shared_name" : "only (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "only (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1289,
        "BEND_MAP_ID" : 1289,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1275",
        "source" : "647",
        "target" : "277",
        "EdgeBetweenness" : 169.0,
        "shared_name" : "only (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "only (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1275,
        "BEND_MAP_ID" : 1275,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "649",
        "source" : "647",
        "target" : "277",
        "EdgeBetweenness" : 169.0,
        "shared_name" : "only (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "only (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 649,
        "BEND_MAP_ID" : 649,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3467",
        "source" : "641",
        "target" : "277",
        "EdgeBetweenness" : 172.0,
        "shared_name" : "serious (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "serious (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3467,
        "BEND_MAP_ID" : 3467,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3305",
        "source" : "641",
        "target" : "277",
        "EdgeBetweenness" : 172.0,
        "shared_name" : "serious (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "serious (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3305,
        "BEND_MAP_ID" : 3305,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3243",
        "source" : "641",
        "target" : "277",
        "EdgeBetweenness" : 172.0,
        "shared_name" : "serious (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "serious (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3243,
        "BEND_MAP_ID" : 3243,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3241",
        "source" : "641",
        "target" : "277",
        "EdgeBetweenness" : 172.0,
        "shared_name" : "serious (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "serious (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3241,
        "BEND_MAP_ID" : 3241,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3155",
        "source" : "641",
        "target" : "277",
        "EdgeBetweenness" : 172.0,
        "shared_name" : "serious (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "serious (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3155,
        "BEND_MAP_ID" : 3155,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2293",
        "source" : "641",
        "target" : "277",
        "EdgeBetweenness" : 172.0,
        "shared_name" : "serious (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "serious (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2293,
        "BEND_MAP_ID" : 2293,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1913",
        "source" : "641",
        "target" : "277",
        "EdgeBetweenness" : 172.0,
        "shared_name" : "serious (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "serious (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1913,
        "BEND_MAP_ID" : 1913,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1911",
        "source" : "641",
        "target" : "277",
        "EdgeBetweenness" : 172.0,
        "shared_name" : "serious (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "serious (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1911,
        "BEND_MAP_ID" : 1911,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1475",
        "source" : "641",
        "target" : "277",
        "EdgeBetweenness" : 172.0,
        "shared_name" : "serious (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "serious (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1475,
        "BEND_MAP_ID" : 1475,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1473",
        "source" : "641",
        "target" : "277",
        "EdgeBetweenness" : 172.0,
        "shared_name" : "serious (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "serious (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1473,
        "BEND_MAP_ID" : 1473,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1153",
        "source" : "641",
        "target" : "277",
        "EdgeBetweenness" : 172.0,
        "shared_name" : "serious (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "serious (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1153,
        "BEND_MAP_ID" : 1153,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1105",
        "source" : "641",
        "target" : "277",
        "EdgeBetweenness" : 172.0,
        "shared_name" : "serious (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "serious (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1105,
        "BEND_MAP_ID" : 1105,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "837",
        "source" : "641",
        "target" : "277",
        "EdgeBetweenness" : 172.0,
        "shared_name" : "serious (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "serious (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 837,
        "BEND_MAP_ID" : 837,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "711",
        "source" : "641",
        "target" : "277",
        "EdgeBetweenness" : 172.0,
        "shared_name" : "serious (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "serious (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 711,
        "BEND_MAP_ID" : 711,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "643",
        "source" : "641",
        "target" : "277",
        "EdgeBetweenness" : 172.0,
        "shared_name" : "serious (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "serious (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 643,
        "BEND_MAP_ID" : 643,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "639",
        "source" : "637",
        "target" : "277",
        "EdgeBetweenness" : 175.0,
        "shared_name" : "eighth (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "eighth (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 639,
        "BEND_MAP_ID" : 639,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "633",
        "source" : "631",
        "target" : "277",
        "EdgeBetweenness" : 178.0,
        "shared_name" : "favorite (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "favorite (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 633,
        "BEND_MAP_ID" : 633,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "627",
        "source" : "625",
        "target" : "277",
        "EdgeBetweenness" : 182.0,
        "shared_name" : "touchy (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "touchy (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 627,
        "BEND_MAP_ID" : 627,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1569",
        "source" : "619",
        "target" : "277",
        "EdgeBetweenness" : 185.0,
        "shared_name" : "careful (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "careful (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1569,
        "BEND_MAP_ID" : 1569,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "621",
        "source" : "619",
        "target" : "277",
        "EdgeBetweenness" : 185.0,
        "shared_name" : "careful (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "careful (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 621,
        "BEND_MAP_ID" : 621,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "617",
        "source" : "615",
        "target" : "277",
        "EdgeBetweenness" : 188.0,
        "shared_name" : "guilty (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "guilty (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 617,
        "BEND_MAP_ID" : 617,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1245",
        "source" : "611",
        "target" : "277",
        "EdgeBetweenness" : 189.0,
        "shared_name" : "drunk (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "drunk (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1245,
        "BEND_MAP_ID" : 1245,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "613",
        "source" : "611",
        "target" : "277",
        "EdgeBetweenness" : 189.0,
        "shared_name" : "drunk (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "drunk (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 613,
        "BEND_MAP_ID" : 613,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "607",
        "source" : "605",
        "target" : "277",
        "EdgeBetweenness" : 192.0,
        "shared_name" : "political (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "political (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 607,
        "BEND_MAP_ID" : 607,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3163",
        "source" : "599",
        "target" : "277",
        "EdgeBetweenness" : 195.0,
        "shared_name" : "first (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "first (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3163,
        "BEND_MAP_ID" : 3163,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2893",
        "source" : "599",
        "target" : "277",
        "EdgeBetweenness" : 195.0,
        "shared_name" : "first (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "first (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2893,
        "BEND_MAP_ID" : 2893,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2709",
        "source" : "599",
        "target" : "277",
        "EdgeBetweenness" : 195.0,
        "shared_name" : "first (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "first (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2709,
        "BEND_MAP_ID" : 2709,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2221",
        "source" : "599",
        "target" : "277",
        "EdgeBetweenness" : 195.0,
        "shared_name" : "first (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "first (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2221,
        "BEND_MAP_ID" : 2221,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1383",
        "source" : "599",
        "target" : "277",
        "EdgeBetweenness" : 195.0,
        "shared_name" : "first (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "first (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1383,
        "BEND_MAP_ID" : 1383,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1131",
        "source" : "599",
        "target" : "277",
        "EdgeBetweenness" : 195.0,
        "shared_name" : "first (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "first (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1131,
        "BEND_MAP_ID" : 1131,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1013",
        "source" : "599",
        "target" : "277",
        "EdgeBetweenness" : 195.0,
        "shared_name" : "first (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "first (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1013,
        "BEND_MAP_ID" : 1013,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "601",
        "source" : "599",
        "target" : "277",
        "EdgeBetweenness" : 195.0,
        "shared_name" : "first (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "first (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 601,
        "BEND_MAP_ID" : 601,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3103",
        "source" : "593",
        "target" : "277",
        "EdgeBetweenness" : 197.0,
        "shared_name" : "different (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "different (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3103,
        "BEND_MAP_ID" : 3103,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "709",
        "source" : "593",
        "target" : "277",
        "EdgeBetweenness" : 197.0,
        "shared_name" : "different (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "different (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 709,
        "BEND_MAP_ID" : 709,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "595",
        "source" : "593",
        "target" : "277",
        "EdgeBetweenness" : 197.0,
        "shared_name" : "different (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "different (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 595,
        "BEND_MAP_ID" : 595,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "591",
        "source" : "589",
        "target" : "277",
        "EdgeBetweenness" : 198.0,
        "shared_name" : "fascist (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "fascist (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 591,
        "BEND_MAP_ID" : 591,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "587",
        "source" : "581",
        "target" : "277",
        "EdgeBetweenness" : 201.0,
        "shared_name" : "european (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "european (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 587,
        "BEND_MAP_ID" : 587,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "585",
        "source" : "581",
        "target" : "277",
        "EdgeBetweenness" : 201.0,
        "shared_name" : "european (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "european (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 585,
        "BEND_MAP_ID" : 585,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "583",
        "source" : "581",
        "target" : "277",
        "EdgeBetweenness" : 201.0,
        "shared_name" : "european (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "european (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 583,
        "BEND_MAP_ID" : 583,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "579",
        "source" : "577",
        "target" : "277",
        "EdgeBetweenness" : 202.0,
        "shared_name" : "pebbled (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "pebbled (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 579,
        "BEND_MAP_ID" : 579,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3507",
        "source" : "569",
        "target" : "277",
        "EdgeBetweenness" : 207.0,
        "shared_name" : "sick (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "sick (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3507,
        "BEND_MAP_ID" : 3507,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3445",
        "source" : "569",
        "target" : "277",
        "EdgeBetweenness" : 207.0,
        "shared_name" : "sick (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "sick (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3445,
        "BEND_MAP_ID" : 3445,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3443",
        "source" : "569",
        "target" : "277",
        "EdgeBetweenness" : 207.0,
        "shared_name" : "sick (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "sick (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3443,
        "BEND_MAP_ID" : 3443,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3205",
        "source" : "569",
        "target" : "277",
        "EdgeBetweenness" : 207.0,
        "shared_name" : "sick (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "sick (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3205,
        "BEND_MAP_ID" : 3205,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2809",
        "source" : "569",
        "target" : "277",
        "EdgeBetweenness" : 207.0,
        "shared_name" : "sick (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "sick (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2809,
        "BEND_MAP_ID" : 2809,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2447",
        "source" : "569",
        "target" : "277",
        "EdgeBetweenness" : 207.0,
        "shared_name" : "sick (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "sick (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2447,
        "BEND_MAP_ID" : 2447,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2119",
        "source" : "569",
        "target" : "277",
        "EdgeBetweenness" : 207.0,
        "shared_name" : "sick (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "sick (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2119,
        "BEND_MAP_ID" : 2119,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2033",
        "source" : "569",
        "target" : "277",
        "EdgeBetweenness" : 207.0,
        "shared_name" : "sick (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "sick (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2033,
        "BEND_MAP_ID" : 2033,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1723",
        "source" : "569",
        "target" : "277",
        "EdgeBetweenness" : 207.0,
        "shared_name" : "sick (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "sick (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1723,
        "BEND_MAP_ID" : 1723,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1461",
        "source" : "569",
        "target" : "277",
        "EdgeBetweenness" : 207.0,
        "shared_name" : "sick (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "sick (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1461,
        "BEND_MAP_ID" : 1461,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1257",
        "source" : "569",
        "target" : "277",
        "EdgeBetweenness" : 207.0,
        "shared_name" : "sick (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "sick (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1257,
        "BEND_MAP_ID" : 1257,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1229",
        "source" : "569",
        "target" : "277",
        "EdgeBetweenness" : 207.0,
        "shared_name" : "sick (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "sick (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1229,
        "BEND_MAP_ID" : 1229,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1215",
        "source" : "569",
        "target" : "277",
        "EdgeBetweenness" : 207.0,
        "shared_name" : "sick (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "sick (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1215,
        "BEND_MAP_ID" : 1215,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1159",
        "source" : "569",
        "target" : "277",
        "EdgeBetweenness" : 207.0,
        "shared_name" : "sick (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "sick (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1159,
        "BEND_MAP_ID" : 1159,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1073",
        "source" : "569",
        "target" : "277",
        "EdgeBetweenness" : 207.0,
        "shared_name" : "sick (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "sick (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1073,
        "BEND_MAP_ID" : 1073,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1071",
        "source" : "569",
        "target" : "277",
        "EdgeBetweenness" : 207.0,
        "shared_name" : "sick (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "sick (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1071,
        "BEND_MAP_ID" : 1071,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1059",
        "source" : "569",
        "target" : "277",
        "EdgeBetweenness" : 207.0,
        "shared_name" : "sick (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "sick (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1059,
        "BEND_MAP_ID" : 1059,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1011",
        "source" : "569",
        "target" : "277",
        "EdgeBetweenness" : 207.0,
        "shared_name" : "sick (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "sick (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1011,
        "BEND_MAP_ID" : 1011,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "831",
        "source" : "569",
        "target" : "277",
        "EdgeBetweenness" : 207.0,
        "shared_name" : "sick (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "sick (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 831,
        "BEND_MAP_ID" : 831,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "789",
        "source" : "569",
        "target" : "277",
        "EdgeBetweenness" : 207.0,
        "shared_name" : "sick (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "sick (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 789,
        "BEND_MAP_ID" : 789,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "775",
        "source" : "569",
        "target" : "277",
        "EdgeBetweenness" : 207.0,
        "shared_name" : "sick (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "sick (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 775,
        "BEND_MAP_ID" : 775,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "713",
        "source" : "569",
        "target" : "277",
        "EdgeBetweenness" : 207.0,
        "shared_name" : "sick (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "sick (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 713,
        "BEND_MAP_ID" : 713,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "571",
        "source" : "569",
        "target" : "277",
        "EdgeBetweenness" : 207.0,
        "shared_name" : "sick (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "sick (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 571,
        "BEND_MAP_ID" : 571,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2225",
        "source" : "565",
        "target" : "277",
        "EdgeBetweenness" : 210.0,
        "shared_name" : "ninth (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "ninth (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2225,
        "BEND_MAP_ID" : 2225,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "567",
        "source" : "565",
        "target" : "277",
        "EdgeBetweenness" : 210.0,
        "shared_name" : "ninth (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "ninth (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 567,
        "BEND_MAP_ID" : 567,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3439",
        "source" : "557",
        "target" : "277",
        "EdgeBetweenness" : 215.0,
        "shared_name" : "high (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "high (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3439,
        "BEND_MAP_ID" : 3439,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3153",
        "source" : "557",
        "target" : "277",
        "EdgeBetweenness" : 215.0,
        "shared_name" : "high (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "high (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3153,
        "BEND_MAP_ID" : 3153,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2911",
        "source" : "557",
        "target" : "277",
        "EdgeBetweenness" : 215.0,
        "shared_name" : "high (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "high (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2911,
        "BEND_MAP_ID" : 2911,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2763",
        "source" : "557",
        "target" : "277",
        "EdgeBetweenness" : 215.0,
        "shared_name" : "high (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "high (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2763,
        "BEND_MAP_ID" : 2763,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2559",
        "source" : "557",
        "target" : "277",
        "EdgeBetweenness" : 215.0,
        "shared_name" : "high (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "high (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2559,
        "BEND_MAP_ID" : 2559,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2555",
        "source" : "557",
        "target" : "277",
        "EdgeBetweenness" : 215.0,
        "shared_name" : "high (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "high (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2555,
        "BEND_MAP_ID" : 2555,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2453",
        "source" : "557",
        "target" : "277",
        "EdgeBetweenness" : 215.0,
        "shared_name" : "high (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "high (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2453,
        "BEND_MAP_ID" : 2453,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2239",
        "source" : "557",
        "target" : "277",
        "EdgeBetweenness" : 215.0,
        "shared_name" : "high (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "high (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2239,
        "BEND_MAP_ID" : 2239,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1629",
        "source" : "557",
        "target" : "277",
        "EdgeBetweenness" : 215.0,
        "shared_name" : "high (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "high (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1629,
        "BEND_MAP_ID" : 1629,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1627",
        "source" : "557",
        "target" : "277",
        "EdgeBetweenness" : 215.0,
        "shared_name" : "high (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "high (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1627,
        "BEND_MAP_ID" : 1627,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1003",
        "source" : "557",
        "target" : "277",
        "EdgeBetweenness" : 215.0,
        "shared_name" : "high (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "high (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1003,
        "BEND_MAP_ID" : 1003,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "997",
        "source" : "557",
        "target" : "277",
        "EdgeBetweenness" : 215.0,
        "shared_name" : "high (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "high (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 997,
        "BEND_MAP_ID" : 997,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "869",
        "source" : "557",
        "target" : "277",
        "EdgeBetweenness" : 215.0,
        "shared_name" : "high (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "high (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 869,
        "BEND_MAP_ID" : 869,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "777",
        "source" : "557",
        "target" : "277",
        "EdgeBetweenness" : 215.0,
        "shared_name" : "high (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "high (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 777,
        "BEND_MAP_ID" : 777,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "575",
        "source" : "557",
        "target" : "277",
        "EdgeBetweenness" : 215.0,
        "shared_name" : "high (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "high (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 575,
        "BEND_MAP_ID" : 575,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "559",
        "source" : "557",
        "target" : "277",
        "EdgeBetweenness" : 215.0,
        "shared_name" : "high (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "high (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 559,
        "BEND_MAP_ID" : 559,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "555",
        "source" : "553",
        "target" : "277",
        "EdgeBetweenness" : 217.0,
        "shared_name" : "childish (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "childish (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 555,
        "BEND_MAP_ID" : 555,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1455",
        "source" : "549",
        "target" : "277",
        "EdgeBetweenness" : 219.0,
        "shared_name" : "stupid (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "stupid (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1455,
        "BEND_MAP_ID" : 1455,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "551",
        "source" : "549",
        "target" : "277",
        "EdgeBetweenness" : 219.0,
        "shared_name" : "stupid (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "stupid (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 551,
        "BEND_MAP_ID" : 551,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3461",
        "source" : "543",
        "target" : "277",
        "EdgeBetweenness" : 222.0,
        "shared_name" : "new (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "new (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3461,
        "BEND_MAP_ID" : 3461,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3177",
        "source" : "543",
        "target" : "277",
        "EdgeBetweenness" : 222.0,
        "shared_name" : "new (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "new (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3177,
        "BEND_MAP_ID" : 3177,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1759",
        "source" : "543",
        "target" : "277",
        "EdgeBetweenness" : 222.0,
        "shared_name" : "new (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "new (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1759,
        "BEND_MAP_ID" : 1759,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1149",
        "source" : "543",
        "target" : "277",
        "EdgeBetweenness" : 222.0,
        "shared_name" : "new (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "new (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1149,
        "BEND_MAP_ID" : 1149,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "959",
        "source" : "543",
        "target" : "277",
        "EdgeBetweenness" : 222.0,
        "shared_name" : "new (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "new (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 959,
        "BEND_MAP_ID" : 959,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "545",
        "source" : "543",
        "target" : "277",
        "EdgeBetweenness" : 222.0,
        "shared_name" : "new (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "new (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 545,
        "BEND_MAP_ID" : 545,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "729",
        "source" : "537",
        "target" : "277",
        "EdgeBetweenness" : 225.0,
        "shared_name" : "nervous (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "nervous (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 729,
        "BEND_MAP_ID" : 729,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "539",
        "source" : "537",
        "target" : "277",
        "EdgeBetweenness" : 225.0,
        "shared_name" : "nervous (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "nervous (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 539,
        "BEND_MAP_ID" : 539,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "535",
        "source" : "533",
        "target" : "277",
        "EdgeBetweenness" : 227.0,
        "shared_name" : "pretty (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "pretty (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 535,
        "BEND_MAP_ID" : 535,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "683",
        "source" : "529",
        "target" : "277",
        "EdgeBetweenness" : 229.0,
        "shared_name" : "specific (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "specific (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 683,
        "BEND_MAP_ID" : 683,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "531",
        "source" : "529",
        "target" : "277",
        "EdgeBetweenness" : 229.0,
        "shared_name" : "specific (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "specific (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 531,
        "BEND_MAP_ID" : 531,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2619",
        "source" : "525",
        "target" : "277",
        "EdgeBetweenness" : 232.0,
        "shared_name" : "- (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "- (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2619,
        "BEND_MAP_ID" : 2619,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "527",
        "source" : "525",
        "target" : "277",
        "EdgeBetweenness" : 232.0,
        "shared_name" : "- (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "- (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 527,
        "BEND_MAP_ID" : 527,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "523",
        "source" : "521",
        "target" : "277",
        "EdgeBetweenness" : 233.0,
        "shared_name" : "non (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "non (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 523,
        "BEND_MAP_ID" : 523,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "517",
        "source" : "515",
        "target" : "277",
        "EdgeBetweenness" : 235.0,
        "shared_name" : "physical (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "physical (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 517,
        "BEND_MAP_ID" : 517,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2567",
        "source" : "509",
        "target" : "277",
        "EdgeBetweenness" : 239.0,
        "shared_name" : "beautiful (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "beautiful (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2567,
        "BEND_MAP_ID" : 2567,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2255",
        "source" : "509",
        "target" : "277",
        "EdgeBetweenness" : 239.0,
        "shared_name" : "beautiful (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "beautiful (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2255,
        "BEND_MAP_ID" : 2255,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1789",
        "source" : "509",
        "target" : "277",
        "EdgeBetweenness" : 239.0,
        "shared_name" : "beautiful (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "beautiful (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1789,
        "BEND_MAP_ID" : 1789,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1787",
        "source" : "509",
        "target" : "277",
        "EdgeBetweenness" : 239.0,
        "shared_name" : "beautiful (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "beautiful (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1787,
        "BEND_MAP_ID" : 1787,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1297",
        "source" : "509",
        "target" : "277",
        "EdgeBetweenness" : 239.0,
        "shared_name" : "beautiful (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "beautiful (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1297,
        "BEND_MAP_ID" : 1297,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1163",
        "source" : "509",
        "target" : "277",
        "EdgeBetweenness" : 239.0,
        "shared_name" : "beautiful (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "beautiful (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1163,
        "BEND_MAP_ID" : 1163,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "573",
        "source" : "509",
        "target" : "277",
        "EdgeBetweenness" : 239.0,
        "shared_name" : "beautiful (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "beautiful (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 573,
        "BEND_MAP_ID" : 573,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "511",
        "source" : "509",
        "target" : "277",
        "EdgeBetweenness" : 239.0,
        "shared_name" : "beautiful (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "beautiful (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 511,
        "BEND_MAP_ID" : 511,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3509",
        "source" : "505",
        "target" : "277",
        "EdgeBetweenness" : 241.0,
        "shared_name" : "bad (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "bad (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3509,
        "BEND_MAP_ID" : 3509,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3297",
        "source" : "505",
        "target" : "277",
        "EdgeBetweenness" : 241.0,
        "shared_name" : "bad (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "bad (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3297,
        "BEND_MAP_ID" : 3297,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2505",
        "source" : "505",
        "target" : "277",
        "EdgeBetweenness" : 241.0,
        "shared_name" : "bad (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "bad (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2505,
        "BEND_MAP_ID" : 2505,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2499",
        "source" : "505",
        "target" : "277",
        "EdgeBetweenness" : 241.0,
        "shared_name" : "bad (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "bad (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2499,
        "BEND_MAP_ID" : 2499,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2151",
        "source" : "505",
        "target" : "277",
        "EdgeBetweenness" : 241.0,
        "shared_name" : "bad (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "bad (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2151,
        "BEND_MAP_ID" : 2151,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2123",
        "source" : "505",
        "target" : "277",
        "EdgeBetweenness" : 241.0,
        "shared_name" : "bad (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "bad (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2123,
        "BEND_MAP_ID" : 2123,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1333",
        "source" : "505",
        "target" : "277",
        "EdgeBetweenness" : 241.0,
        "shared_name" : "bad (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "bad (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1333,
        "BEND_MAP_ID" : 1333,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1167",
        "source" : "505",
        "target" : "277",
        "EdgeBetweenness" : 241.0,
        "shared_name" : "bad (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "bad (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1167,
        "BEND_MAP_ID" : 1167,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1123",
        "source" : "505",
        "target" : "277",
        "EdgeBetweenness" : 241.0,
        "shared_name" : "bad (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "bad (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1123,
        "BEND_MAP_ID" : 1123,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1111",
        "source" : "505",
        "target" : "277",
        "EdgeBetweenness" : 241.0,
        "shared_name" : "bad (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "bad (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1111,
        "BEND_MAP_ID" : 1111,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1049",
        "source" : "505",
        "target" : "277",
        "EdgeBetweenness" : 241.0,
        "shared_name" : "bad (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "bad (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1049,
        "BEND_MAP_ID" : 1049,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "645",
        "source" : "505",
        "target" : "277",
        "EdgeBetweenness" : 241.0,
        "shared_name" : "bad (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "bad (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 645,
        "BEND_MAP_ID" : 645,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "541",
        "source" : "505",
        "target" : "277",
        "EdgeBetweenness" : 241.0,
        "shared_name" : "bad (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "bad (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 541,
        "BEND_MAP_ID" : 541,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "507",
        "source" : "505",
        "target" : "277",
        "EdgeBetweenness" : 241.0,
        "shared_name" : "bad (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "bad (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 507,
        "BEND_MAP_ID" : 507,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2865",
        "source" : "501",
        "target" : "277",
        "EdgeBetweenness" : 243.0,
        "shared_name" : "incredible (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "incredible (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2865,
        "BEND_MAP_ID" : 2865,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2775",
        "source" : "501",
        "target" : "277",
        "EdgeBetweenness" : 243.0,
        "shared_name" : "incredible (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "incredible (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2775,
        "BEND_MAP_ID" : 2775,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "503",
        "source" : "501",
        "target" : "277",
        "EdgeBetweenness" : 243.0,
        "shared_name" : "incredible (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "incredible (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 503,
        "BEND_MAP_ID" : 503,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "499",
        "source" : "497",
        "target" : "277",
        "EdgeBetweenness" : 245.0,
        "shared_name" : "brilliant (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "brilliant (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 499,
        "BEND_MAP_ID" : 499,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3465",
        "source" : "493",
        "target" : "277",
        "EdgeBetweenness" : 247.0,
        "shared_name" : "little (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "little (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3465,
        "BEND_MAP_ID" : 3465,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3367",
        "source" : "493",
        "target" : "277",
        "EdgeBetweenness" : 247.0,
        "shared_name" : "little (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "little (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3367,
        "BEND_MAP_ID" : 3367,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3257",
        "source" : "493",
        "target" : "277",
        "EdgeBetweenness" : 247.0,
        "shared_name" : "little (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "little (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3257,
        "BEND_MAP_ID" : 3257,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3253",
        "source" : "493",
        "target" : "277",
        "EdgeBetweenness" : 247.0,
        "shared_name" : "little (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "little (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3253,
        "BEND_MAP_ID" : 3253,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3143",
        "source" : "493",
        "target" : "277",
        "EdgeBetweenness" : 247.0,
        "shared_name" : "little (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "little (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3143,
        "BEND_MAP_ID" : 3143,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2957",
        "source" : "493",
        "target" : "277",
        "EdgeBetweenness" : 247.0,
        "shared_name" : "little (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "little (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2957,
        "BEND_MAP_ID" : 2957,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2955",
        "source" : "493",
        "target" : "277",
        "EdgeBetweenness" : 247.0,
        "shared_name" : "little (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "little (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2955,
        "BEND_MAP_ID" : 2955,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2841",
        "source" : "493",
        "target" : "277",
        "EdgeBetweenness" : 247.0,
        "shared_name" : "little (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "little (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2841,
        "BEND_MAP_ID" : 2841,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2715",
        "source" : "493",
        "target" : "277",
        "EdgeBetweenness" : 247.0,
        "shared_name" : "little (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "little (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2715,
        "BEND_MAP_ID" : 2715,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2685",
        "source" : "493",
        "target" : "277",
        "EdgeBetweenness" : 247.0,
        "shared_name" : "little (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "little (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2685,
        "BEND_MAP_ID" : 2685,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2537",
        "source" : "493",
        "target" : "277",
        "EdgeBetweenness" : 247.0,
        "shared_name" : "little (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "little (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2537,
        "BEND_MAP_ID" : 2537,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2533",
        "source" : "493",
        "target" : "277",
        "EdgeBetweenness" : 247.0,
        "shared_name" : "little (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "little (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2533,
        "BEND_MAP_ID" : 2533,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2461",
        "source" : "493",
        "target" : "277",
        "EdgeBetweenness" : 247.0,
        "shared_name" : "little (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "little (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2461,
        "BEND_MAP_ID" : 2461,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2437",
        "source" : "493",
        "target" : "277",
        "EdgeBetweenness" : 247.0,
        "shared_name" : "little (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "little (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2437,
        "BEND_MAP_ID" : 2437,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2277",
        "source" : "493",
        "target" : "277",
        "EdgeBetweenness" : 247.0,
        "shared_name" : "little (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "little (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2277,
        "BEND_MAP_ID" : 2277,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2035",
        "source" : "493",
        "target" : "277",
        "EdgeBetweenness" : 247.0,
        "shared_name" : "little (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "little (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2035,
        "BEND_MAP_ID" : 2035,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1639",
        "source" : "493",
        "target" : "277",
        "EdgeBetweenness" : 247.0,
        "shared_name" : "little (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "little (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1639,
        "BEND_MAP_ID" : 1639,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1199",
        "source" : "493",
        "target" : "277",
        "EdgeBetweenness" : 247.0,
        "shared_name" : "little (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "little (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1199,
        "BEND_MAP_ID" : 1199,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1147",
        "source" : "493",
        "target" : "277",
        "EdgeBetweenness" : 247.0,
        "shared_name" : "little (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "little (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1147,
        "BEND_MAP_ID" : 1147,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "983",
        "source" : "493",
        "target" : "277",
        "EdgeBetweenness" : 247.0,
        "shared_name" : "little (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "little (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 983,
        "BEND_MAP_ID" : 983,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "805",
        "source" : "493",
        "target" : "277",
        "EdgeBetweenness" : 247.0,
        "shared_name" : "little (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "little (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 805,
        "BEND_MAP_ID" : 805,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "787",
        "source" : "493",
        "target" : "277",
        "EdgeBetweenness" : 247.0,
        "shared_name" : "little (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "little (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 787,
        "BEND_MAP_ID" : 787,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "563",
        "source" : "493",
        "target" : "277",
        "EdgeBetweenness" : 247.0,
        "shared_name" : "little (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "little (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 563,
        "BEND_MAP_ID" : 563,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "547",
        "source" : "493",
        "target" : "277",
        "EdgeBetweenness" : 247.0,
        "shared_name" : "little (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "little (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 547,
        "BEND_MAP_ID" : 547,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "495",
        "source" : "493",
        "target" : "277",
        "EdgeBetweenness" : 247.0,
        "shared_name" : "little (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "little (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 495,
        "BEND_MAP_ID" : 495,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "491",
        "source" : "489",
        "target" : "277",
        "EdgeBetweenness" : 249.0,
        "shared_name" : "sly (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "sly (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 491,
        "BEND_MAP_ID" : 491,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "487",
        "source" : "485",
        "target" : "277",
        "EdgeBetweenness" : 250.0,
        "shared_name" : "glassy (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "glassy (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 487,
        "BEND_MAP_ID" : 487,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3505",
        "source" : "481",
        "target" : "277",
        "EdgeBetweenness" : 254.0,
        "shared_name" : "well (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "well (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3505,
        "BEND_MAP_ID" : 3505,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3501",
        "source" : "481",
        "target" : "277",
        "EdgeBetweenness" : 254.0,
        "shared_name" : "well (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "well (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3501,
        "BEND_MAP_ID" : 3501,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3291",
        "source" : "481",
        "target" : "277",
        "EdgeBetweenness" : 254.0,
        "shared_name" : "well (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "well (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3291,
        "BEND_MAP_ID" : 3291,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3281",
        "source" : "481",
        "target" : "277",
        "EdgeBetweenness" : 254.0,
        "shared_name" : "well (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "well (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3281,
        "BEND_MAP_ID" : 3281,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3101",
        "source" : "481",
        "target" : "277",
        "EdgeBetweenness" : 254.0,
        "shared_name" : "well (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "well (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3101,
        "BEND_MAP_ID" : 3101,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2993",
        "source" : "481",
        "target" : "277",
        "EdgeBetweenness" : 254.0,
        "shared_name" : "well (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "well (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2993,
        "BEND_MAP_ID" : 2993,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2353",
        "source" : "481",
        "target" : "277",
        "EdgeBetweenness" : 254.0,
        "shared_name" : "well (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "well (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2353,
        "BEND_MAP_ID" : 2353,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2341",
        "source" : "481",
        "target" : "277",
        "EdgeBetweenness" : 254.0,
        "shared_name" : "well (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "well (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2341,
        "BEND_MAP_ID" : 2341,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2061",
        "source" : "481",
        "target" : "277",
        "EdgeBetweenness" : 254.0,
        "shared_name" : "well (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "well (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2061,
        "BEND_MAP_ID" : 2061,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2011",
        "source" : "481",
        "target" : "277",
        "EdgeBetweenness" : 254.0,
        "shared_name" : "well (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "well (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2011,
        "BEND_MAP_ID" : 2011,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1413",
        "source" : "481",
        "target" : "277",
        "EdgeBetweenness" : 254.0,
        "shared_name" : "well (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "well (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1413,
        "BEND_MAP_ID" : 1413,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "483",
        "source" : "481",
        "target" : "277",
        "EdgeBetweenness" : 254.0,
        "shared_name" : "well (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "well (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 483,
        "BEND_MAP_ID" : 483,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "479",
        "source" : "477",
        "target" : "277",
        "EdgeBetweenness" : 255.0,
        "shared_name" : "pathetic (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "pathetic (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 479,
        "BEND_MAP_ID" : 479,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1785",
        "source" : "473",
        "target" : "277",
        "EdgeBetweenness" : 257.0,
        "shared_name" : "special (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "special (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1785,
        "BEND_MAP_ID" : 1785,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "475",
        "source" : "473",
        "target" : "277",
        "EdgeBetweenness" : 257.0,
        "shared_name" : "special (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "special (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 475,
        "BEND_MAP_ID" : 475,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "471",
        "source" : "469",
        "target" : "277",
        "EdgeBetweenness" : 259.0,
        "shared_name" : "such (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "such (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 471,
        "BEND_MAP_ID" : 471,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3193",
        "source" : "465",
        "target" : "277",
        "EdgeBetweenness" : 262.0,
        "shared_name" : "nice (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "nice (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3193,
        "BEND_MAP_ID" : 3193,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2991",
        "source" : "465",
        "target" : "277",
        "EdgeBetweenness" : 262.0,
        "shared_name" : "nice (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "nice (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2991,
        "BEND_MAP_ID" : 2991,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2845",
        "source" : "465",
        "target" : "277",
        "EdgeBetweenness" : 262.0,
        "shared_name" : "nice (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "nice (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2845,
        "BEND_MAP_ID" : 2845,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2643",
        "source" : "465",
        "target" : "277",
        "EdgeBetweenness" : 262.0,
        "shared_name" : "nice (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "nice (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2643,
        "BEND_MAP_ID" : 2643,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2613",
        "source" : "465",
        "target" : "277",
        "EdgeBetweenness" : 262.0,
        "shared_name" : "nice (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "nice (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2613,
        "BEND_MAP_ID" : 2613,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2049",
        "source" : "465",
        "target" : "277",
        "EdgeBetweenness" : 262.0,
        "shared_name" : "nice (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "nice (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2049,
        "BEND_MAP_ID" : 2049,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1465",
        "source" : "465",
        "target" : "277",
        "EdgeBetweenness" : 262.0,
        "shared_name" : "nice (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "nice (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1465,
        "BEND_MAP_ID" : 1465,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1177",
        "source" : "465",
        "target" : "277",
        "EdgeBetweenness" : 262.0,
        "shared_name" : "nice (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "nice (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1177,
        "BEND_MAP_ID" : 1177,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "467",
        "source" : "465",
        "target" : "277",
        "EdgeBetweenness" : 262.0,
        "shared_name" : "nice (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "nice (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 467,
        "BEND_MAP_ID" : 467,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3441",
        "source" : "457",
        "target" : "277",
        "EdgeBetweenness" : 266.0,
        "shared_name" : "alright (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "alright (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3441,
        "BEND_MAP_ID" : 3441,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3391",
        "source" : "457",
        "target" : "277",
        "EdgeBetweenness" : 266.0,
        "shared_name" : "alright (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "alright (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3391,
        "BEND_MAP_ID" : 3391,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1197",
        "source" : "457",
        "target" : "277",
        "EdgeBetweenness" : 266.0,
        "shared_name" : "alright (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "alright (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1197,
        "BEND_MAP_ID" : 1197,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "459",
        "source" : "457",
        "target" : "277",
        "EdgeBetweenness" : 266.0,
        "shared_name" : "alright (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "alright (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 459,
        "BEND_MAP_ID" : 459,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3451",
        "source" : "451",
        "target" : "277",
        "EdgeBetweenness" : 267.0,
        "shared_name" : "huge (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "huge (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3451,
        "BEND_MAP_ID" : 3451,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3405",
        "source" : "451",
        "target" : "277",
        "EdgeBetweenness" : 267.0,
        "shared_name" : "huge (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "huge (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3405,
        "BEND_MAP_ID" : 3405,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2821",
        "source" : "451",
        "target" : "277",
        "EdgeBetweenness" : 267.0,
        "shared_name" : "huge (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "huge (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2821,
        "BEND_MAP_ID" : 2821,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2203",
        "source" : "451",
        "target" : "277",
        "EdgeBetweenness" : 267.0,
        "shared_name" : "huge (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "huge (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2203,
        "BEND_MAP_ID" : 2203,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1809",
        "source" : "451",
        "target" : "277",
        "EdgeBetweenness" : 267.0,
        "shared_name" : "huge (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "huge (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1809,
        "BEND_MAP_ID" : 1809,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "453",
        "source" : "451",
        "target" : "277",
        "EdgeBetweenness" : 267.0,
        "shared_name" : "huge (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "huge (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 453,
        "BEND_MAP_ID" : 453,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "449",
        "source" : "447",
        "target" : "277",
        "EdgeBetweenness" : 268.0,
        "shared_name" : "syphilitic (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "syphilitic (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 449,
        "BEND_MAP_ID" : 449,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3513",
        "source" : "443",
        "target" : "277",
        "EdgeBetweenness" : 271.0,
        "shared_name" : "right (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "right (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3513,
        "BEND_MAP_ID" : 3513,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3511",
        "source" : "443",
        "target" : "277",
        "EdgeBetweenness" : 271.0,
        "shared_name" : "right (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "right (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3511,
        "BEND_MAP_ID" : 3511,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3265",
        "source" : "443",
        "target" : "277",
        "EdgeBetweenness" : 271.0,
        "shared_name" : "right (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "right (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3265,
        "BEND_MAP_ID" : 3265,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2789",
        "source" : "443",
        "target" : "277",
        "EdgeBetweenness" : 271.0,
        "shared_name" : "right (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "right (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2789,
        "BEND_MAP_ID" : 2789,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1949",
        "source" : "443",
        "target" : "277",
        "EdgeBetweenness" : 271.0,
        "shared_name" : "right (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "right (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1949,
        "BEND_MAP_ID" : 1949,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1935",
        "source" : "443",
        "target" : "277",
        "EdgeBetweenness" : 271.0,
        "shared_name" : "right (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "right (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1935,
        "BEND_MAP_ID" : 1935,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1797",
        "source" : "443",
        "target" : "277",
        "EdgeBetweenness" : 271.0,
        "shared_name" : "right (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "right (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1797,
        "BEND_MAP_ID" : 1797,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1477",
        "source" : "443",
        "target" : "277",
        "EdgeBetweenness" : 271.0,
        "shared_name" : "right (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "right (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1477,
        "BEND_MAP_ID" : 1477,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1355",
        "source" : "443",
        "target" : "277",
        "EdgeBetweenness" : 271.0,
        "shared_name" : "right (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "right (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1355,
        "BEND_MAP_ID" : 1355,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1239",
        "source" : "443",
        "target" : "277",
        "EdgeBetweenness" : 271.0,
        "shared_name" : "right (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "right (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1239,
        "BEND_MAP_ID" : 1239,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1235",
        "source" : "443",
        "target" : "277",
        "EdgeBetweenness" : 271.0,
        "shared_name" : "right (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "right (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1235,
        "BEND_MAP_ID" : 1235,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "651",
        "source" : "443",
        "target" : "277",
        "EdgeBetweenness" : 271.0,
        "shared_name" : "right (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "right (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 651,
        "BEND_MAP_ID" : 651,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "609",
        "source" : "443",
        "target" : "277",
        "EdgeBetweenness" : 271.0,
        "shared_name" : "right (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "right (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 609,
        "BEND_MAP_ID" : 609,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "561",
        "source" : "443",
        "target" : "277",
        "EdgeBetweenness" : 271.0,
        "shared_name" : "right (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "right (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 561,
        "BEND_MAP_ID" : 561,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "445",
        "source" : "443",
        "target" : "277",
        "EdgeBetweenness" : 271.0,
        "shared_name" : "right (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "right (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 445,
        "BEND_MAP_ID" : 445,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "441",
        "source" : "439",
        "target" : "277",
        "EdgeBetweenness" : 273.0,
        "shared_name" : "myocardial (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "myocardial (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 441,
        "BEND_MAP_ID" : 441,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "437",
        "source" : "435",
        "target" : "277",
        "EdgeBetweenness" : 274.0,
        "shared_name" : "fit (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "fit (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 437,
        "BEND_MAP_ID" : 437,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "433",
        "source" : "431",
        "target" : "277",
        "EdgeBetweenness" : 276.0,
        "shared_name" : "thankful (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "thankful (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 433,
        "BEND_MAP_ID" : 433,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1107",
        "source" : "427",
        "target" : "277",
        "EdgeBetweenness" : 277.0,
        "shared_name" : "upset (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "upset (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1107,
        "BEND_MAP_ID" : 1107,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "429",
        "source" : "427",
        "target" : "277",
        "EdgeBetweenness" : 277.0,
        "shared_name" : "upset (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "upset (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 429,
        "BEND_MAP_ID" : 429,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "425",
        "source" : "423",
        "target" : "277",
        "EdgeBetweenness" : 281.0,
        "shared_name" : "unfair (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "unfair (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 425,
        "BEND_MAP_ID" : 425,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3073",
        "source" : "419",
        "target" : "277",
        "EdgeBetweenness" : 285.0,
        "shared_name" : "angry (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "angry (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3073,
        "BEND_MAP_ID" : 3073,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1371",
        "source" : "419",
        "target" : "277",
        "EdgeBetweenness" : 285.0,
        "shared_name" : "angry (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "angry (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1371,
        "BEND_MAP_ID" : 1371,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "421",
        "source" : "419",
        "target" : "277",
        "EdgeBetweenness" : 285.0,
        "shared_name" : "angry (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "angry (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 421,
        "BEND_MAP_ID" : 421,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3029",
        "source" : "415",
        "target" : "277",
        "EdgeBetweenness" : 287.0,
        "shared_name" : "enough (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "enough (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3029,
        "BEND_MAP_ID" : 3029,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "417",
        "source" : "415",
        "target" : "277",
        "EdgeBetweenness" : 287.0,
        "shared_name" : "enough (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "enough (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 417,
        "BEND_MAP_ID" : 417,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2779",
        "source" : "409",
        "target" : "277",
        "EdgeBetweenness" : 291.0,
        "shared_name" : "major (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "major (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2779,
        "BEND_MAP_ID" : 2779,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2673",
        "source" : "409",
        "target" : "277",
        "EdgeBetweenness" : 291.0,
        "shared_name" : "major (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "major (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2673,
        "BEND_MAP_ID" : 2673,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2275",
        "source" : "409",
        "target" : "277",
        "EdgeBetweenness" : 291.0,
        "shared_name" : "major (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "major (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2275,
        "BEND_MAP_ID" : 2275,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1757",
        "source" : "409",
        "target" : "277",
        "EdgeBetweenness" : 291.0,
        "shared_name" : "major (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "major (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1757,
        "BEND_MAP_ID" : 1757,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "411",
        "source" : "409",
        "target" : "277",
        "EdgeBetweenness" : 291.0,
        "shared_name" : "major (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "major (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 411,
        "BEND_MAP_ID" : 411,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2995",
        "source" : "405",
        "target" : "277",
        "EdgeBetweenness" : 292.0,
        "shared_name" : "cute (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "cute (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2995,
        "BEND_MAP_ID" : 2995,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2977",
        "source" : "405",
        "target" : "277",
        "EdgeBetweenness" : 292.0,
        "shared_name" : "cute (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "cute (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2977,
        "BEND_MAP_ID" : 2977,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2975",
        "source" : "405",
        "target" : "277",
        "EdgeBetweenness" : 292.0,
        "shared_name" : "cute (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "cute (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2975,
        "BEND_MAP_ID" : 2975,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2045",
        "source" : "405",
        "target" : "277",
        "EdgeBetweenness" : 292.0,
        "shared_name" : "cute (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "cute (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2045,
        "BEND_MAP_ID" : 2045,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2039",
        "source" : "405",
        "target" : "277",
        "EdgeBetweenness" : 292.0,
        "shared_name" : "cute (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "cute (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2039,
        "BEND_MAP_ID" : 2039,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1977",
        "source" : "405",
        "target" : "277",
        "EdgeBetweenness" : 292.0,
        "shared_name" : "cute (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "cute (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1977,
        "BEND_MAP_ID" : 1977,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "981",
        "source" : "405",
        "target" : "277",
        "EdgeBetweenness" : 292.0,
        "shared_name" : "cute (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "cute (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 981,
        "BEND_MAP_ID" : 981,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "407",
        "source" : "405",
        "target" : "277",
        "EdgeBetweenness" : 292.0,
        "shared_name" : "cute (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "cute (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 407,
        "BEND_MAP_ID" : 407,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3397",
        "source" : "399",
        "target" : "277",
        "EdgeBetweenness" : 295.0,
        "shared_name" : "okay (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "okay (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3397,
        "BEND_MAP_ID" : 3397,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3345",
        "source" : "399",
        "target" : "277",
        "EdgeBetweenness" : 295.0,
        "shared_name" : "okay (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "okay (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3345,
        "BEND_MAP_ID" : 3345,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3217",
        "source" : "399",
        "target" : "277",
        "EdgeBetweenness" : 295.0,
        "shared_name" : "okay (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "okay (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3217,
        "BEND_MAP_ID" : 3217,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3065",
        "source" : "399",
        "target" : "277",
        "EdgeBetweenness" : 295.0,
        "shared_name" : "okay (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "okay (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3065,
        "BEND_MAP_ID" : 3065,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3061",
        "source" : "399",
        "target" : "277",
        "EdgeBetweenness" : 295.0,
        "shared_name" : "okay (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "okay (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3061,
        "BEND_MAP_ID" : 3061,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3051",
        "source" : "399",
        "target" : "277",
        "EdgeBetweenness" : 295.0,
        "shared_name" : "okay (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "okay (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3051,
        "BEND_MAP_ID" : 3051,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "463",
        "source" : "399",
        "target" : "277",
        "EdgeBetweenness" : 295.0,
        "shared_name" : "okay (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "okay (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 463,
        "BEND_MAP_ID" : 463,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "401",
        "source" : "399",
        "target" : "277",
        "EdgeBetweenness" : 295.0,
        "shared_name" : "okay (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "okay (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 401,
        "BEND_MAP_ID" : 401,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "397",
        "source" : "395",
        "target" : "277",
        "EdgeBetweenness" : 298.0,
        "shared_name" : "fruitful (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "fruitful (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 397,
        "BEND_MAP_ID" : 397,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3373",
        "source" : "391",
        "target" : "277",
        "EdgeBetweenness" : 301.0,
        "shared_name" : "good (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "good (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3373,
        "BEND_MAP_ID" : 3373,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3361",
        "source" : "391",
        "target" : "277",
        "EdgeBetweenness" : 301.0,
        "shared_name" : "good (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "good (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3361,
        "BEND_MAP_ID" : 3361,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3295",
        "source" : "391",
        "target" : "277",
        "EdgeBetweenness" : 301.0,
        "shared_name" : "good (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "good (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3295,
        "BEND_MAP_ID" : 3295,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3289",
        "source" : "391",
        "target" : "277",
        "EdgeBetweenness" : 301.0,
        "shared_name" : "good (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "good (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3289,
        "BEND_MAP_ID" : 3289,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3167",
        "source" : "391",
        "target" : "277",
        "EdgeBetweenness" : 301.0,
        "shared_name" : "good (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "good (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3167,
        "BEND_MAP_ID" : 3167,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3145",
        "source" : "391",
        "target" : "277",
        "EdgeBetweenness" : 301.0,
        "shared_name" : "good (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "good (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3145,
        "BEND_MAP_ID" : 3145,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2963",
        "source" : "391",
        "target" : "277",
        "EdgeBetweenness" : 301.0,
        "shared_name" : "good (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "good (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2963,
        "BEND_MAP_ID" : 2963,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2767",
        "source" : "391",
        "target" : "277",
        "EdgeBetweenness" : 301.0,
        "shared_name" : "good (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "good (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2767,
        "BEND_MAP_ID" : 2767,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2759",
        "source" : "391",
        "target" : "277",
        "EdgeBetweenness" : 301.0,
        "shared_name" : "good (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "good (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2759,
        "BEND_MAP_ID" : 2759,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2521",
        "source" : "391",
        "target" : "277",
        "EdgeBetweenness" : 301.0,
        "shared_name" : "good (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "good (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2521,
        "BEND_MAP_ID" : 2521,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2519",
        "source" : "391",
        "target" : "277",
        "EdgeBetweenness" : 301.0,
        "shared_name" : "good (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "good (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2519,
        "BEND_MAP_ID" : 2519,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2141",
        "source" : "391",
        "target" : "277",
        "EdgeBetweenness" : 301.0,
        "shared_name" : "good (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "good (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2141,
        "BEND_MAP_ID" : 2141,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2077",
        "source" : "391",
        "target" : "277",
        "EdgeBetweenness" : 301.0,
        "shared_name" : "good (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "good (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2077,
        "BEND_MAP_ID" : 2077,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1967",
        "source" : "391",
        "target" : "277",
        "EdgeBetweenness" : 301.0,
        "shared_name" : "good (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "good (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1967,
        "BEND_MAP_ID" : 1967,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1927",
        "source" : "391",
        "target" : "277",
        "EdgeBetweenness" : 301.0,
        "shared_name" : "good (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "good (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1927,
        "BEND_MAP_ID" : 1927,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1851",
        "source" : "391",
        "target" : "277",
        "EdgeBetweenness" : 301.0,
        "shared_name" : "good (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "good (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1851,
        "BEND_MAP_ID" : 1851,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1753",
        "source" : "391",
        "target" : "277",
        "EdgeBetweenness" : 301.0,
        "shared_name" : "good (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "good (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1753,
        "BEND_MAP_ID" : 1753,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1603",
        "source" : "391",
        "target" : "277",
        "EdgeBetweenness" : 301.0,
        "shared_name" : "good (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "good (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1603,
        "BEND_MAP_ID" : 1603,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1273",
        "source" : "391",
        "target" : "277",
        "EdgeBetweenness" : 301.0,
        "shared_name" : "good (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "good (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1273,
        "BEND_MAP_ID" : 1273,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1271",
        "source" : "391",
        "target" : "277",
        "EdgeBetweenness" : 301.0,
        "shared_name" : "good (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "good (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1271,
        "BEND_MAP_ID" : 1271,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1161",
        "source" : "391",
        "target" : "277",
        "EdgeBetweenness" : 301.0,
        "shared_name" : "good (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "good (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1161,
        "BEND_MAP_ID" : 1161,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1151",
        "source" : "391",
        "target" : "277",
        "EdgeBetweenness" : 301.0,
        "shared_name" : "good (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "good (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1151,
        "BEND_MAP_ID" : 1151,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1121",
        "source" : "391",
        "target" : "277",
        "EdgeBetweenness" : 301.0,
        "shared_name" : "good (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "good (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1121,
        "BEND_MAP_ID" : 1121,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "833",
        "source" : "391",
        "target" : "277",
        "EdgeBetweenness" : 301.0,
        "shared_name" : "good (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "good (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 833,
        "BEND_MAP_ID" : 833,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "797",
        "source" : "391",
        "target" : "277",
        "EdgeBetweenness" : 301.0,
        "shared_name" : "good (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "good (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 797,
        "BEND_MAP_ID" : 797,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "603",
        "source" : "391",
        "target" : "277",
        "EdgeBetweenness" : 301.0,
        "shared_name" : "good (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "good (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 603,
        "BEND_MAP_ID" : 603,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "597",
        "source" : "391",
        "target" : "277",
        "EdgeBetweenness" : 301.0,
        "shared_name" : "good (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "good (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 597,
        "BEND_MAP_ID" : 597,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "519",
        "source" : "391",
        "target" : "277",
        "EdgeBetweenness" : 301.0,
        "shared_name" : "good (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "good (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 519,
        "BEND_MAP_ID" : 519,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "393",
        "source" : "391",
        "target" : "277",
        "EdgeBetweenness" : 301.0,
        "shared_name" : "good (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "good (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 393,
        "BEND_MAP_ID" : 393,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2525",
        "source" : "387",
        "target" : "277",
        "EdgeBetweenness" : 302.0,
        "shared_name" : "fine (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "fine (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2525,
        "BEND_MAP_ID" : 2525,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2523",
        "source" : "387",
        "target" : "277",
        "EdgeBetweenness" : 302.0,
        "shared_name" : "fine (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "fine (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2523,
        "BEND_MAP_ID" : 2523,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1513",
        "source" : "387",
        "target" : "277",
        "EdgeBetweenness" : 302.0,
        "shared_name" : "fine (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "fine (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1513,
        "BEND_MAP_ID" : 1513,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "413",
        "source" : "387",
        "target" : "277",
        "EdgeBetweenness" : 302.0,
        "shared_name" : "fine (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "fine (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 413,
        "BEND_MAP_ID" : 413,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "389",
        "source" : "387",
        "target" : "277",
        "EdgeBetweenness" : 302.0,
        "shared_name" : "fine (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "fine (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 389,
        "BEND_MAP_ID" : 389,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "385",
        "source" : "383",
        "target" : "277",
        "EdgeBetweenness" : 304.0,
        "shared_name" : "raspy (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "raspy (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 385,
        "BEND_MAP_ID" : 385,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "381",
        "source" : "379",
        "target" : "277",
        "EdgeBetweenness" : 308.0,
        "shared_name" : "choked (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "choked (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 381,
        "BEND_MAP_ID" : 381,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "513",
        "source" : "375",
        "target" : "277",
        "EdgeBetweenness" : 309.0,
        "shared_name" : "clammy (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "clammy (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 513,
        "BEND_MAP_ID" : 513,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "377",
        "source" : "375",
        "target" : "277",
        "EdgeBetweenness" : 309.0,
        "shared_name" : "clammy (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "clammy (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 377,
        "BEND_MAP_ID" : 377,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2301",
        "source" : "371",
        "target" : "277",
        "EdgeBetweenness" : 313.0,
        "shared_name" : "cold (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "cold (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2301,
        "BEND_MAP_ID" : 2301,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2175",
        "source" : "371",
        "target" : "277",
        "EdgeBetweenness" : 313.0,
        "shared_name" : "cold (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "cold (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2175,
        "BEND_MAP_ID" : 2175,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1345",
        "source" : "371",
        "target" : "277",
        "EdgeBetweenness" : 313.0,
        "shared_name" : "cold (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "cold (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1345,
        "BEND_MAP_ID" : 1345,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "373",
        "source" : "371",
        "target" : "277",
        "EdgeBetweenness" : 313.0,
        "shared_name" : "cold (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "cold (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 373,
        "BEND_MAP_ID" : 373,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3213",
        "source" : "367",
        "target" : "277",
        "EdgeBetweenness" : 316.0,
        "shared_name" : "lifeless (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "lifeless (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3213,
        "BEND_MAP_ID" : 3213,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3209",
        "source" : "367",
        "target" : "277",
        "EdgeBetweenness" : 316.0,
        "shared_name" : "lifeless (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "lifeless (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3209,
        "BEND_MAP_ID" : 3209,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "369",
        "source" : "367",
        "target" : "277",
        "EdgeBetweenness" : 316.0,
        "shared_name" : "lifeless (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "lifeless (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 369,
        "BEND_MAP_ID" : 369,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1857",
        "source" : "361",
        "target" : "277",
        "EdgeBetweenness" : 319.0,
        "shared_name" : "middle (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "middle (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1857,
        "BEND_MAP_ID" : 1857,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "363",
        "source" : "361",
        "target" : "277",
        "EdgeBetweenness" : 319.0,
        "shared_name" : "middle (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "middle (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 363,
        "BEND_MAP_ID" : 363,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "359",
        "source" : "357",
        "target" : "277",
        "EdgeBetweenness" : 323.0,
        "shared_name" : "upper (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "upper (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 359,
        "BEND_MAP_ID" : 359,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "355",
        "source" : "353",
        "target" : "277",
        "EdgeBetweenness" : 324.0,
        "shared_name" : "early (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "early (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 355,
        "BEND_MAP_ID" : 355,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2765",
        "source" : "349",
        "target" : "277",
        "EdgeBetweenness" : 328.0,
        "shared_name" : "late (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "late (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2765,
        "BEND_MAP_ID" : 2765,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1145",
        "source" : "349",
        "target" : "277",
        "EdgeBetweenness" : 328.0,
        "shared_name" : "late (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "late (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1145,
        "BEND_MAP_ID" : 1145,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "351",
        "source" : "349",
        "target" : "277",
        "EdgeBetweenness" : 328.0,
        "shared_name" : "late (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "late (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 351,
        "BEND_MAP_ID" : 351,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1303",
        "source" : "345",
        "target" : "277",
        "EdgeBetweenness" : 330.0,
        "shared_name" : "dry (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "dry (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1303,
        "BEND_MAP_ID" : 1303,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "347",
        "source" : "345",
        "target" : "277",
        "EdgeBetweenness" : 330.0,
        "shared_name" : "dry (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "dry (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 347,
        "BEND_MAP_ID" : 347,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2091",
        "source" : "341",
        "target" : "277",
        "EdgeBetweenness" : 332.0,
        "shared_name" : "fat (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "fat (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2091,
        "BEND_MAP_ID" : 2091,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "343",
        "source" : "341",
        "target" : "277",
        "EdgeBetweenness" : 332.0,
        "shared_name" : "fat (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "fat (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 343,
        "BEND_MAP_ID" : 343,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1827",
        "source" : "333",
        "target" : "277",
        "EdgeBetweenness" : 336.0,
        "shared_name" : "close (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "close (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1827,
        "BEND_MAP_ID" : 1827,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1557",
        "source" : "333",
        "target" : "277",
        "EdgeBetweenness" : 336.0,
        "shared_name" : "close (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "close (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1557,
        "BEND_MAP_ID" : 1557,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1187",
        "source" : "333",
        "target" : "277",
        "EdgeBetweenness" : 336.0,
        "shared_name" : "close (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "close (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1187,
        "BEND_MAP_ID" : 1187,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "803",
        "source" : "333",
        "target" : "277",
        "EdgeBetweenness" : 336.0,
        "shared_name" : "close (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "close (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 803,
        "BEND_MAP_ID" : 803,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "365",
        "source" : "333",
        "target" : "277",
        "EdgeBetweenness" : 336.0,
        "shared_name" : "close (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "close (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 365,
        "BEND_MAP_ID" : 365,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "335",
        "source" : "333",
        "target" : "277",
        "EdgeBetweenness" : 336.0,
        "shared_name" : "close (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "close (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 335,
        "BEND_MAP_ID" : 335,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3245",
        "source" : "327",
        "target" : "277",
        "EdgeBetweenness" : 340.0,
        "shared_name" : "wrong (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "wrong (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3245,
        "BEND_MAP_ID" : 3245,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3203",
        "source" : "327",
        "target" : "277",
        "EdgeBetweenness" : 340.0,
        "shared_name" : "wrong (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "wrong (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3203,
        "BEND_MAP_ID" : 3203,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3063",
        "source" : "327",
        "target" : "277",
        "EdgeBetweenness" : 340.0,
        "shared_name" : "wrong (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "wrong (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3063,
        "BEND_MAP_ID" : 3063,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1439",
        "source" : "327",
        "target" : "277",
        "EdgeBetweenness" : 340.0,
        "shared_name" : "wrong (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "wrong (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1439,
        "BEND_MAP_ID" : 1439,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "681",
        "source" : "327",
        "target" : "277",
        "EdgeBetweenness" : 340.0,
        "shared_name" : "wrong (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "wrong (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 681,
        "BEND_MAP_ID" : 681,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "679",
        "source" : "327",
        "target" : "277",
        "EdgeBetweenness" : 340.0,
        "shared_name" : "wrong (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "wrong (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 679,
        "BEND_MAP_ID" : 679,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "331",
        "source" : "327",
        "target" : "277",
        "EdgeBetweenness" : 340.0,
        "shared_name" : "wrong (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "wrong (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 331,
        "BEND_MAP_ID" : 331,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "329",
        "source" : "327",
        "target" : "277",
        "EdgeBetweenness" : 340.0,
        "shared_name" : "wrong (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "wrong (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 329,
        "BEND_MAP_ID" : 329,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3399",
        "source" : "323",
        "target" : "277",
        "EdgeBetweenness" : 342.0,
        "shared_name" : "worried (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "worried (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3399,
        "BEND_MAP_ID" : 3399,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2485",
        "source" : "323",
        "target" : "277",
        "EdgeBetweenness" : 342.0,
        "shared_name" : "worried (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "worried (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2485,
        "BEND_MAP_ID" : 2485,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2283",
        "source" : "323",
        "target" : "277",
        "EdgeBetweenness" : 342.0,
        "shared_name" : "worried (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "worried (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2283,
        "BEND_MAP_ID" : 2283,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2249",
        "source" : "323",
        "target" : "277",
        "EdgeBetweenness" : 342.0,
        "shared_name" : "worried (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "worried (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2249,
        "BEND_MAP_ID" : 2249,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1193",
        "source" : "323",
        "target" : "277",
        "EdgeBetweenness" : 342.0,
        "shared_name" : "worried (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "worried (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1193,
        "BEND_MAP_ID" : 1193,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "455",
        "source" : "323",
        "target" : "277",
        "EdgeBetweenness" : 342.0,
        "shared_name" : "worried (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "worried (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 455,
        "BEND_MAP_ID" : 455,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "325",
        "source" : "323",
        "target" : "277",
        "EdgeBetweenness" : 342.0,
        "shared_name" : "worried (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "worried (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 325,
        "BEND_MAP_ID" : 325,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "321",
        "source" : "319",
        "target" : "277",
        "EdgeBetweenness" : 344.0,
        "shared_name" : "breathless (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "breathless (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 321,
        "BEND_MAP_ID" : 321,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3085",
        "source" : "315",
        "target" : "277",
        "EdgeBetweenness" : 346.0,
        "shared_name" : "open (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "open (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3085,
        "BEND_MAP_ID" : 3085,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3083",
        "source" : "315",
        "target" : "277",
        "EdgeBetweenness" : 346.0,
        "shared_name" : "open (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "open (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3083,
        "BEND_MAP_ID" : 3083,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2935",
        "source" : "315",
        "target" : "277",
        "EdgeBetweenness" : 346.0,
        "shared_name" : "open (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "open (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2935,
        "BEND_MAP_ID" : 2935,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2741",
        "source" : "315",
        "target" : "277",
        "EdgeBetweenness" : 346.0,
        "shared_name" : "open (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "open (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2741,
        "BEND_MAP_ID" : 2741,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2735",
        "source" : "315",
        "target" : "277",
        "EdgeBetweenness" : 346.0,
        "shared_name" : "open (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "open (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2735,
        "BEND_MAP_ID" : 2735,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2659",
        "source" : "315",
        "target" : "277",
        "EdgeBetweenness" : 346.0,
        "shared_name" : "open (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "open (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2659,
        "BEND_MAP_ID" : 2659,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2573",
        "source" : "315",
        "target" : "277",
        "EdgeBetweenness" : 346.0,
        "shared_name" : "open (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "open (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2573,
        "BEND_MAP_ID" : 2573,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1833",
        "source" : "315",
        "target" : "277",
        "EdgeBetweenness" : 346.0,
        "shared_name" : "open (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "open (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1833,
        "BEND_MAP_ID" : 1833,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1825",
        "source" : "315",
        "target" : "277",
        "EdgeBetweenness" : 346.0,
        "shared_name" : "open (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "open (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1825,
        "BEND_MAP_ID" : 1825,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1697",
        "source" : "315",
        "target" : "277",
        "EdgeBetweenness" : 346.0,
        "shared_name" : "open (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "open (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1697,
        "BEND_MAP_ID" : 1697,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1619",
        "source" : "315",
        "target" : "277",
        "EdgeBetweenness" : 346.0,
        "shared_name" : "open (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "open (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1619,
        "BEND_MAP_ID" : 1619,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "969",
        "source" : "315",
        "target" : "277",
        "EdgeBetweenness" : 346.0,
        "shared_name" : "open (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "open (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 969,
        "BEND_MAP_ID" : 969,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "339",
        "source" : "315",
        "target" : "277",
        "EdgeBetweenness" : 346.0,
        "shared_name" : "open (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "open (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 339,
        "BEND_MAP_ID" : 339,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "317",
        "source" : "315",
        "target" : "277",
        "EdgeBetweenness" : 346.0,
        "shared_name" : "open (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "open (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 317,
        "BEND_MAP_ID" : 317,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "313",
        "source" : "311",
        "target" : "277",
        "EdgeBetweenness" : 348.0,
        "shared_name" : "tense (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "tense (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 313,
        "BEND_MAP_ID" : 313,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3531",
        "source" : "305",
        "target" : "277",
        "EdgeBetweenness" : 353.0,
        "shared_name" : "big (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "big (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3531,
        "BEND_MAP_ID" : 3531,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3525",
        "source" : "305",
        "target" : "277",
        "EdgeBetweenness" : 353.0,
        "shared_name" : "big (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "big (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3525,
        "BEND_MAP_ID" : 3525,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3463",
        "source" : "305",
        "target" : "277",
        "EdgeBetweenness" : 353.0,
        "shared_name" : "big (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "big (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3463,
        "BEND_MAP_ID" : 3463,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3299",
        "source" : "305",
        "target" : "277",
        "EdgeBetweenness" : 353.0,
        "shared_name" : "big (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "big (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3299,
        "BEND_MAP_ID" : 3299,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3151",
        "source" : "305",
        "target" : "277",
        "EdgeBetweenness" : 353.0,
        "shared_name" : "big (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "big (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3151,
        "BEND_MAP_ID" : 3151,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2725",
        "source" : "305",
        "target" : "277",
        "EdgeBetweenness" : 353.0,
        "shared_name" : "big (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "big (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2725,
        "BEND_MAP_ID" : 2725,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2579",
        "source" : "305",
        "target" : "277",
        "EdgeBetweenness" : 353.0,
        "shared_name" : "big (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "big (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2579,
        "BEND_MAP_ID" : 2579,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2279",
        "source" : "305",
        "target" : "277",
        "EdgeBetweenness" : 353.0,
        "shared_name" : "big (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "big (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2279,
        "BEND_MAP_ID" : 2279,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1889",
        "source" : "305",
        "target" : "277",
        "EdgeBetweenness" : 353.0,
        "shared_name" : "big (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "big (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1889,
        "BEND_MAP_ID" : 1889,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1525",
        "source" : "305",
        "target" : "277",
        "EdgeBetweenness" : 353.0,
        "shared_name" : "big (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "big (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1525,
        "BEND_MAP_ID" : 1525,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1363",
        "source" : "305",
        "target" : "277",
        "EdgeBetweenness" : 353.0,
        "shared_name" : "big (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "big (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1363,
        "BEND_MAP_ID" : 1363,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "847",
        "source" : "305",
        "target" : "277",
        "EdgeBetweenness" : 353.0,
        "shared_name" : "big (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "big (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 847,
        "BEND_MAP_ID" : 847,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "461",
        "source" : "305",
        "target" : "277",
        "EdgeBetweenness" : 353.0,
        "shared_name" : "big (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "big (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 461,
        "BEND_MAP_ID" : 461,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "307",
        "source" : "305",
        "target" : "277",
        "EdgeBetweenness" : 353.0,
        "shared_name" : "big (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "big (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 307,
        "BEND_MAP_ID" : 307,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "303",
        "source" : "301",
        "target" : "277",
        "EdgeBetweenness" : 354.0,
        "shared_name" : "sadistic (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "sadistic (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 303,
        "BEND_MAP_ID" : 303,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3395",
        "source" : "293",
        "target" : "277",
        "EdgeBetweenness" : 359.0,
        "shared_name" : "old (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "old (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3395,
        "BEND_MAP_ID" : 3395,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3067",
        "source" : "293",
        "target" : "277",
        "EdgeBetweenness" : 359.0,
        "shared_name" : "old (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "old (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3067,
        "BEND_MAP_ID" : 3067,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2535",
        "source" : "293",
        "target" : "277",
        "EdgeBetweenness" : 359.0,
        "shared_name" : "old (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "old (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2535,
        "BEND_MAP_ID" : 2535,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2317",
        "source" : "293",
        "target" : "277",
        "EdgeBetweenness" : 359.0,
        "shared_name" : "old (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "old (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2317,
        "BEND_MAP_ID" : 2317,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2189",
        "source" : "293",
        "target" : "277",
        "EdgeBetweenness" : 359.0,
        "shared_name" : "old (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "old (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2189,
        "BEND_MAP_ID" : 2189,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2139",
        "source" : "293",
        "target" : "277",
        "EdgeBetweenness" : 359.0,
        "shared_name" : "old (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "old (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2139,
        "BEND_MAP_ID" : 2139,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2105",
        "source" : "293",
        "target" : "277",
        "EdgeBetweenness" : 359.0,
        "shared_name" : "old (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "old (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2105,
        "BEND_MAP_ID" : 2105,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2093",
        "source" : "293",
        "target" : "277",
        "EdgeBetweenness" : 359.0,
        "shared_name" : "old (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "old (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2093,
        "BEND_MAP_ID" : 2093,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1989",
        "source" : "293",
        "target" : "277",
        "EdgeBetweenness" : 359.0,
        "shared_name" : "old (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "old (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1989,
        "BEND_MAP_ID" : 1989,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1959",
        "source" : "293",
        "target" : "277",
        "EdgeBetweenness" : 359.0,
        "shared_name" : "old (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "old (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1959,
        "BEND_MAP_ID" : 1959,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1937",
        "source" : "293",
        "target" : "277",
        "EdgeBetweenness" : 359.0,
        "shared_name" : "old (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "old (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1937,
        "BEND_MAP_ID" : 1937,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1899",
        "source" : "293",
        "target" : "277",
        "EdgeBetweenness" : 359.0,
        "shared_name" : "old (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "old (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1899,
        "BEND_MAP_ID" : 1899,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1563",
        "source" : "293",
        "target" : "277",
        "EdgeBetweenness" : 359.0,
        "shared_name" : "old (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "old (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1563,
        "BEND_MAP_ID" : 1563,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1365",
        "source" : "293",
        "target" : "277",
        "EdgeBetweenness" : 359.0,
        "shared_name" : "old (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "old (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1365,
        "BEND_MAP_ID" : 1365,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "665",
        "source" : "293",
        "target" : "277",
        "EdgeBetweenness" : 359.0,
        "shared_name" : "old (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "old (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 665,
        "BEND_MAP_ID" : 665,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "635",
        "source" : "293",
        "target" : "277",
        "EdgeBetweenness" : 359.0,
        "shared_name" : "old (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "old (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 635,
        "BEND_MAP_ID" : 635,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "629",
        "source" : "293",
        "target" : "277",
        "EdgeBetweenness" : 359.0,
        "shared_name" : "old (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "old (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 629,
        "BEND_MAP_ID" : 629,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "623",
        "source" : "293",
        "target" : "277",
        "EdgeBetweenness" : 359.0,
        "shared_name" : "old (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "old (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 623,
        "BEND_MAP_ID" : 623,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "403",
        "source" : "293",
        "target" : "277",
        "EdgeBetweenness" : 359.0,
        "shared_name" : "old (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "old (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 403,
        "BEND_MAP_ID" : 403,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "337",
        "source" : "293",
        "target" : "277",
        "EdgeBetweenness" : 359.0,
        "shared_name" : "old (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "old (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 337,
        "BEND_MAP_ID" : 337,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "299",
        "source" : "293",
        "target" : "277",
        "EdgeBetweenness" : 359.0,
        "shared_name" : "old (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "old (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 299,
        "BEND_MAP_ID" : 299,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "297",
        "source" : "293",
        "target" : "277",
        "EdgeBetweenness" : 359.0,
        "shared_name" : "old (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "old (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 297,
        "BEND_MAP_ID" : 297,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "295",
        "source" : "293",
        "target" : "277",
        "EdgeBetweenness" : 359.0,
        "shared_name" : "old (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "old (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 295,
        "BEND_MAP_ID" : 295,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "291",
        "source" : "289",
        "target" : "277",
        "EdgeBetweenness" : 360.0,
        "shared_name" : "aural (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "aural (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 291,
        "BEND_MAP_ID" : 291,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2543",
        "source" : "285",
        "target" : "277",
        "EdgeBetweenness" : 363.0,
        "shared_name" : "ready (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "ready (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2543,
        "BEND_MAP_ID" : 2543,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "287",
        "source" : "285",
        "target" : "277",
        "EdgeBetweenness" : 363.0,
        "shared_name" : "ready (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "ready (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 287,
        "BEND_MAP_ID" : 287,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3115",
        "source" : "281",
        "target" : "277",
        "EdgeBetweenness" : 365.0,
        "shared_name" : "silent (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "silent (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3115,
        "BEND_MAP_ID" : 3115,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "309",
        "source" : "281",
        "target" : "277",
        "EdgeBetweenness" : 365.0,
        "shared_name" : "silent (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "silent (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 309,
        "BEND_MAP_ID" : 309,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "283",
        "source" : "281",
        "target" : "277",
        "EdgeBetweenness" : 365.0,
        "shared_name" : "silent (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "silent (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 283,
        "BEND_MAP_ID" : 283,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3427",
        "source" : "277",
        "target" : "277",
        "EdgeBetweenness" : 0.0,
        "shared_name" : "ferris (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "ferris (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3427,
        "BEND_MAP_ID" : 3427,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2969",
        "source" : "277",
        "target" : "277",
        "EdgeBetweenness" : 0.0,
        "shared_name" : "ferris (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "ferris (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2969,
        "BEND_MAP_ID" : 2969,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2473",
        "source" : "277",
        "target" : "277",
        "EdgeBetweenness" : 0.0,
        "shared_name" : "ferris (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "ferris (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2473,
        "BEND_MAP_ID" : 2473,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3019",
        "source" : "275",
        "target" : "277",
        "EdgeBetweenness" : 370.0,
        "shared_name" : "black (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "black (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3019,
        "BEND_MAP_ID" : 3019,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3015",
        "source" : "275",
        "target" : "277",
        "EdgeBetweenness" : 370.0,
        "shared_name" : "black (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "black (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 3015,
        "BEND_MAP_ID" : 3015,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2961",
        "source" : "275",
        "target" : "277",
        "EdgeBetweenness" : 370.0,
        "shared_name" : "black (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "black (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2961,
        "BEND_MAP_ID" : 2961,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2747",
        "source" : "275",
        "target" : "277",
        "EdgeBetweenness" : 370.0,
        "shared_name" : "black (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "black (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2747,
        "BEND_MAP_ID" : 2747,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2639",
        "source" : "275",
        "target" : "277",
        "EdgeBetweenness" : 370.0,
        "shared_name" : "black (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "black (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2639,
        "BEND_MAP_ID" : 2639,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2527",
        "source" : "275",
        "target" : "277",
        "EdgeBetweenness" : 370.0,
        "shared_name" : "black (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "black (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 2527,
        "BEND_MAP_ID" : 2527,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1483",
        "source" : "275",
        "target" : "277",
        "EdgeBetweenness" : 370.0,
        "shared_name" : "black (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "black (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 1483,
        "BEND_MAP_ID" : 1483,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "987",
        "source" : "275",
        "target" : "277",
        "EdgeBetweenness" : 370.0,
        "shared_name" : "black (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "black (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 987,
        "BEND_MAP_ID" : 987,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "279",
        "source" : "275",
        "target" : "277",
        "EdgeBetweenness" : 370.0,
        "shared_name" : "black (ADJ) ferris",
        "shared_interaction" : "ADJ",
        "name" : "black (ADJ) ferris",
        "interaction" : "ADJ",
        "SUID" : 279,
        "BEND_MAP_ID" : 279,
        "selected" : false
      },
      "selected" : false
    } ]
  }
},"Network": {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.3",
  "target_cytoscapejs_version" : "~2.1",
  "data" : {
    "shared_name" : "Network",
    "name" : "Network",
    "SUID" : 128,
    "__Annotations" : [ ],
    "selected" : false
  },
  "elements" : {
    "nodes" : [ ],
    "edges" : [ ]
  }
}}